import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {NavigationContainer} from '@react-navigation/native';
import Login from './src/screens/Login';
import Home from './src/screens/Home';
import ProjectTarget from './src/screens/ProjectTarget/ProjectTarget';
import AddProjectTarget from './src/screens/ProjectTarget/AddProjectTarget';
import ClientAgreementMaster from './src/screens/Client Agreement Master/ClientAgreementMaster';
import AddClientAgreement from './src/screens/Client Agreement Master/AddClientAgreement';
import AccountMaster from './src/screens/Account Master/AccountMaster';
import AddAccountant from './src/screens/Account Master/AddAccountant';
import TechnologyMaster from './src/screens/Technology Master/TechnologyMaster';
import AddTechnology from './src/screens/Technology Master/AddTechnology';
import CompareReport from './src/screens/CompareReport';
import ResourceMaster from './src/screens/Resource/ResourceMaster';
import AddResource from './src/screens/Resource/AddResource';
import ExternalProductMaster from './src/screens/External Product/ExternalProductMaster'; 
import AddExternalProduct from './src/screens/External Product/AddExternalProduct';
import PurchaseOrderMaster from './src/screens/Purchase Order/PurchaseOrderMaster';
import AddPurchaseOrder from './src/screens/Purchase Order/AddPurchaseOrder';
import DrawerNav from './src/components/DrawerNav';
import ForgotPassword from './src/screens/ForgotPassword';
import EditScreen from './src/screens/Account Master/EditScreen';
import Vendor from './src/screens/Vendor Master/Vendor';
import AddVendor from './src/screens/Vendor Master/AddVendor';
import UserSetting from './src/screens/User Setting/UserSetting';
import ClientRequest from './src/screens/Client Request/ClientRequest';
import EditTechnology from './src/screens/Technology Master/EditTechnology';
import EditExternalProduct from './src/screens/External Product/EditExternalProduct';
import EditPurchaseOrder from './src/screens/Purchase Order/EditPurchase'
import EditProjectTarget from './src/screens/ProjectTarget/EditProjectTarget';
import EditClientAgreement from './src/screens/Client Agreement Master/EditClientAgreement'
import EditResource from './src/screens/Resource/EditResource';
import EditVendor from './src/screens/Vendor Master/EditVendor';
import AddUserSetting from './src/screens/User Setting/AddUserSetting';
import UpdateModal from './src/screens/Client Request/UpdateModal'
import EditUserSetting from './src/screens/User Setting/Edit UserSetting'
import ClientMaster from './src/screens/Client Master/ClientMaster';
import Setting from './src/screens/Setting Master/Setting';
import EditSetting from './src/screens/Setting Master/EditSetting';
import AddClient from './src/screens/Client Master/AddClient';
import EditClient from './src/screens/Client Master/EditClient';
import ViewModal from './src/screens/ProjectTarget/Viewmodal';
import ModalReource from './src/screens/Resource/ModalResource';
import Interview from './src/Process/Interview/Interview';
import AddInterview from './src/Process/Interview/AddInterview';
import LeavingScreen from './src/Process/Leaving Organization/Leaving Organization';
import AddLeavingScreen from './src/Process/Leaving Organization/AddLeaving';
import AddJoining from './src/Process/Joining Process/AddJoining';
import Joining from './src/Process/Joining Process/Joining';
import EditLeavingScreen from './src/Process/Leaving Organization/EditLeaving'
import EditInterviewScreen from './src/Process/Interview/EditInterview';
import Splashscreen from './src/constants/SplashScreen';
import Custom from './src/components/DrawerContent';
import NonJoining from './src/Process/Non Joining/Non Joining'
import AddNonJoining from './src/Process/Non Joining/AddNonJoining'
import EditJoining from './src/Process/Joining Process/EditJoining';
import EditNonJoining from './src/Process/Non Joining/EditNonJoining';
import CustomSidebarMenu from './src/components/CustomSidebarMenu';
import InternalInterviewReport from './src/Report/InternalInterviewReport';
import ExternalInterviewReport from './src/Report/ExternalInterviewReport';
import Archive from './src/screens/Resource/Archive';
import NotesView from './src/Process/Interview/NotesView';
import InvoiceStatus from './src/Invoice Master/Invoice Status/InvoiceStatus'
import InvoiceHistory from './src/Invoice Master/Invoice History/InvoiceHistory';
import ExternalProjectInvoiceHistory from './src/Invoice Master/ExternalProjectInvoiceHistory/ExternalProjectInvoiceHistory';
import ExternalProjectInvoiceStatus from './src/Invoice Master/ExternalProjectInvoiceStatus/ExternalProjectInvoiceStatus';
import Active from './src/screens/Resource/Active';
const Stack = createNativeStackNavigator();

const App = () => {
  
  return (

  <NavigationContainer>
      
      <Stack.Navigator
           initialRouteName="Splash"

        screenOptions={{
          headerShown: false,
        }}>
      <Stack.Screen name="Splash" component={Splashscreen} />
      <Stack.Screen name="Drawer Nav" component={DrawerNav}/>

        <Stack.Screen name="LoginScreen" component={Login} />

        <Stack.Screen name="ForgotPasswordScreen" component={ForgotPassword} />
        <Stack.Screen name="HomeScreen" component={Home} />

        <Stack.Screen name="ProjectScreen" component={ProjectTarget} />
        <Stack.Screen name="AddProjectScreen" component={AddProjectTarget} />
        <Stack.Screen
          name="ClientAgreementMasterScreen"
          component={ClientAgreementMaster}
        />
        <Stack.Screen
          name="AddClientAgreementScreen"
          component={AddClientAgreement}
        />
        <Stack.Screen name="AccountMasterScreen" component={AccountMaster} />
        <Stack.Screen name="AddAccountantScreen" component={AddAccountant} />
        <Stack.Screen
          name="TechnologyMasterScreen"
          component={TechnologyMaster}
        />
        <Stack.Screen name="AddTechnologyScreen" component={AddTechnology} />

        <Stack.Screen name="Compare Report" component={CompareReport} />
        <Stack.Screen name="Resource Master" component={ResourceMaster} />
        <Stack.Screen name="Add Resource" component={AddResource} />
     
      
        <Stack.Screen
          name="External Product Master"
          component={ExternalProductMaster}
        />
        <Stack.Screen
          name="Add External Product"
          component={AddExternalProduct}
        />
        <Stack.Screen
          name="Purchase Order Master"
          component={PurchaseOrderMaster}
        />
        <Stack.Screen name="Add Purchase Order" component={AddPurchaseOrder} />
        <Stack.Screen name="Edit Screen" component={EditScreen} />
        <Stack.Screen name=" Vendor Master" component={Vendor} />
        <Stack.Screen name="AddVendor" component={AddVendor} />

        <Stack.Screen name=" User Setting" component={UserSetting} />
        <Stack.Screen name="Client Request" component={ClientRequest} />
        <Stack.Screen name="Edit Technology" component={EditTechnology} />
        <Stack.Screen name="Edit ExternalProduct" component={EditExternalProduct} />
        <Stack.Screen name="Edit Purchase Order" component={EditPurchaseOrder} />
        <Stack.Screen name="Edit Project Target" component={EditProjectTarget} />
        <Stack.Screen name="Edit Client Agreenent" component={EditClientAgreement} />

        <Stack.Screen name="Edit Resource" component={EditResource} />
        <Stack.Screen name="Edit Vendor" component={EditVendor} />
        <Stack.Screen name="Add UserSetting" component={AddUserSetting} />
        <Stack.Screen name="Edit UserSetting" component={EditUserSetting} />
        <Stack.Screen name="UpdateModal" component={UpdateModal} />
        <Stack.Screen name="Client Master" component={ClientMaster} />
        <Stack.Screen name="Setting Master" component={Setting} />
        <Stack.Screen name="Edit Setting" component={EditSetting} />

        <Stack.Screen name="Add Client" component={AddClient} />
        <Stack.Screen name="Edit Client" component={EditClient} />
        <Stack.Screen name="Modal Project" component={ViewModal} />
        <Stack.Screen name="Modal Resource" component={ModalReource} />
        <Stack.Screen name=" Interview" component={Interview} />
        <Stack.Screen name="Add Interview" component={AddInterview} />
        <Stack.Screen name="Leaving Screen" component={LeavingScreen} />
        <Stack.Screen name="Add Leaving" component={AddLeavingScreen} />
        <Stack.Screen name="Joining" component={Joining} />
        <Stack.Screen name="Add Joining" component={AddJoining} />
        <Stack.Screen name="Edit Leaving" component={EditLeavingScreen} />
        <Stack.Screen name="Edit InterviewScreen" component={EditInterviewScreen} />
        <Stack.Screen name="Custom" component={Custom} />
        <Stack.Screen name="NonJoiningScreen" component={NonJoining} />
        <Stack.Screen name="AddNonJoiningScreen" component={AddNonJoining} />
        <Stack.Screen name="Edit Joining" component={EditJoining} />
        <Stack.Screen name="Edit NonJoining" component={EditNonJoining} />
        <Stack.Screen name="CustomSidebarMenu Screen" component={CustomSidebarMenu} />
        <Stack.Screen name="InternalInterviewReport Screen" component={InternalInterviewReport} />
        <Stack.Screen name="ExternalInterviewReport Screen" component={ExternalInterviewReport} />
        <Stack.Screen name="Archive Screen" component={Archive} />
        <Stack.Screen name="Notes Screen" component={NotesView} />
        <Stack.Screen name="Invoice Status" component={InvoiceStatus} />
        <Stack.Screen name="ExternalProjectInvoiceStatus" component={ExternalProjectInvoiceStatus} />
        <Stack.Screen name="InvoiceHistoryScreen" component={InvoiceHistory} />
        <Stack.Screen name="ExternalProjectInvoiceHistory Screen" component={ExternalProjectInvoiceHistory} />


        <Stack.Screen name="ActiveScreen" component={Active}/>
      </Stack.Navigator>
    </NavigationContainer>
    
  );
};

export default App;