import React from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
// import Fontisto from 'react-native-vector-icons/Fontisto'
import {
  createDrawerNavigator,

} from '@react-navigation/drawer';
import ResourceMaster from '../screens/Resource/ResourceMaster';
import TechnologyMaster from '../screens/Technology Master/TechnologyMaster';
import ProjectTarget from '../screens/ProjectTarget/ProjectTarget';
import ExternalProductMaster from '../screens/External Product/ExternalProductMaster';
import PurchaseOrderMaster from '../screens/Purchase Order/PurchaseOrderMaster';
import ClientAgreementMaster from '../screens/Client Agreement Master/ClientAgreementMaster';
import AccountMaster from '../screens/Account Master/AccountMaster';
import Vendor from '../screens/Vendor Master/Vendor';
import Home from '../screens/Home';
import Login from '../screens/Login';
import CompareReport from '../Compare Report/CompareReport'
import UserSetting from '../screens/User Setting/UserSetting';
import ClientRequest from '../screens/Client Request/ClientRequest';
import ClientMaster from '../screens/Client Master/ClientMaster';
import Setting from '../screens/Setting Master/Setting';
import Joining from '../Process/Joining Process/Joining';
import LeavingScreen from '../Process/Leaving Organization/Leaving Organization';
import NonJoining from '../Process/Non Joining/Non Joining';
import InternalInterviewReport from '../Report/InternalInterviewReport';
import ExternalInterviewReport from '../Report/ExternalInterviewReport';
import Archive from '../screens/Resource/Archive';
import InvoiceStatus from '../Invoice Master/Invoice Status/InvoiceStatus';
import InvoiceHistory from '../Invoice Master/Invoice History/InvoiceHistory';
import ExternalProjectInvoiceHistory from '../Invoice Master/ExternalProjectInvoiceHistory/ExternalProjectInvoiceHistory';
import ExternalProjectInvoiceStatus from '../Invoice Master/ExternalProjectInvoiceStatus/ExternalProjectInvoiceStatus';
import Active from '../screens/Resource/Active';
import {
  ImageBackground,
  StyleSheet,
  StatusBar,
  View,
  Text,
  Image,
} from 'react-native';
import Interview from '../Process/Interview/Interview';
import CustomDrawer from './DrawerContent';
const Drawer = createDrawerNavigator();

const DrawerNav = ({ navigation }) => {
  <StatusBar translucent backgroundColor="white" />;

  return (
    <Drawer.Navigator
    drawerPosition="right"

      drawerContent={props => <CustomDrawer {...props}/>}
      screenOptions={{
        
        headerShown: false,
        drawerActiveBackgroundColor: 'lightblue',
        drawerActiveTintColor: 'blue',
        drawerInactiveTintColor: 'black',
        drawerLabelStyle: {
          fontFamily: 'Roboto-Medium',
          fontSize: 15,
                  },
      }}
      
      initialRouteName="LoginScreen"

      >

      <Drawer.Screen
        drawerContent={props => <CustomDrawer {...props} />}

        name="LoginScreen"
        component={Login}

        options={{ headerShown: true, headerTitleAlign: 'center' }}

      />

      <Drawer.Screen
        name="HomeScreen"
        component={Home}
        options={{ headerShown: true, headerTitleAlign: 'center' }}

      />
       <Drawer.Screen
        name="Compare Report"
        component={CompareReport}
        options={{ headerShown: true, headerTitleAlign: 'center' }}

      />
      <Drawer.Screen
        name="Internal Interview Report"
        component={InternalInterviewReport}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerTitleAlign: 'center',
        }}
      />
      <Drawer.Screen
        name="External Interview Report"
        component={ExternalInterviewReport}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerTitleAlign: 'center',
        }}
      />
      <Drawer.Screen
        name="Invoice Status"
        component={InvoiceStatus}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
        }}
      />
      <Drawer.Screen
        name="Invoice History"
        component={InvoiceHistory}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerTitleAlign: 'center',
        }}
      />
      <Drawer.Screen
        name="External Invoice Status"
        component={ExternalProjectInvoiceStatus}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerTitleAlign: 'center',
        }}
      />
      <Drawer.Screen
        name="External Invoice History"
        component={ExternalProjectInvoiceHistory}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerTitleAlign: 'center',
        }}
      />
      <Drawer.Screen
        name="Interview"
        component={Interview}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name={'plus'}
              size={25}
              color="black"
              style={{ marginEnd: '10%', marginTop: '5%', fontWeight: 'bold' }}
              onPress={() => navigation.navigate('Add Interview')}
            />
          ),
        }}
      />
      
      <Drawer.Screen
        name="Joining"
        component={Joining}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name={'plus'}
              size={25}
              color="black"
              style={{ marginEnd: '10%', marginTop: '5%', fontWeight: 'bold' }}
              onPress={() => navigation.navigate('Add Joining')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Leaving"
        component={LeavingScreen}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name={'plus'}
              size={25}
              color="black"
              style={{ marginEnd: '10%', marginTop: '5%', fontWeight: 'bold' }}
              onPress={() => navigation.navigate('Add Leaving')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Non Joining"
        component={NonJoining}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name={'plus'}
              size={25}
              color="black"
              style={{ marginEnd: '10%', marginTop: '5%', fontWeight: 'bold' }}
              onPress={() => navigation.navigate('AddNonJoiningScreen')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Project Target"
        component={ProjectTarget}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{ marginTop: '5%', marginEnd: '10%', fontWeight: 'bold' }}
              onPress={() => navigation.navigate('AddProjectScreen')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Vendor"
        component={Vendor}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{ marginEnd: '10%', marginTop: '5%', fontWeight: 'bold' }}
              onPress={() => navigation.navigate('AddVendor')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Resource"
        component={ResourceMaster}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{ marginEnd: '10%', marginTop: '5%', fontWeight: 'bold' }}
              onPress={() => navigation.navigate('Add Resource')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Archive Resource"
        component={Archive}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
        }}
      />
      <Drawer.Screen
        name="Active Resource"
        component={Active}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
        }}
      />
      {/* <Drawer.Screen
        name="External Resource"
        component={ExternalResourcesMaster}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{ marginEnd: '10%', marginTop: '5%', fontWeight: 'bold' }}
              onPress={() => navigation.navigate('Add External Resource')}
            />
          ),
        }}
      /> */}
      <Drawer.Screen
        name="Client"
        component={ClientMaster}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name={'plus'}
              size={25}
              color="black"
              style={{ marginEnd: '10%', marginTop: '5%', fontWeight: 'bold' }}
              onPress={() => navigation.navigate('Add Client')}
            />
          ),
        }}
      />

      <Drawer.Screen
        name="External Product"
        component={ExternalProductMaster}
        options={{
          headerShown: true,
          swipeEnabled: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{ marginEnd: '10%', marginTop: '5%', fontWeight: 'bold' }}
              onPress={() => navigation.navigate('Add External Product')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Purchase Order"
        component={PurchaseOrderMaster}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{ marginEnd: '10%', marginTop: '5%', fontWeight: 'bold' }}
              onPress={() => navigation.navigate('Add Purchase Order')}
            />
          ),
        }}
      />

      <Drawer.Screen
        name="Client Agreement"
        component={ClientAgreementMaster}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{ marginEnd: '10%', marginTop: '5%', fontWeight: 'bold' }}
              onPress={() => navigation.navigate('AddClientAgreementScreen')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Client Request"
        component={ClientRequest}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              // name={'plus'}
              size={25}
              color="black"
              style={{ marginEnd: '10%', marginTop: '5%', fontWeight: 'bold' }}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Account"
        component={AccountMaster}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{ marginEnd: '10%', marginTop: '5%', fontWeight: 'bold' }}
              onPress={() => navigation.navigate('AddAccountantScreen')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Technology"
        component={TechnologyMaster}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{ marginEnd: '10%', marginTop: '5%', fontWeight: 'bold' }}
              onPress={() => navigation.navigate('AddTechnologyScreen')}
            />
          ),
        }}
      />

      <Drawer.Screen
        name="User Setting"
        component={UserSetting}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{ marginEnd: '10%', marginTop: '5%', fontWeight: 'bold' }}
              onPress={() => navigation.navigate('Add UserSetting')}
            />
          ),
        }}
      />

      <Drawer.Screen
        name="Setting"
        component={Setting}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerTitleAlign: 'center',
        }}
      />
    </Drawer.Navigator>
  );
};

export default DrawerNav;