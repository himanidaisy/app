import React, {useState,useEffect} from 'react';
import {
  View,
  Text,
  ImageBackground,
  Image,
  TouchableOpacity,
  FlatList
} from 'react-native';
import {
  DrawerContentScrollView,
  DrawerItemList,
  DrawerItem
} from '@react-navigation/drawer';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { IMAGES } from '../constants/theme';
import axios from 'axios';
import { URL } from '../constants/configure';

const CustomDrawer = props  => {
  const [newData, setNewData] = useState([]);

  useEffect(() => {
    getResource();
  }, []);

  const getResource = async () => {

    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL+'/user', requestOptions);

      // console.log(data.data.data.users);
      setNewData(data.data.data.users);
    } catch (error) {
      console.log(error);
    }
  };

    return (
      <View style={{flex: 1}}>

        <DrawerContentScrollView
          {...props}
          contentContainerStyle={{backgroundColor: '#8200d6'}}>
          <ImageBackground
            source={IMAGES.menu}
            style={{padding: 20}}>
            <Image
              source={IMAGES.userprofile}
              style={{height: 80, width: 80, borderRadius: 40, marginBottom: 10,alignSelf:'center'}}
            />
            
       {/* <Text
            style={{
              color: '#fff',
              fontSize: 18,
              fontFamily: 'Roboto-Medium',
              marginBottom: 5,
            }}>
          Vinay
          </Text> */}
          
            <Text
            style={{
              color: '#fff',
              fontSize: 18,
              fontFamily: 'Roboto-Medium',
              marginBottom: 5,
              alignSelf:'center'
            }}>{newData.name}</Text>
          </ImageBackground>
      
          <View style={{flex: 1, backgroundColor: '#fff', paddingTop: 10}}>
          {/* <View><Text>Dashboard</Text></View> */}

            <DrawerItemList {...props} />
          </View>
        </DrawerContentScrollView>
      
        <View style={{padding: 2, borderTopWidth: 1, borderTopColor: '#ccc'}}>
        
          <TouchableOpacity onPress={() => props.navigation.navigate('LoginScreen')} style={{paddingVertical: 15}}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <Ionicons name="exit-outline" size={22} style={{marginStart:15}}/>
              <Text
                style={{
                  fontSize: 15,
                  fontFamily: 'Roboto-Medium',
                  marginLeft: 10,
                }}>
                Log Out
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    );
  };
  export default CustomDrawer;
  