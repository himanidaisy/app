import React, { useEffect, useState } from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  ToastAndroid,
  Dimensions,
} from 'react-native';
import { GLOBALSTYLES, COLORS, FONTS } from '../constants/theme';
import SearchBox from '../components/SearchBox';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { URL } from '../constants/configure';
const { height, width } = Dimensions.get('window');

const ExternalInterviewReport = ({ navigation }) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [filterData, setFilterData] = useState([]);
  const [status, setStatus] = useState('');
  const [received, setReceived] = useState('');

  useEffect(() => {
    getInternalInterviewReport();
    getAccountFilterData();
  }, [search, loding, newData]);

  //get

  const getInternalInterviewReport = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      //console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/external-interview-report',
        requestOptions,
      );

      // console.log(data.data.data.technologies);
      setNewData(data.data.data.reports);
      setLoding(false);
    } catch (error) {
      console.log(error);
      setLoding(true);
    }
  };

  const setSearchValue = value => {
    setSearch(value);
  };
  const getAccountFilterData = () => {
    if (!loding) {
      const filterValue = newData?.filter(data => {
        if (search.length === 0) {
          return data;
        } else if (
          data.clients?.client_name
            .toLowerCase()
            .includes(search.toLowerCase()) ||
          data.externalResources?.fname.toLowerCase().includes(search.toLowerCase()) ||
          data.externalResources?.lname.toLowerCase().includes(search.toLowerCase())
        ) {
          // console.log(data);
          return data;
        }
      });
      setFilterData(filterValue);
    }
  };
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <SearchBox search={search} setSearchValue={setSearchValue} />
      {loding ? (
        <ActivityIndicator
          animating={true}
          size="large"
          style={{
            opacity: 1,
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        />
      ) : (
        <FlatList
          data={filterData}
          renderItem={({ item }) => (
            <View style={GLOBALSTYLES.appContainer}>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Resource Name</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.externalResources === null
                      ? '-'
                      : `${item.externalResources.fname} ${item.externalResources.lname}`}
                  </Text>
                </View>
              </View>
              <View style={{ flexDirection: 'row' }}>
                <View style={{ flexDirection: 'column', flex: 1 }}>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Total Interview</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.totalInterview === null ? '-' : item.totalInterview}
                    </Text>
                  </View>

                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Selected</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.interview_status === null ? '-' : item.interview_status}
                    
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Rejected</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.interview_status === null ? '-' : item.interview_status}
                    
                    </Text>
                  </View>
                </View>

                <View style={{ flexDirection: 'column', flex: 0.5, top: 10 }}>
                  <Text style={GLOBALSTYLES.lebal}>Hold</Text>

                  <Text style={GLOBALSTYLES.content}>
                    {item.interview_status === null ? '-' : item.interview_status}
                  </Text>

                  </View>
              </View>
              <View style={{ flexDirection: 'row' }}>
                <View style={{ flexDirection: 'column', flex: 1 }}>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Last Interview</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.datetime === null ? '-' : item.datetime}
                    </Text>
                  </View>

                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Received Question</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.receive_question === null ? '-' : item.receive_question}
                      
                    </Text>
                  </View>
                </View>
              </View>

             
            </View>
          )}
        />
      )}
    </SafeAreaView>
  );
};

export default ExternalInterviewReport;