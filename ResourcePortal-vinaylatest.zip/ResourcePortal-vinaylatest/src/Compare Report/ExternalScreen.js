import React, {useState} from 'react';
import {
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import SearchBox from '../components/SearchBox';
// import DateTimePicker from '@react-native-community/datetimepicker';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Icon from 'react-native-vector-icons/FontAwesome';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { GLOBALSTYLES, COLORS } from '../constants/theme'; 
import DatePicker from 'react-native-datepicker';

const {height, width} = Dimensions.get('window');
const ExternalScreen = () => {
  return (
    <SafeAreaView>
      <ScrollView>
        <View style={styles.infocontainer}>
          <Text style={{marginStart: 20, marginTop: 10, fontSize: 16}}>
            Resources Name
          </Text>
          <View style={{padding: 10}}>
            <Text style={GLOBALSTYLES.content}> Shwetali Sangle</Text>
          </View>
          <View style={{padding: 10}}>
            <View style={styles.textStyle}>
              <Text style={{color: 'black', fontSize: 15}}>
                Total Interview
              </Text>
              <Text style={{color: 'black', fontSize: 15}}> 200/450 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={{color: 'black', fontSize: 15}}> Selected </Text>
              <Text style={{color: 'black', fontSize: 15}}> 200/450 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={{color: 'black', fontSize: 15}}> Rejected </Text>
              <Text style={{color: 'black', fontSize: 15}}> 200/450 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={{color: 'black', fontSize: 15}}> Hold </Text>
              <Text style={{color: 'black', fontSize: 15}}> 200/450 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={{color: 'black', fontSize: 15}}>
                {' '}
                Last Interview{' '}
              </Text>
              <Text style={{color: 'black', fontSize: 15}}> 21 May 2021 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={{color: 'black', fontSize: 15}}>
                {' '}
                Review Question{' '}
              </Text>
              <Text style={{color: 'black', fontSize: 15}}> 200/450 </Text>
            </View>
          </View>
        </View>
        <View style={styles.infocontainer}>
          <Text style={{marginStart: 20, marginTop: 10, fontSize: 16}}>
            Resources Name
          </Text>
          <View style={{padding: 10}}>
            <Text style={GLOBALSTYLES.content}> Shwetali Sangle</Text>
          </View>
          <View style={{padding: 10}}>
            <View style={styles.textStyle}>
              <Text style={{color: 'black', fontSize: 15}}>
                Total Interview
              </Text>
              <Text style={{color: 'black', fontSize: 15}}> 200/450 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={{color: 'black', fontSize: 15}}> Selected </Text>
              <Text style={{color: 'black', fontSize: 15}}> 200/450 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={{color: 'black', fontSize: 15}}> Rejected </Text>
              <Text style={{color: 'black', fontSize: 15}}> 200/450 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={{color: 'black', fontSize: 15}}> Hold </Text>
              <Text style={{color: 'black', fontSize: 15}}> 200/450 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={{color: 'black', fontSize: 15}}>
                {' '}
                Last Interview{' '}
              </Text>
              <Text style={{color: 'black', fontSize: 15}}> 21 May 2021 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={{color: 'black', fontSize: 15}}>
                {' '}
                Review Question{' '}
              </Text>
              <Text style={{color: 'black', fontSize: 15}}> 200/450 </Text>
            </View>
          </View>
        </View>
        <View style={styles.infocontainer}>
          <View style={{padding: 10}}></View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  numberText: {
    color: 'darkorange',
    fontSize: 40,
    fontWeight: 'bold',
    marginStart: 20,
    marginTop: 10,
  },
  titleText: {
    fontSize: 20,
    color: 'grey',
    marginStart: 20,
  },
  rtitleText: {
    fontSize: 18,
    color: 'grey',
    marginStart: 20,
  },
  contractboxtitleText: {
    color: COLORS.pureWhite,
    fontWeight: 'bold',
    fontSize: 17,
    marginStart: width / 4,
  },
  inumberText: {
    color: 'skyblue',
    fontSize: 40,
    fontWeight: 'bold',
    marginStart: 20,
    marginTop: 10,
  },
  viewcontainer: {
    flex: 1,
    backgroundColor: 'white',
    borderRadius: 10,
    marginTop: 15,
    marginStart: 20,
  },
  infocontainer: {
    borderRadius: 10,

    marginStart: 20,
    marginTop: 10,
    backgroundColor: COLORS.pureWhite,
  },
  boxcontainer: {
    borderRadius: 10,
    marginHorizontal: 20,

    marginTop: 10,
    backgroundColor: COLORS.pureWhite,
  },
  boxcontainerstyle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: 'skyblue',
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  projectboxcontainerstyle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: 'skyblue',
    borderRadius: 10,
  },
  boxtitleText: {
    color: COLORS.pureWhite,
    fontWeight: 'bold',
    fontSize: 17,
  },
  textStyle: {
    flexDirection: 'row',
    padding: '3%',
    justifyContent: 'space-between',
  },

  rnumberText: {
    color: 'black',
    fontSize: 18,
    fontWeight: 'bold',
    marginStart: 20,
  },
});

export default ExternalScreen;