import React, { useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Dimensions,
  _View,
} from 'react-native';
import SearchBox from '../components/SearchBox';
// import DateTimePicker from '@react-native-community/datetimepicker';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import DatePicker from 'react-native-datepicker';
import { GLOBALSTYLES, FONTS, COLORS } from '../constants/theme';
import InternalScreen from './InternalScreen';
import ExternalScreen from './ExternalScreen';

const { height, width } = Dimensions.get('window');

const CompareReport = () => {
  const [change, setChange] = useState(false);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const handleChange = () => {
    setChange(true);
  };
  const handleChange2 = () => {
    !setChange();
  };

  return (
    <SafeAreaView>
      <ScrollView>
        <View style={{ flexDirection: 'row', margin: 20, bottom: 10 }}>
          <View style={styles.inbtn}>
            <TouchableOpacity onPress={handleChange2}>
              <Text style={styles.inbtntext}>Internal</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.exbtn}>
            <TouchableOpacity onPress={handleChange}>
              <Text style={styles.exbtntext}>External</Text>
            </TouchableOpacity>
          </View>
        </View>
        <View style={{ bottom: 30 }}>
          <SearchBox />
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', bottom: 30 }}>
          <TouchableOpacity
            style={{
              width: width / 2.5,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              justifyContent: 'space-between',
              backgroundColor: COLORS.pureWhite,
              marginStart: 20,
              borderRadius: 10,
            }}>
            <DatePicker
              style={{ width: '100%', top: 7 }}
              date={startDate}
              value={startDate}
              mode="date"
              placeholder="Start Date"
              format="DD MMMM YYYY"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              showIcon={false}
              customStyles={{
                dateInput: {
                  borderWidth: 0,

                  position: 'absolute',
                  left: 20,
                  fontSize:14,
                },
              }}
              onDateChange={startDate => {
                setStartDate(startDate);
              }}
            />
            <FontAwesome
              name="calendar-o"
              size={20}
              style={{ alignSelf: 'center', right: 30 }}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              width: width / 2.5,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              justifyContent: 'space-between',
              backgroundColor: COLORS.pureWhite,
              right: 15,
              borderRadius: 10,
            }}>
            <DatePicker
              style={{ width: '100%', top: 7 }}
              date={endDate}
              value={endDate}
              mode="date"
              placeholder="End Date"
              minDate={startDate}
              format="DD MMMM YYYY"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              showIcon={false}
              customStyles={{
                dateInput: {
                  borderWidth: 0,

                  position: 'absolute',
                  left: 20,
                  fontSize:14,
                },
              }}
              onDateChange={endDate => {
                setEndDate(endDate);
              }}
            />
            <FontAwesome
              name="calendar-o"
              size={20}
              style={{ alignSelf: 'center', right: 30 }}
            />
          </TouchableOpacity>
        </View>
        <TouchableOpacity
          style={{
            height: height / 14,
            width: width - 40,
            borderRadius: 10,
            alignSelf: 'center',
            bottom: 25,
            backgroundColor: COLORS.skyBlue,
            position: 'relative',
          }}>
          <Text style={{
            alignSelf: 'center',
            fontSize:17,
             top: 16,
            color: COLORS.pureWhite,
            fontWeight: 'bold',
          }}>Submit</Text>
        </TouchableOpacity>
        <View>{change ? <ExternalScreen /> : <InternalScreen />}</View>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  inbtn: {
    width: width / 2.15,
    backgroundColor: 'skyblue',
    height: height / 14,
    borderRadius: 10,
  },
  inbtnn: {
    width: width / 2.4,
    backgroundColor: 'white',
    height: height / 14,
    position: 'relative',
    left: 5,
  },
  inbtntext: {
    fontSize: 17,
    color: 'white',
    position: 'relative',
    textAlign: 'center',
    top: 18
  },
  exbtntext: {
    fontSize: 17,
    color: 'skyblue',
    position: 'relative',
    textAlign: 'center',
    top: 18,
  },
  exbtn: {
    width: width / 2.4,
    backgroundColor: 'white',
    height: height / 14,
    borderRadius: 10,
    position: 'relative',
    left: 8,
  },
  numberText: {
    color: 'darkorange',
    fontSize: 40,
    fontWeight: 'bold',
    marginStart: 20,
    marginTop: 10,
  },
  titleText: {
    fontSize: 20,
    color: 'grey',
    marginStart: 20,
  },
  rtitleText: {
    fontSize: 18,
    color: 'grey',
    marginStart: 20,
  },
  contractboxtitleText: {
    color: COLORS.pureWhite,
    fontWeight: 'bold',
    fontSize: 17,
    marginStart: width / 4,
  },
  inumberText: {
    color: 'skyblue',
    fontSize: 40,
    fontWeight: 'bold',
    marginStart: 20,
    marginTop: 10,
  },
  viewcontainer: {
    flex: 1,
    backgroundColor: 'white',
    borderRadius: 10,
    marginTop: 15,
    marginStart: 20,
  },
  infocontainer: {
    borderRadius: 10,

    marginStart: 20,
    marginTop: 10,
    backgroundColor: COLORS.pureWhite,
  },
  boxcontainer: {
    borderRadius: 10,
    marginHorizontal: 20,

    marginTop: 10,
    backgroundColor: COLORS.pureWhite,
  },
  boxcontainerstyle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: 'skyblue',
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  projectboxcontainerstyle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: 'skyblue',
    borderRadius: 10,
  },
  boxtitleText: {
    color: COLORS.pureWhite,
    fontWeight: 'bold',
    fontSize: 17,
  },
  textStyle: {
    flexDirection: 'row',
    padding: '3%',
    justifyContent: 'space-between',
  },

  rnumberText: {
    color: 'black',
    fontSize: 18,
    fontWeight: 'bold',
    marginStart: 20,
  },
});

export default CompareReport;