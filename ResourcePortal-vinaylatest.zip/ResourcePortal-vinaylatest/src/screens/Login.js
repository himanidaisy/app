import {
  Text,
  View,
  SafeAreaView,
  Image,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Dimensions,
  ActivityIndicator
} from 'react-native';
import { COLORS, IMAGES, FONTS } from '../constants/theme';
import { Formik } from 'formik';
import * as yup from 'yup';
import React, { useState } from 'react';
import Entypo from 'react-native-vector-icons/Entypo';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { URL } from '../constants/configure';
import Toast from 'react-native-simple-toast';

const { height, width } = Dimensions.get('window');
const Login = ({ navigation }) => {
  const [show, setShow] = useState(false);
  const [visible, setVisible] = useState(true);
  const [loading, setLoading] = useState(false);
  const loginValidationSchema = yup.object().shape({
    email: yup
      .string()
      .email('Please enter valid email')
      .required('Please fill this filed'),
    password: yup
      .string()
      .min(8, ({ min }) => `Password must be at least ${min} characters`)
      .required('Please fill this filed'),
  });
  const postUser = async values => {
    console.log(values)

    try {
      const { data } = await axios.post(URL.BASE_URL + '/auth/signIn', values);

      console.log(data)
      if (data.message) {
        // ToastAndroid.showWithGravity(
        //   'Login successfully',
        //   ToastAndroid.SHORT,
        //   ToastAndroid.BOTTOM,
        // );
        Toast.showWithGravity('Login successfully', Toast.LONG, Toast.BOTTOM);

        await AsyncStorage.setItem('token', data.token);

      }
      navigation.navigate('HomeScreen');
    } catch (err) {
      // ToastAndroid.showWithGravity(
      //   'Please check user email and password',
      //   ToastAndroid.SHORT,
      //   ToastAndroid.BOTTOM,
      // );
      console.log('catch', err)
      Toast.showWithGravity('Please check user email and password', Toast.LONG, Toast.BOTTOM);

    }
  };
  const handleSubmit = values => {
    postUser(values);
  };
  const loadButton = () => {
    setLoading(!loading);
    setTimeout(() => {
      setLoading(false);
    }, 2000);
  };

  return (
    <SafeAreaView style={styles.mainContainer}>
      <View style={styles.container}>
        <ScrollView style={styles.ScrollViewStyle}>
          <View style={styles.ImageView}>
            <Image source={IMAGES.nimaplogo} style={styles.ImageStyle} />
          </View>
          <View style={styles.loginContainer}>
            <Formik
              validationSchema={loginValidationSchema}
              initialValues={{ email: '', password: '' }}
              onSubmit={handleSubmit}>
              {({
                handleChange,
                handleBlur,
                handleSubmit,
                errors,
                values,
                isValid,
                touched,
              }) => (
                <>
                  <View style={styles.textInputStyle}>
                    <TextInput
                      placeholder="User Name"
                      style={styles.textInput}
                      onChangeText={handleChange('email')}
                      onBlur={handleBlur('email')}
                      keyboardType="default"
                      maxLength={40}
                    />
                  </View>
                  {errors.email && touched.email && (
                    <Text style={styles.errorText}>{errors.email}</Text>
                  )}

                  <View style={styles.textInputStyle}>
                    <TextInput
                      placeholder="Password"
                      style={styles.textInput}
                      onChangeText={handleChange('password')}
                      onBlur={handleBlur('password')}
                      secureTextEntry={visible}
                      maxLength={15}
                    />
                    <TouchableOpacity
                      style={styles.btnStyle}
                      onPress={() => {
                        setShow(!show);
                        setVisible(!visible);
                      }}>
                      <Entypo
                        name={show === true ? 'eye' : 'eye-with-line'}
                        size={26}
                        color={COLORS.grey}
                      />
                    </TouchableOpacity>
                  </View>

                  {errors.password && touched.password && (
                    <Text style={{   color: COLORS.red,
                      bottom:10,
                      right:'10%'}}>{errors.password}</Text>
                  )}
                  <TouchableOpacity
                    onPress={() => navigation.navigate('ForgotPasswordScreen')}>
                    <Text style={styles.forgotStyle}>Forgot Password?</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={styles.buttonStyle}
                    onPress={() => {
                      handleSubmit();
                      loadButton();
                    }}
                    disabled={!isValid}>
                    {loading ? (
                      <ActivityIndicator animating={loading} color="white" style={{top:15}}/>
                    ) : (
                      <Text style={styles.textStyle}>Login</Text>
                    )}
                  </TouchableOpacity>
                </>
              )}
            </Formik>
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  ImageView: {
    width: width / 2,
    alignSelf: 'center',
    height: height / 3.5,
    justifyContent: 'center',
    marginVertical: 20,
  },
  ImageStyle: {
    alignSelf: 'center',
  },
  loginContainer: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: 'white',
    margin: 10,
    backgroundColor: COLORS.white,
  },
  textInputStyle: {
    backgroundColor: "white",
    borderRadius: 10,
    width: "95%",
    height: 55,
    marginBottom: 20,
    alignItems: "center"
  },
  textInput: {
    flex: 1,
    width: "95%",
    
  },
  buttonStyle: {
    backgroundColor: COLORS.blue,
    borderRadius: 10,
    width: "95%",
    height: 55,
    marginBottom: 20,
    alignItems: "center",
    top:30
  },
  textStyle: {
    height: 50,
    flex: 1,
    padding: 10,
    top:8,
    fontWeight:'bold',
    color:'white'
   },
  forgotStyle: {
    fontSize: 14,
    position: 'absolute',
    left: '14%',
  },
  errorText: {
    color: COLORS.red,
    bottom:10,
    right:'27%'
  },
  btnStyle: {
    position: 'absolute',
    marginTop: '5%',
    right: '5%',
    
  },
});

export default Login;