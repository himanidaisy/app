import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  Dimensions,
  TouchableOpacity,
  ToastAndroid,
} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import { dpforHeight, dpforWidth } from '../../constants/SizeScreen';
import moment from 'moment';
import { URL } from '../../constants/configure';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import DatePicker from 'react-native-datepicker';
import { COLORS, GLOBALSTYLES, FONTS } from '../../constants/theme';
import EmailIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import { Picker } from '@react-native-picker/picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { Formik } from 'formik';
import * as yup from 'yup';
import { Button } from 'react-native-paper';
const { height, width } = Dimensions.get('window');

const AddResource = ({ navigation }) => {
  const [newData, setNewData] = useState([]);
  const [technologys, setTechnologys] = useState([]);
  const [extern, setExtern] = useState([]);
  const [venders, setVendors] = useState([]);

  useEffect(() => {
    getResource();
    getTechnology();
    getExternal();
    getVendor();
  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/resource', requestOptions);

      // console.log(data.data.data.resources);

      setNewData(data.data.data.resources);
    } catch (error) {
      console.log(error);
    }
  };
  const getTechnology = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      // console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/technology',
        requestOptions,
      );

      // console.log(data.data.data.externalResource);

      setTechnologys(data.data.data.technologies);
    } catch (error) {
      console.log(error);
    }
  };

  const getExternal = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/external-resource',
        requestOptions,
      );

      // console.log(data.data.data.resources);

      setExtern(data.data.data.externalResource);
    } catch (error) {
      console.log(error);
    }
  };

  //post api

  const postUser = async values => {
    // const exp_date = calculateStringToDate(values?.exp_date)
    // const {...other} = values
    values["languages"] = values.languages.toString()

    values["otherlanguages"] = values.otherlanguages.toString()
    console.log('vinay-------->', values);


    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      const { languages, otherlanguages, ...other } = values
      const { data } = await axios.post(
        URL.BASE_URL + '/resource',
        { ...other, language: languages, otherlanguage: otherlanguages }, requestOptions

      );
      console.log('check-------------->', data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Resource Data Added Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
      navigation.goBack();


    } catch (err) {
      console.log(err.response);
      ToastAndroid.showWithGravity(
        'Resource Data Not Added Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }

  };
  const handleSubmit = values => {

    postUser(values);

    console.log('values-------', values);
  };
  const getVendor = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/vendor', requestOptions);

      // console.log(data.data.data.externalResource);

      setVendors(data.data.data.vendors);
    } catch (error) {
      console.log(error);
    }
  };


  const technologyCheck = technologys.filter(t => t.technologies !== null);
  const clientsVendor = venders.filter(t => t.company_name !== null);
  const phoneRegExp =
    /^(\+91)?(-)?\s*?(91)?\s*?(\d{3})-?\s*?(\d{3})-?\s*?(\d{4})$/;
  const nameReg = /^[^-\s][a-zA-Z\s-]+$/;
  const pdf = /(http(s?)):\/\//i
  const number = /^[0-9]*$/
  const loginValidationSchema = yup.object().shape({
    vendor_id: yup.string().required('These field is Required'),
    fname: yup.string().matches(nameReg, 'Please enter a valid name').required('These field is Required'),
    lname: yup.string().matches(nameReg, 'Please enter a valid name').required('These field is Required'),
    phone: yup.string().matches(phoneRegExp, 'Please enter a valid number').required('These field is Required'),
    email: yup.string().email('Email is not valid').required('These field is Required'),
    personal_email: yup.string().email('Email is not valid').required('These field is Required'),
    project: yup.string().matches(nameReg, 'Please enter a valid name').required('These field is Required'),
    languages: yup.array().nullable(),
    otherlanguages: yup.array().nullable(),
    exp_date: yup.date().required('These field is Required'),
    resident_address: yup.string().required('These field is Required'),
    resume: yup.string().matches(pdf, 'Please enter a valid link').required('These field is Required'),
    contract_file: yup.string().matches(pdf, 'Please enter a valid link').required('These field is Required'),
    contract_start_date: yup.string().required('These field is Required'),
    contract_end_date: yup.string().required('These field is Required'),
    checklist: yup.string().matches(pdf, 'Please enter a valid link').required('These field is Required'),
    other_docs: yup.string().matches(pdf, 'Please enter a valid link').required('These field is Required'),
    passing_year: yup.string().matches(number, 'Please enter a valid passing year').required('These field is Required'),
    pan_link: yup.string().matches(pdf, 'Please enter a valid link').required('These field is Required'),
    pf_opt_out_form_link: yup.string().matches(pdf, 'Please enter a valid pdf').required('These field is Required'),
    l1: yup.string().required('These field is Required'),
    cost: yup.string().matches(number, 'Please enter a valid cost').required('These field is Required'),
    alternate_no: yup.string().matches(phoneRegExp, 'Please enter a valid number').required('These field is Required'),
    relationship: yup.string().required('These field is Required')

  });
  const calculateStringToDate = (yearOfExp) => {
    const monthsBack = +yearOfExp.split(" ")[0] * 12;
    const exp = new Date(moment().subtract(monthsBack, "months"));
    return moment(exp).format("YYYY-MM-DD");
  };
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Resource" />
      <Formik
        validationSchema={loginValidationSchema}
        initialValues={{
          "vendor_id": "",
          "fname": "",
          "lname": "",
          "phone": "",
          "email": "",
          "personal_email": "",
          "project": "",
          "languages": [],
          "otherlanguages": [],
          "exp_date": "",
          "resident_address": "",
          "resume": "",
          "contract_file": "",
          "contract_start_date": "",
          "contract_end_date": "",
          "checklist": "",
          "other_docs": "",
          "passing_year": "",
          "pan_link": "",
          "pf_opt_out_form_link": "",
          "l1": "",
          "cost": "",
          "alternate_no": "",
          "relationship": "",

        }}
        onSubmit={values => {
          handleSubmit(values);
        }}
      >
        {({
          handleChange,
          handleBlur,
          handleSubmit,
          errors,
          touched,
          values,
          setFieldValue
        }) => (
          <>
            <View style={{ height: height / 1.2 }}>{
              console.log('values', values, errors)
            }
              <ScrollView>
                <View style={{ height: height / 0.3 }}>

                  <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      selectedValue={values.vendor_id}
                      style={{ margin: 5 }}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('vendor_id', itemValue)
                      )}>
                      <Picker.Item label="Vendor List*" value="" color="grey" />

                      {clientsVendor.map((item, index) => (
                        <Picker.Item
                          key={item.id}
                          label={item.company_name}
                          value={item.id}
                        />
                      ))}
                    </Picker>
                  </View>
                  {errors.vendor_id && touched.vendor_id && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.vendor_id}</Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="First Name*"
                      value={values.fname}
                      style={GLOBALSTYLES.textInput}
                      maxLength={25}
                      keyboardType="default"
                      onChangeText={handleChange('fname')}
                      onBlur={handleBlur('fname')}
                    />
                  </View>
                  {errors.fname && touched.fname && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.fname}
                    </Text>
                  )}

                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Last Name*"
                      value={values.lname}
                      style={GLOBALSTYLES.textInput}
                      maxLength={25}
                      keyboardType="default"
                      onChangeText={handleChange('lname')}
                      onBlur={handleBlur('lname')}
                    />
                  </View>
                  {errors.lname && touched.lname && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.lname}
                    </Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 12,

                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <FontAwesome
                        name="phone"
                        size={25}
                        style={{ right: 12, marginStart: 20 }}
                      />
                    </View>
                    <TextInput
                      placeholder="Phone Number*"
                      value={values.phone}
                      style={GLOBALSTYLES.textInput}
                      maxLength={10}
                      keyboardType='phone-pad'
                      onChangeText={handleChange('phone')}
                      onBlur={handleBlur('phone')}

                    />
                  </View>
                  {errors.phone && touched.phone && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.phone}
                    </Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 12,

                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <FontAwesome
                        name="phone"
                        size={25}
                        style={{ right: 12, marginStart: 20 }}
                      />
                    </View>
                    <TextInput
                      placeholder="Alternate Number*"
                      style={GLOBALSTYLES.textInput}
                      maxLength={10}
                      value={values.alternate_no}
                      keyboardType='phone-pad'
                      onChangeText={handleChange('alternate_no')}
                      onBlur={handleBlur('alternate_no')}

                    />
                  </View>
                  {errors.alternate_no && touched.alternate_no && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.alternate_no}
                    </Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 8,
                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <EmailIcon
                        name="email-outline"
                        size={25}
                        style={{ right: 12, marginStart: 20 }}
                      />
                    </View>
                    <TextInput
                      placeholder="Personal Email Id*"
                      style={GLOBALSTYLES.textInput}
                      value={values.personal_email}
                      maxLength={45}
                      keyboardType='email-address'
                      onChangeText={handleChange('personal_email')}
                      onBlur={handleBlur('personal_email')}

                    />
                  </View>
                  {errors.personal_email && touched.personal_email && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.personal_email}
                    </Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 8,
                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <EmailIcon
                        name="email-outline"
                        size={25}
                        style={{ right: 12, marginStart: 20 }}
                      />
                    </View>
                    <TextInput
                      placeholder="Official Email Id"
                      style={GLOBALSTYLES.textInput}
                      maxLength={45}
                      value={values.email}
                      keyboardType='email-address'
                      onChangeText={handleChange('email')}
                      onBlur={handleBlur('email')}

                    />
                  </View>
                  {errors.email && touched.email && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.email}
                    </Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10,
                    }}>
                    <Picker
                      selectedValue={values.languages}
                      style={{ margin: 5 }}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('languages', itemValue)
                      )}>
                      <Picker.Item label="Primary Skill*" value="" color="grey" />

                      {technologyCheck.map((item, index) => (
                        <Picker.Item
                          key={item.id}
                          label={item.technology}
                          value={item.id}
                        />
                      ))}
                    </Picker>
                  </View>
                  {errors.languages && touched.languages && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.languages}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      selectedValue={values.otherlanguages}
                      style={{ margin: 5 }}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('otherlanguages', itemValue)
                      )}>
                      <Picker.Item
                        label="Secondary Skill*"
                        value=""
                        color="grey"
                      />

                      {technologyCheck.map((item, index) => (
                        <Picker.Item
                          key={item.id}
                          label={item.technology}
                          value={item.id}
                        />
                      ))}
                    </Picker>
                  </View>
                  {errors.otherlanguages && touched.otherlanguages && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.otherlanguages}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      style={{ margin: 5 }}
                      selectedValue={values.relationship}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('relationship', itemValue)
                      )}>
                      <Picker.Item
                        label="Relationship*"
                        value=""
                        color="grey"
                      />
                      <Picker.Item label="Father" value="Father" />
                      <Picker.Item label="Mother" value="Mother" />
                      <Picker.Item label="Brother" value="Brother" />
                      <Picker.Item label="Sister" value="Sister" />
                    </Picker>
                  </View>
                  {errors.relationship && touched.relationship && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.relationship}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Resume Link*"
                      value={values.exp_date}
                      style={GLOBALSTYLES.textInput}
                      keyboardType='numeric'
                      maxLength={10}
                      onChangeText={handleChange('exp_date')}
                      onBlur={handleBlur('exp_date')}

                    />
                  </View>
                  {errors.exp_date && touched.exp_date && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.exp_date}
                    </Text>
                  )}
                  {/* <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      style={{ margin: 5 }}
                      selectedValue={values.exp_date}
                      mode="dropdown"
                      
                      onValueChange={(itemValue) => (
                        setFieldValue('exp_date', itemValue)
                      )}>
                      <Picker.Item
                        label="Experience Year*"
                        value=""
                        color="grey"
                      />
                      <Picker.Item label="0.5 year" value="0.5 year" />
                      <Picker.Item label="1 year" value="1 year" />
                      <Picker.Item label="1.5 year" value="1.5 year" />
                      <Picker.Item label="2 year" value="2 year" />
                      <Picker.Item label="2.5 year" value="2.5 year" />
                      <Picker.Item label="3 year" value="3 year" />
                      <Picker.Item label="3.5 year" value="3.5 year" />
                      <Picker.Item label="4 year" value="4 year" />
                      <Picker.Item label="4.5 year" value="4.5 year" />
                      <Picker.Item label="5 year" value="5 year" />
                      <Picker.Item label="5.5 year" value="5.5 year" />
                      <Picker.Item label="6 year" value="6 year" />
                      <Picker.Item label="6.5 year" value="6.5 year" />
                      <Picker.Item label="7 year" value="7 year" />
                      <Picker.Item label="7.5 year" value="7.5 year" />
                      <Picker.Item label="8 year" value="8 year" />
                      <Picker.Item label="8.5 year" value="8.5 year" />
                      <Picker.Item label="9 year" value="9 year" />
                      <Picker.Item label="9.5 year" value="9.5 year" />
                      <Picker.Item label="10 year" value="10 year" />
                      <Picker.Item label="10.5 year" value="10.5 year" />
                      <Picker.Item label="11 year" value="11 year" />
                      <Picker.Item label="11.5 year" value="11.5 year" />
                      <Picker.Item label="12 year" value="12 year" />
                      <Picker.Item label="12.5 year" value="12.5 year" />
                    </Picker>
                  </View>
                  {errors.exp_date && touched.exp_date && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.exp_date}
                    </Text>
                  )} */}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10,
                    }}>
                    <TextInput
                      placeholder="Locality*"
                      style={{
                        marginHorizontal: 20,
                        ...FONTS.appFontSemiBold,

                        marginTop: 1,
                      }}
                      maxLength={200}
                      value={values.resident_address}
                      onChangeText={handleChange('resident_address')}
                      onBlur={handleBlur('resident_address')}

                    />
                  </View>
                  {errors.resident_address && touched.resident_address && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.resident_address}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Resume Link*"
                      value={values.resume}
                      style={GLOBALSTYLES.textInput}
                      keyboardType="default"
                      maxLength={200}
                      onChangeText={handleChange('resume')}
                      onBlur={handleBlur('resume')}

                    />
                  </View>
                  {errors.resume && touched.resume && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.resume}
                    </Text>
                  )}
                  <TouchableOpacity
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <DatePicker
                      date={values.contract_start_date}
                      style={{ width: '100%', top: 7 }}
                      mode="date"
                      placeholder="Contract Start Date"
                      format="DD MMMM YYYY"
                      confirmBtnText="Confirm"
                      cancelBtnText="Cancel"
                      showIcon={false}
                      customStyles={{
                        dateInput: {
                          borderWidth: 0,

                          position: 'absolute',
                          left: 20,
                          ...FONTS.appFontSemiBold,
                        },
                      }}
                      onDateChange={(itemValue) => (
                        setFieldValue('contract_start_date', itemValue)
                      )}
                    />
                    <FontAwesome
                      name="calendar-o"
                      size={20}
                      style={{ alignSelf: 'center', right: 30 }}
                    />
                  </TouchableOpacity>
                  {errors.contract_start_date && touched.contract_start_date && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.contract_start_date}</Text>
                  )}
                  <TouchableOpacity
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <DatePicker
                      date={values.contract_end_date}
                      style={{ width: '100%', top: 7 }}
                      mode="date"
                      placeholder="Contract End Date"
                      format="DD MMMM YYYY"
                      minDate={values.contract_start_date}
                      confirmBtnText="Confirm"
                      cancelBtnText="Cancel"
                      showIcon={false}
                      customStyles={{
                        dateInput: {
                          borderWidth: 0,

                          position: 'absolute',
                          left: 20,
                          ...FONTS.appFontSemiBold,
                        },
                      }}
                      onDateChange={(itemValue) => (
                        setFieldValue('contract_end_date', itemValue)
                      )}
                    />
                    <FontAwesome
                      name="calendar-o"
                      size={20}
                      style={{ alignSelf: 'center', right: 30 }}
                    />
                  </TouchableOpacity>
                  {errors.contract_end_date && touched.contract_end_date && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.contract_end_date}</Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Contract File Link"
                      style={GLOBALSTYLES.textInput}
                      keyboardType="default"
                      value={values.contract_file}
                      maxLength={200}
                      onChangeText={handleChange('contract_file')}
                      onBlur={handleBlur('contract_file')}

                    />
                  </View>
                  {errors.contract_file && touched.contract_file && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.contract_file}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Checklist Drive Link"
                      style={GLOBALSTYLES.textInput}
                      value={values.checklist}
                      keyboardType="default"
                      maxLength={200}
                      onChangeText={handleChange('checklist')}
                      onBlur={handleBlur('checklist')}

                    />
                  </View>
                  {errors.checklist && touched.checklist && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.checklist}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Other Documents"
                      style={GLOBALSTYLES.textInput}
                      keyboardType="default"
                      value={values.other_docs}
                      maxLength={200}
                      onChangeText={handleChange('other_docs')}
                      onBlur={handleBlur('other_docs')}

                    />
                  </View>
                  {errors.other_docs && touched.other_docs && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.other_docs}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Passing Year*"
                      style={GLOBALSTYLES.textInput}
                      keyboardType='numeric'
                      value={values.passing_year}
                      maxLength={4}
                      onChangeText={handleChange('passing_year')}
                      onBlur={handleBlur('passing_year')}

                    />
                  </View>
                  {errors.passing_year && touched.passing_year && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.passing_year}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="PAN Link*"
                      style={GLOBALSTYLES.textInput}
                      keyboardType="default"
                      value={values.pan_link}
                      maxLength={200}
                      onChangeText={handleChange('pan_link')}
                      onBlur={handleBlur('pan_link')}

                    />
                  </View>
                  {errors.pan_link && touched.pan_link && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.pan_link}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Pf Opt Out Form Link*"
                      style={GLOBALSTYLES.textInput}
                      keyboardType="default"
                      value={values.pf_opt_out_form_link}
                      maxLength={200}
                      onChangeText={handleChange('pf_opt_out_form_link')}
                      onBlur={handleBlur('pf_opt_out_form_link')}

                    />
                  </View>
                  {errors.pf_opt_out_form_link && touched.pf_opt_out_form_link && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.pf_opt_out_form_link}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Project"
                      style={GLOBALSTYLES.textInput}
                      keyboardType="default"
                      maxLength={25}
                      value={values.project}
                      onChangeText={handleChange('project')}
                      onBlur={handleBlur('project')}

                    />
                  </View>
                  {errors.project && touched.project && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.project}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Cost*"
                      style={GLOBALSTYLES.textInput}
                      keyboardType='numeric'
                      maxLength={5}
                      value={values.cost}
                      onChangeText={handleChange('cost')}
                      onBlur={handleBlur('cost')}

                    />
                  </View>
                  {errors.cost && touched.cost && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.cost}
                    </Text>
                  )}

                  <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      style={GLOBALSTYLES.textInput}
                      selectedValue={values.l1}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('l1', itemValue)
                      )}>
                      <Picker.Item
                        label="Select Interview Type*"
                        value=""
                        color="grey"
                      />
                      <Picker.Item label="L1" value="l1" />
                      <Picker.Item label="L2" value="l2" />
                      <Picker.Item label="Final" value="final" />
                    </Picker>
                  </View>
                  {errors.l1 && touched.l1 && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.l1}
                    </Text>
                  )}
                </View>
              </ScrollView>
            </View>

            <View style={{ flex: 1, flexDirection: 'column' }}>
              <TouchableOpacity
                style={{
                  width: dpforWidth(90),
                  height: dpforHeight(7),
                  borderRadius: 10,
                  alignSelf: 'center',
                  bottom: 0,
                  backgroundColor: COLORS.skyBlue,

                  position: 'absolute',
                }}
                onPress={(values) => handleSubmit(values)}
              >
                <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </Formik>
    </SafeAreaView>
  );
};

export default AddResource;