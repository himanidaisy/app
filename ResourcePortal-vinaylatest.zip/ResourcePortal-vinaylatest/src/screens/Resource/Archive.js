import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  Text,
  TouchableOpacity,
  FlatList,
  View,
  Linking,
  ActivityIndicator,
  StyleSheet,
  Modal,
  Dimensions,
  TextInput,
  ToastAndroid,
} from 'react-native';

import Ionicons from 'react-native-vector-icons/MaterialIcons';
import SearchBox from '../../components/SearchBox';
import { COLORS, GLOBALSTYLES, FONTS } from '../../constants/theme';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { URL } from '../../constants/configure';
const { height, width } = Dimensions.get('window');

const Archive = ({ navigation }) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [ide, setIde] = useState('');
  const [filterData, setFilterData] = useState([]);
  useEffect(() => {
    // getTemplate();
    getResource();
    getAccountFilterData();
  }, [search, loding, newData]);

  //get

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/resource//getAllArchive', requestOptions);

      //   console.log(data.data.result);
      setNewData(data.data.result);
      setLoding(false);
    } catch (error) {
      console.log(error);
      setLoding(true);
    }
  };
  const setSearchValue = value => {
    setSearch(value);
  };
  const getAccountFilterData = () => {
    if (!loding) {
      const filterValue = newData?.filter(data => {
        if (search.length === 0) {
          return data;
        } else if (
          data.fname.toLowerCase().includes(search.toLowerCase()) ||
          data.lname.toLowerCase().includes(search.toLowerCase()) ||
          data.email.toLowerCase().includes(search.toLowerCase()) ||
          data.personal_email.toLowerCase().includes(search.toLowerCase()) ||
          data.project.toLowerCase().includes(search.toLowerCase()) ||
          // data.cost.toLowerCase().includes(search.toLowerCase()) ||
          // data.status.toLowerCase().includes(search.toLowerCase()) ||
          data.passing_year.toLowerCase().includes(search.toLowerCase()) ||

          data.phone.toLowerCase().includes(search.toLowerCase()) ||
          data.project.toLowerCase().includes(search.toLowerCase()) ||

          // data.project.includes(search.toLowerCase()) ||
          // data.on_bench.toLowerCase().includes(search.toLowerCase()) ||

          data.resident_address.toLowerCase().includes(search.toLowerCase())
        ) {
          // console.log(data);
          return data;
        }
      });
      setFilterData(filterValue);
    }
  };

  //archive update

  const ArchiveUser = async (item) => {

    try {
      var token = await AsyncStorage.getItem('token');
      const privateService = axios.create({
        baseURL: URL.BASE_URL
      })
      privateService.interceptors.request.use((request) => {
        request.headers.common.Authorization = `Bearer ${token}`
        return request
      })
      // console.log('deletetoken------------------->', token);

      // console.log('ide------------>', ide)
      const {data} = await privateService.put(`/resource/unarchive/${item}`)
      console.log('data-----', data)

      if (data.message) {
        ToastAndroid.showWithGravity(
          'Resource Unarchive Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
    } catch (err) {
      console.log(err.response);
      ToastAndroid.showWithGravity(
        'Resource  Not Unarchive Successfully',
        ToastAndroid.LONG,
        ToastAndroid.BOTTOM,
      );
    }
  };
  
  const handleArchive = (e, item) => {
    console.log('Archive hit', item.id);
    setIde(item.id)
    ArchiveUser(item.id);
    getResource();

    // console.log('check id', ide);
  };
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
    <SearchBox setSearchValue={setSearchValue} />
    {loding ? (
      <ActivityIndicator
        animating={true}
        size="large"
        style={{
          opacity: 1,
          position: 'absolute',
          left: 0,
          right: 0,
          top: 0,
          bottom: 0,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      />
    ) : (
      filterData.length !== 0 ?

        <FlatList
          data={filterData}
          renderItem={({ item }) => (
            <View style={GLOBALSTYLES.appContainer}>
              <TouchableOpacity style={{ marginBottom: 30, flex: 1 }}
                onPress={e => handleArchive(e, item)}>
                <Ionicons
                  style={{ position: 'absolute', right: 10, top: 0 }}
                  name={'unarchive'}
                  size={26}
                  color={COLORS.green}
                />
              </TouchableOpacity>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Name</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.fname === null ? '-' : `${item.fname} ${item.lname}`}

                  </Text>
                </View>
              </View>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Official Email Id</Text>

                <Text style={GLOBALSTYLES.content}>
                  {item.personal_email == null ? '-' : item.personal_email}
                </Text>
              </View>
              <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Personal Email Id</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.email === null ? '-' : item.email}
                    </Text>
                  </View>
              <View
                style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <View style={{ flexDirection: 'column' }}>

                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Mobile</Text>
                    <View style={GLOBALSTYLES.contentView}>
                      <Text
                        style={{
                          ...FONTS.appFontSemiBold,
                          color: 'black',
                          padding: 3,
                          marginStart: 2,
                        }}>
                        {item.phone === null ? '-' : item.phone}
                      </Text>
                    </View>
                  </View>
                   <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Locality</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.resident_address == null ? '-' : item.resident_address}
                    </Text>
                  </View>

                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>L1</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.l1 === null
                        ? '-'
                        : item.l1}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Project</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.project === null
                        ? '-'
                        : item.project}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Status</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.on_bench === null
                      ? '-'
                      : item.on_bench === 1
                        ? 'Bench'
                        : 'Project'}
                  </Text>
                </View>
              </View>

                </View>
                <View tyle={{ flexDirection: 'column' }}>
                  <View style={{
                    flexDirection: 'column',
                    margin: 10,
                    position: 'relative',
                    right: 30,
                  }}>
                    <Text style={GLOBALSTYLES.lebal}>Vendor</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.vendor == null ? '-' : item?.vendor?.company_name}
                    </Text>
                  </View>
                  <View style={{
                    flexDirection: 'column',
                    margin: 10,
                    position: 'relative',
                    right: 30,
                  }}>
                   
                  </View>
                
                  <View
                    style={{
                      flexDirection: 'column',
                      margin: 10,
                      bottom:10,
                      position: 'relative',
                      right: 30,
                    }}>
                    <Text style={GLOBALSTYLES.lebal}>CV</Text>
                    <TouchableOpacity>
                      <Text
                        style={{
                          fontSize: 15,
                          color: COLORS.skyBlue,
                          marginStart: 4,
                        }}
                        onPress={() => {
                          Linking.openURL(
                            item.resume === null ? '-' : item.resume,
                          );
                        }}>
                        View
                      </Text>
                    </TouchableOpacity>
                  </View>

                  <View
                    style={{
                      flexDirection: 'column',
                      margin: 10,
                      bottom:10,
                      position: 'relative',
                      right: 30,
                    }}>
                    <Text style={GLOBALSTYLES.lebal}>Cost</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.cost === null ? '-' : item.cost}
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: 'column',
                      margin: 10,
                      bottom:10,
                      position: 'relative',
                      right: 30,
                    }}>
                    <Text style={GLOBALSTYLES.lebal}>Passing Year</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.passing_year === null ? '-' : item.passing_year}
                    </Text>
                  </View>
              

                </View>
              </View>
              
            </View>
          )}
        /> : <View style={GLOBALSTYLES.mainContainer}><Text style={{ alignSelf: 'center', margin: '20%', color: 'black' }}>No Data Found</Text></View>

    )}
  </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  viewContainerView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalView: {
    width: width - 50,
    backgroundColor: COLORS.white,
    borderRadius: 10,
    alignSelf: 'center',
    marginTop: width / 1.2,
    height: height / 4.5,
  },
  cancelButton: {
    backgroundColor: COLORS.redOrange,
    borderRadius: 10,
    padding: 20,
    margin: 10,
    position: 'relative',
    top: 10,
  },
  previewButton: {
    backgroundColor: COLORS.skyBlue,
    borderRadius: 10,
    padding: 20,
    margin: 10,
    position: 'relative',
    top: 10,
  },
  cancelButtonText: {
    fontSize: 17,
    alignSelf: 'center',
    fontWeight: 'bold',
    color: 'white',
  },
  modalText: {
    marginBottom: 5,
    textAlign: 'center',
    borderWidth: 1,
    borderColor: 'grey',
    padding: 15,
    marginTop: 20,
    color: 'black',
    alignSelf: 'center',
    width: width / 2,
    borderRadius: 10,
    //  flex:1
  },
});
export default Archive;
