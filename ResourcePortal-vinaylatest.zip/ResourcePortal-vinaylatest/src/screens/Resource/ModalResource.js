import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TextInput,
  FlatList,
  Dimensions,
} from 'react-native';
import {TouchableOpacity} from 'react-native-gesture-handler';
import {GLOBALSTYLES,COLORS,FONTS} from '../../constants/theme';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import {URL} from '../../constants/configure';
const {height, width} = Dimensions.get('window');

const ModalResource = ({navigation, route}) => {
  // const [ide,setIde] = useState('')
  const [acc, setAcc] = useState([]);
  const [admin, setAdmin] = useState();
  const [hr, setHr] = useState('');
const [data,setData] = useState({})

  useEffect(() => {
    setData(route.params.template);
  }, []);

  //Delete User
  const deleteUser = async () => {
    const store = {
      end_date: startDate,
      admin_mail: admin,
      account_mail: acc,
      hr_mail: hr,

    };
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'DELETE',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      const {data} = await axios.delete(
        URL.BASE_URL + `/resource/${id}`,
        store,
        requestOptions,
      );

      setData(route.params.template.ide);
      console.log('--------------------->>>>>>>>>', data.ide);

      if (data.message) {
        ToastAndroid.showWithGravity(
          'Resource Deleted Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
    } catch (err) {
      ToastAndroid.showWithGravity(
        'Resource Not Deleted Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.TOP,
      );
    }
  };
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <View style={{    flex: 1,
    backgroundColor: 'white',
    marginVertical: '1%',
    padding: 10,
    marginHorizontal: 20,
    borderRadius: 10,
    backgroundColor: COLORS.pureWhite,borderWidth:1}}>
      <View style={GLOBALSTYLES.textInputView}>
        <TextInput style={GLOBALSTYLES.textInput}
        value={admin}
        placeholder="admin" />
      </View>
      <View style={GLOBALSTYLES.textInputView}>
        <TextInput style={GLOBALSTYLES.textInput} 
        placeholder="admin body" />
      </View>
      <View style={GLOBALSTYLES.textInputView}>
        <TextInput style={GLOBALSTYLES.textInput} placeholder="account" />
      </View>
      <View style={GLOBALSTYLES.textInputView}>
        <TextInput style={GLOBALSTYLES.textInput} placeholder="account body" />
      </View>
      <View style={GLOBALSTYLES.textInputView}>
        <TextInput style={GLOBALSTYLES.textInput} placeholder="hr" />
      </View>
      <View style={GLOBALSTYLES.textInputView}>
        <TextInput style={GLOBALSTYLES.textInput} placeholder="hr body" />
        </View>

        <TouchableOpacity
          style={{    width: width - 50,
            borderRadius: 10,
            alignSelf: 'center',
            backgroundColor: COLORS.skyBlue,
       }}
          onPress={deleteUser()}>
          <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default ModalResource;
