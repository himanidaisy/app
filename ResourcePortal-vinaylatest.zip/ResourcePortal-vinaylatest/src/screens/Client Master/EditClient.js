import React, { useState, useEffect } from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  Animatable,
  Dimensions,
  StyleSheet, ScrollView
} from 'react-native';
import { dpforHeight, dpforWidth } from '../../constants/SizeScreen';
import { RadioButton } from 'react-native-paper';
import { URL } from '../../constants/configure';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import { COLORS, FONTS, GLOBALSTYLES } from '../../constants/theme';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import { Picker } from '@react-native-picker/picker';
import axios from 'axios';
import EmailIcon from 'react-native-vector-icons/MaterialCommunityIcons';
const { height, width } = Dimensions.get('window');
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Formik } from 'formik';
import * as yup from 'yup';
const EditClient = ({ route,navigation }) => {
  const [newData, setNewData] = useState([]);
  const [ex, setEx] = useState([]);
  const [data, setData] = useState({});

  useEffect(() => {
    getResource();
    getExternal();
    setData(route.params.newData);

  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/client',
        requestOptions,
      );

      //  console.log(data.data.data.clientAgreements);

      setNewData(data.data.data.clients);
    } catch (error) {
      console.log(error);
    }
  };

  //get
  const getExternal = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      // console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/external-products',
        requestOptions,
      );
      setEx(data.data.data.product);
      // console.log(data.data.data.product);
    } catch (error) {
      console.log(error);
    }
  };
  //Post
  const postUser = async values => {
    const id = route.params.newData.id;
    // console.log('checkv--------', values);
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };

      const { data } = await axios.put(
        URL.BASE_URL + `/client/${id}`,
        values,
        requestOptions,
      );

      console.log('valuecheck------------->', data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          ' Client Data Updated Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
      navigation.goBack();
    } catch (err) {
      // console.log(err.response)
      ToastAndroid.showWithGravity(
        'Client Data Not Updated Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };
  const handleSubmit = values => {

    postUser(values);

    console.log('values-------', values);
  };
  const clientsOptions = ex.filter(t => t.name !== null);
  const phoneRegExp =
    /^(\+91)?(-)?\s*?(91)?\s*?(\d{3})-?\s*?(\d{3})-?\s*?(\d{4})$/;
  const nameReg = /^[^-\s][a-zA-Z\s-]+$/;
  const length = /^[0-9]*$/;
  const Pan = /([A-Z]){5}([0-9]){4}([A-Z]){1}$/
  const Gst = /\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}/
  const link = /(((https?:\/\/)|(www\.))[^\s]+)/g

  const loginValidationSchema = yup.object().shape({
    "client_name": yup.string().matches(nameReg, 'Please enter a valid name').required('These field is Required'),
    "reporting_name": yup.string().matches(nameReg, 'Please enter a valid name').required('These field is Required'),
    "reporting_contact": yup.string().matches(phoneRegExp, 'Please enter a valid number').required('These field is Required'),
    "reporting_email": yup.string().email('Email is not valid').required('These field is Required'),
    "hr_name": yup.string().matches(nameReg, 'Please enter a valid name').required('These field is Required'),
    "hr_contact": yup.string().matches(phoneRegExp, 'Please enter a valid number').required('These field is Required'),
    "hr_email": yup.string().email('Email is not valid').required('These field is Required'),
    "Interviewer_name": yup.string().matches(nameReg, 'Please enter a valid name').required('These field is Required'),
    "Interviewer_contact": yup.string().matches(phoneRegExp, 'Please enter a valid number').required('These field is Required'),    
  });

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Edit ClientMaster" />
      <Formik
        validationSchema={loginValidationSchema}
        initialValues={{
          "client_name":data.client_name,
          "reporting_name":data.reporting_name,
          "reporting_contact":data.reporting_contact,
          "reporting_email":data.reporting_email,
          "hr_name":data.hr_name,
          "hr_contact":data.hr_contact,
          "hr_email":data.hr_email,
          "Interviewer_name":data.Interviewer_name,
          "Interviewer_contact":data.Interviewer_contact,
        }}
        enableReinitialize={true}
        onSubmit={values => {
          handleSubmit(values);
        }}>
        {({
          handleChange,
          handleBlur,
          handleSubmit,
          errors,
          touched,
          values,
          setFieldValue
        }) => (
          <>
            <View style={{ height: height / 1.2 }}>

              <ScrollView>

                <View style={{ height: height / 0.22 }}>
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10,
                      marginTop: 10,
                    }}>
                    <TextInput
                      placeholder="Client Name*"
                      style={GLOBALSTYLES.textInput}
                      maxLength={25}
                      value={values.client_name}
                      // keyboardType='default'
                      onChangeText={handleChange('client_name')}
                      onBlur={handleBlur('client_name')}
                    />
                  </View>
                  {errors.client_name && touched.client_name && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.client_name}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Reporting Manager Name*"
                      style={GLOBALSTYLES.textInput}
                      maxLength={25}
                      value={values.reporting_name}
                      // keyboardType='default'
                      onChangeText={handleChange('reporting_name')}
                      onBlur={handleBlur('reporting_name')}
                    />
                  </View>
                  {errors.reporting_name && touched.reporting_name && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.reporting_name}
                    </Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 12,

                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <FontAwesome
                        name="phone"
                        size={25}
                        style={{ right: 12, marginStart: 25 }}
                      />
                    </View>

                    <TextInput
                      placeholder="Reporting Manager Contact*"
                      style={GLOBALSTYLES.textInput}
                      maxLength={10}
                      value={values.reporting_contact}
                      keyboardType='phone-pad'
                      onChangeText={handleChange('reporting_contact')}
                      onBlur={handleBlur('reporting_contact')}
                    />
                  </View>
                  {errors.reporting_contact && touched.reporting_contact && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.reporting_contact}
                    </Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 8,
                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <EmailIcon
                        name="email-outline"
                        size={30}
                        style={{ right: 12, marginStart: 25 }}
                      />
                    </View>
                    <TextInput
                      placeholder="Reporting Manager Email*"
                      style={GLOBALSTYLES.textInput}
                      maxLength={45}
                      value={values.reporting_email}

                      keyboardType='email-address'
                      onChangeText={handleChange('reporting_email')}
                      onBlur={handleBlur('reporting_email')}

                    />
                  </View>
                  {errors.reporting_email && touched.reporting_email && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.reporting_email}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="HR Name"
                      style={GLOBALSTYLES.textInput}
                      maxLength={25}
                      // keyboardType='default'
                      value={values.hr_name}
                      onChangeText={handleChange('hr_name*')}
                      onBlur={handleBlur('hr_name')}

                    />
                  </View>
                  {errors.hr_name && touched.hr_name && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.hr_name}
                    </Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 12,

                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <FontAwesome
                        name="phone"
                        size={25}
                        style={{ right: 12, marginStart: 25 }}
                      />
                    </View>

                    <TextInput
                      placeholder="HR Contact*"
                      style={GLOBALSTYLES.textInput}
                      maxLength={10}
                      value={values.hr_contact}
                      keyboardType='phone-pad'
                      onChangeText={handleChange('hr_contact')}
                      onBlur={handleBlur('hr_contact')}

                    />
                  </View>
                  {errors.hr_contact && touched.hr_contact && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.hr_contact}
                    </Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 8,
                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <EmailIcon
                        name="email-outline"
                        size={30}
                        style={{ right: 12, marginStart: 25 }}
                      />
                    </View>
                    <TextInput
                      placeholder="HR Email*"
                      style={GLOBALSTYLES.textInput}
                      maxLength={45}
                      value={values.hr_email}
                      keyboardType='email-address'
                      onChangeText={handleChange('hr_email')}
                      onBlur={handleBlur('hr_email')}

                    />
                  </View>
                  {errors.hr_email && touched.hr_email && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.hr_email}
                    </Text>
                  )}

                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Interviewer Name"
                      style={GLOBALSTYLES.textInput}
                      maxLength={25}
                      value={values.Interviewer_name}

                      keyboardType='default'
                      onChangeText={handleChange('Interviewer_name')}
                      onBlur={handleBlur('Interviewer_name')}

                    />
                  </View>
                  {errors.Interviewer_name && touched.Interviewer_name && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.Interviewer_name}
                    </Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 12,

                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <FontAwesome
                        name="phone"
                        size={25}
                        style={{ right: 12, marginStart: 25 }}
                      />
                    </View>

                    <TextInput
                      placeholder="Interviewer Contact*"
                      style={GLOBALSTYLES.textInput}
                      maxLength={10}
                      value={values.Interviewer_contact}
                      keyboardType='phone-pad'
                      onChangeText={handleChange('Interviewer_contact')}
                      onBlur={handleBlur('Interviewer_contact')}

                    />
                  </View>
                  {errors.Interviewer_contact && touched.Interviewer_contact && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.Interviewer_contact}
                    </Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 8,
                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <EmailIcon
                        name="email-outline"
                        size={30}
                        style={{ right: 12, marginStart: 25 }}
                      />
                    </View>
                    <TextInput
                      placeholder="Interviewer Email"
                      style={GLOBALSTYLES.textInput}
                      value={values.Interviewer_email}
                      maxLength={45}
                      keyboardType='email-address'
                      onChangeText={handleChange('Interviewer_email')}
                      onBlur={handleBlur('Interviewer_email')}

                    />
                  </View>

                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Finance Name"
                      style={GLOBALSTYLES.textInput}
                      maxLength={25}
                      keyboardType='default'
                      value={values.account_name}
                      onChangeText={handleChange('account_name')}
                      onBlur={handleBlur('account_name')}

                    />
                  </View>
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 12,

                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <FontAwesome
                        name="phone"
                        size={25}
                        style={{ right: 12, marginStart: 25 }}
                      />
                    </View>

                    <TextInput
                      placeholder="Finance Phone"
                      style={GLOBALSTYLES.textInput}
                      maxLength={10}
                      value={values.account_mobile}
                      keyboardType='phone-pad'
                      onChangeText={handleChange('account_mobile')}
                      onBlur={handleBlur('account_mobile')}

                    />
                  </View>
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 8,
                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <EmailIcon
                        name="email-outline"
                        size={30}
                        style={{ right: 12, marginStart: 25 }}
                      />
                    </View>
                    <TextInput
                      placeholder="Finance Email"
                      style={GLOBALSTYLES.textInput}
                      maxLength={25}
                      value={values.account_email}

                      keyboardType='email-address'
                      onChangeText={handleChange('account_email')}
                      onBlur={handleBlur('account_email')}

                    />
                  </View>
 
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="URL"
                      style={GLOBALSTYLES.textInput}
                      maxLength={45}
                      value={values.url}

                      keyboardType='default'
                      onChangeText={handleChange('url')}
                      onBlur={handleBlur('url')}

                    />
                  </View>
 
                  <View style={{
                      width: dpforWidth(90),
                      height: dpforHeight(15),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10,
                    }}>
                    <TextInput
                      placeholder="Residential Address"
                      style={{marginHorizontal: 20,
                        fontSize:14,
                        marginTop: 1,}}
                      maxLength={200}
                      keyboardType='default'
                      onChangeText={handleChange('address')}
                      onBlur={handleBlur('address')}
                      value={values.address}

                    />
                  </View>
       
                  <View style={{width: dpforWidth(90),
                      height: dpforHeight(15),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10,}}>
                    <TextInput
                      placeholder="Description"
                      style={{marginHorizontal: 20,
                        fontSize:14,
                        marginTop: 1,}}
                      maxLength={200}
                      value={values.description}

                      keyboardType='default'
                      onChangeText={handleChange('description')}
                      onBlur={handleBlur('description')}

                    />
                  </View>
 
                  <View style={{width: dpforWidth(90),
                      height: dpforHeight(15),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10,}}>
                    <TextInput
                      placeholder="Billing Address"
                      style={{marginHorizontal: 20,
                        fontSize:14,
                        marginTop: 1,}}
                      maxLength={200}
                      value={values.billing_address}

                      keyboardType='default'
                      onChangeText={handleChange('billing_address')}
                      onBlur={handleBlur('billing_address')}

                    />
                  </View>
 
                  <View style={{width: dpforWidth(90),
                      height: dpforHeight(15),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10}}>
                    <TextInput
                      placeholder="Operational Address"
                      style={{marginHorizontal: 20,
                        fontSize:14,
                        marginTop: 1,}}
                      maxLength={200}
                      value={values.operational_address}

                      keyboardType='default'
                      onChangeText={handleChange('operational_address')}
                      onBlur={handleBlur('operational_address')}

                    />
                  </View>

                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="PAN Number"
                      style={GLOBALSTYLES.textInput}
                      maxLength={10}
                      keyboardType='default'
                      onChangeText={handleChange('pan')}
                      onBlur={handleBlur('pan')}
                      value={values.pan}

                    />
                  </View>
   
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="GST Number"
                      style={GLOBALSTYLES.textInput}
                      maxLength={15}
                      value={values.gst}
                      keyboardType='default'
                      onChangeText={handleChange('gst')}
                      onBlur={handleBlur('gst')}

                    />
                  </View>

                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="TAN Number"
                      style={GLOBALSTYLES.textInput}
                      maxLength={10}
                      value={values.tan}

                      keyboardType='default'
                      onChangeText={handleChange('tan')}
                      onBlur={handleBlur('tan')}

                    />
                  </View>
  
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Map"
                      maxLength={25}
                      value={values.address_map_link}

                      keyboardType='default'
                      style={GLOBALSTYLES.textInput}
                      onChangeText={handleChange('address_map_link')}
                      onBlur={handleBlur('address_map_link')}

                    />
                  </View>
  
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Credit Period"
                      maxLength={3}
                      value={values.credit_period}

                      keyboardType='numeric'
                      style={GLOBALSTYLES.textInput}
                      onChangeText={handleChange('credit_period')}
                      onBlur={handleBlur('credit_period')}

                    />
                  </View>
      
                  <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      selectedValue={values.invoice_date}
                      style={{ margin: 4, bottom: 0 }}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('invoice_date', itemValue)
                      )}>
                      <Picker.Item label="Date of Invoice" value="" color="grey" />
                      <Picker.Item label="1st of Months" value="1st of Months" />
                      <Picker.Item label="15th of Months" value="15th of Months" />
                      <Picker.Item label="30th of Months" value="30th of Months" />
                      <Picker.Item
                        label="1st Of Next Months"
                        value="1st Of Next Months"
                      />
                      <Picker.Item
                        label="15th Of Next Months"
                        value="15th Of Next Months"
                      />
                      <Picker.Item
                        label="30th Of Next Months"
                        value="30th Of Next Months"
                      />
                    </Picker>
                  </View>
      
                  <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      selectedValue={values.nationality}
                      style={{ margin: 4, bottom: 0 }}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('nationality', itemValue)
                      )}>
                      <Picker.Item label="Select Nationality" value="" color="grey" />
                      <Picker.Item label="Indian" value="Indian" />
                      <Picker.Item label="Other" value="Other" />
                    </Picker>
                  </View>
             
                  <View style={styles.appContainer}>
                    <View style={styles.lebalView}>
                      <Text>Do You Need Timesheet?</Text>
                    </View>

                    <View style={styles.checkboxContainer}>
                      <RadioButton.Group
                        value={values.need_timesheet} 
                        onValueChange={(itemValue) => (
                          setFieldValue('need_timesheet', itemValue)
                        )}>

                        <View
                          style={{
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                            marginStart: 15,
                          }}>
                          <View>
                            <RadioButton value="N" />
                            <Text style={styles.radiotext}>No</Text>
                          </View>
                          <View style={styles.buttonContainer}>
                            <RadioButton value="Y" />
                            <Text style={styles.yradiotext}>Yes</Text>
                          </View>
                        </View>
                      </RadioButton.Group>
                    </View>    
                    <View style={styles.lebalView}>
                      <Text>Do You Need Machine?</Text>
                    </View>
                    <View style={styles.checkboxContainer}>
                      <RadioButton.Group
                        value={values.need_machine}
                        onValueChange={(itemValue) => (
                          setFieldValue('need_machine', itemValue)
                        )}>
                        <View
                          style={{
                            flexDirection: 'row',
                            marginStart: 15,
                            justifyContent: 'space-between',
                          }}>
                          <View>
                            <RadioButton value="N" />
                            <Text style={styles.radiotext}>No</Text>
                          </View>
                          <View style={styles.buttonContainer}>
                            <RadioButton value="Y" />
                            <Text style={styles.yradiotext}>Yes</Text>
                          </View>
                        </View>
                      </RadioButton.Group>
                    </View>     
                    <View style={styles.lebalView}>
                      <Text>Weekend Working?</Text>
                    </View>
                    <View style={styles.checkboxContainer}>
                      <RadioButton.Group
                        value={values.weekend_working}
                        onValueChange={(itemValue) => (
                          setFieldValue('weekend_working', itemValue)
                        )}>
                        <View
                          style={{
                            flexDirection: 'row',
                            marginStart: 15,
                            justifyContent: 'space-between',
                          }}>
                          <View>
                            <RadioButton value="N" />
                            <Text style={styles.radiotext}>No</Text>
                          </View>
                          <View style={styles.buttonContainer}>
                            <RadioButton value="Y" />
                            <Text style={styles.yradiotext}>Yes</Text>
                          </View>
                        </View>
                      </RadioButton.Group>
                    </View>
         
                    <View style={styles.lebalView}>
                      <Text>Agreement Sign?</Text>
                    </View>
                    <View style={styles.checkboxContainer}>
                      <RadioButton.Group
                        value={values.aggrement_sign}
                        onValueChange={(itemValue) => (
                          setFieldValue('aggrement_sign', itemValue)
                        )}>
                        <View
                          style={{
                            flexDirection: 'row',
                            marginStart: 15,
                            justifyContent: 'space-between',
                          }}>
                          <View>
                            <RadioButton value="N" />
                            <Text style={styles.radiotext}>No</Text>
                          </View>
                          <View style={styles.buttonContainer}>
                            <RadioButton value="Y" />
                            <Text style={styles.yradiotext}>Yes</Text>
                          </View>
                        </View>
                      </RadioButton.Group>
                    </View>
              
                    <View style={styles.lebalView}>
                      <Text>First Invoice Send?</Text>
                    </View>
                    <View style={styles.checkboxContainer}>
                      <RadioButton.Group
                        value={values.first_invoice}
                        onValueChange={(itemValue) => (
                          setFieldValue('first_invoice', itemValue)
                        )}>
                        <View
                          style={{
                            flexDirection: 'row',
                            marginStart: 15,
                            justifyContent: 'space-between',
                          }}>
                          <View>
                            <RadioButton value="N" />
                            <Text style={styles.radiotext}>No</Text>
                          </View>
                          <View style={styles.buttonContainer}>
                            <RadioButton value="Y" />
                            <Text style={styles.yradiotext}>Yes</Text>
                          </View>
                        </View>
                      </RadioButton.Group>
                    </View>
                   
                    <View style={styles.lebalView}>
                      <Text>Pf Proof Needed</Text>
                    </View>
                    <View style={styles.checkboxContainer}>
                      <RadioButton.Group
                        value={values.pf_proof}
                        onValueChange={(itemValue) => (
                          setFieldValue('pf_proof', itemValue)
                        )}>
                        <View
                          style={{
                            flexDirection: 'row',
                            marginStart: 15,
                            justifyContent: 'space-between',
                          }}>
                          <View>
                            <RadioButton value="N" />
                            <Text style={styles.radiotext}>No</Text>
                          </View>
                          <View style={styles.buttonContainer}>
                            <RadioButton value="Y" />
                            <Text style={styles.yradiotext}>Yes</Text>
                          </View>
                        </View>
                      </RadioButton.Group>
                    </View>
                   
                    {/* <View style={styles.lebalView}>
                      <Text>Physical Copy Needed?</Text>
                    </View>
                    <View style={styles.checkboxContainer}>
                      <RadioButton.Group
                        value={values.is_invoice_need}
                        onValueChange={(itemValue) => (
                          setFieldValue('is_invoice_need', itemValue)
                        )}>
                        <View
                          style={{
                            flexDirection: 'row',
                            marginStart: 15,
                            justifyContent: 'space-between',
                          }}>
                          <View>
                            <RadioButton value="N" />
                            <Text style={styles.radiotext}>No</Text>
                          </View>
                          <View style={styles.buttonContainer}>
                            <RadioButton value="Y" />
                            <Text style={styles.yradiotext}>Yes</Text>
                          </View>
                        </View>
                      </RadioButton.Group>
                    </View>
                    {errors.is_invoice_need && touched.is_invoice_need && (
                      <Text style={GLOBALSTYLES.errorStyle}>{errors.is_invoice_need}</Text>
                    )} */}
                    <View style={styles.lebalView}>
                      <Text>Is Purchase Order Required?</Text>
                    </View>
                    <View style={styles.checkboxContainer}>
                      <RadioButton.Group
                        value={values.is_pruchase_ord_req}
                        onValueChange={(itemValue) => (
                          setFieldValue('is_pruchase_ord_req', itemValue)
                        )}>
                        <View
                          style={{
                            flexDirection: 'row',
                            marginStart: 15,
                            justifyContent: 'space-between',
                          }}>
                          <View>
                            <RadioButton value="N" />
                            <Text style={styles.radiotext}>No</Text>
                          </View>
                          <View style={styles.buttonContainer}>
                            <RadioButton value="Y" />
                            <Text style={styles.yradiotext}>Yes</Text>
                          </View>
                        </View>
                      </RadioButton.Group>
                    </View>
             
                    <View style={styles.lebalView}>
                      <Text>Is External Product?</Text>
                    </View>
                    <View style={styles.checkboxContainer}>
                      <RadioButton.Group
                        value={values.is_external_product}
                        onValueChange={(itemValue) => (
                          setFieldValue('is_external_product', itemValue)
                        )}>
                        <View
                          style={{
                            flexDirection: 'row',
                            marginStart: 15,
                            justifyContent: 'space-between',
                          }}>
                          <View>
                            <RadioButton value="N" />
                            <Text style={styles.radiotext}>No</Text>
                          </View>
                          <View style={styles.buttonContainer}>
                            <RadioButton value="Y" />
                            <Text style={styles.yradiotext}>Yes</Text>
                          </View>
                        </View>
                      </RadioButton.Group>
                    </View>
                  
                    {/* <View style={styles.lebalView}>
                      <Text>Is Invoice Needed</Text>
                    </View> */}
                    {/* <View style={styles.checkboxContainer}>
                      <RadioButton.Group
                        value={values.is_invoice_need}
                        onValueChange={(itemValue) => (
                          setFieldValue('is_invoice_need', itemValue)
                        )}>
                        <View
                          style={{
                            flexDirection: 'row',
                            marginStart: 15,
                            justifyContent: 'space-between',
                          }}>
                          <View>
                            <RadioButton value="N" />
                            <Text style={styles.radiotext}>No</Text>
                          </View>
                          <View style={styles.buttonContainer}>
                            <RadioButton value="Y" />
                            <Text style={styles.yradiotext}>Yes</Text>
                          </View>
                        </View>
                      </RadioButton.Group>
                    </View>
                    {errors.is_invoice_need && touched.is_invoice_need && (
                      <Text style={GLOBALSTYLES.errorStyle}>{errors.is_invoice_need}</Text>
                    )} */}
                    {/* <View style={{
                      width: width - 150,
                      height: height / 14,
                      margin: 5,
                      marginStart: 10,
                      backgroundColor: COLORS.white,
                      borderRadius: 10,
                    }}>
                      <Picker
                        selectedValue={values.external_product}
                        style={{ margin: 4, bottom: 0 }}
                        mode="dropdown"
                        onValueChange={(itemValue) => (
                          setFieldValue('external_product', itemValue)
                        )}>
                        <Picker.Item
                          label="Select"
                          value=""
                          color="grey"
                        />

                        {clientsOptions.map((item, index) => (
                          <Picker.Item key={item.id} label={item.name} value={item.id} />
                        ))}
                      </Picker>
                    </View>
                    {errors.external_product && touched.external_product && (
                      <Text style={GLOBALSTYLES.errorStyle}>{errors.external_product}</Text>
                    )} */}
                  </View>
                </View>
              </ScrollView>
            </View>
            <View style={{ flexDirection: 'row', flex: 1, justifyContent: 'space-between' }}>
              <TouchableOpacity
                style={{
                  backgroundColor: COLORS.skyBlue,
                  padding: 10,
                  flex: 1,
                  borderRadius: 10,
                  margin: 10,
                  left: 5,
                }}
                onPress={() => handleSubmit()}>
                <Text style={{
                  ...FONTS.appFontSemi,
                  alignSelf: 'center', top: 4,
                  color: COLORS.pureWhite,
                  fontWeight: 'bold',
                }}>Edit</Text>
              </TouchableOpacity>
              <TouchableOpacity style={{
                backgroundColor: COLORS.red,
                padding: 10,
                flex: 1,
                borderRadius: 10,
                margin: 10,
                right: 4,
              }}
                onPress={() => navigation.goBack()}
              >
                <Text style={{
                  ...FONTS.appFontSemi,
                  alignSelf: 'center', top: 4,
                  color: COLORS.pureWhite,
                  fontWeight: 'bold',
                }}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </Formik>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  appContainer: {
    flex: 1,
    margin: 20,
    backgroundColor: COLORS.pureWhite,
    marginVertical: '1%',
    padding: 10,
    borderRadius: 10,
    backgroundColor: COLORS.pureWhite,
  },
  textInputView: {
    width: dpforWidth(90),
    height: dpforHeight(7),
    margin: 5,
    marginStart: 20,
    backgroundColor: COLORS.pureWhite,
    borderRadius: 10,
  },
  lebalView: {
    flexDirection: 'column',
    padding: 20,
  },
  lebal: {
    fontSize:14,
    color: 'grey',
    padding: 2,
  },
  content: {
    fontSize:14,
    color: 'black',
    margin: 2,
  },
  buttonContainer: {
    position: 'relative',
    right: 100,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radiotext: {
    marginStart: 10,
  },
  yradiotext: {
    marginLeft: 7,
  },
  checkbox: {
    alignSelf: 'center',
    marginLeft: 15,
  },

  secondcheckbox: {
    alignSelf: 'center',
    position: 'relative',
    start: 90,
  },
  label: {
    margin: 8,
  },
  secondlabel: {
    margin: 8,
    position: 'relative',
    left: 90,
  },
  textInput: {},
});
export default EditClient;