import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  ToastAndroid,
  TextInput,
  StyleSheet,
  Dimensions,
} from 'react-native';
import { dpforWidth,dpforHeight } from '../../constants/SizeScreen';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {Formik} from 'formik';
import {URL} from '../../constants/configure';
import axios from 'axios';
import Toast from 'react-native-simple-toast';
import * as yup from 'yup';
import AsyncStorage from '@react-native-async-storage/async-storage';
const {height, width} = Dimensions.get('window');

const AddAccountant = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [nameTouched, setnameTouched] = useState(false);
  const [emailTouched, setemailTouched] = useState(false);
  const [phoneTouched, setphoneTouched] = useState(false);
  const phoneRegExp =
    /^(\+91)?(-)?\s*?(91)?\s*?(\d{3})-?\s*?(\d{3})-?\s*?(\d{4})$/;
    const nameReg = /^[^-\s][a-zA-Z\s-]+$/;


  const loginValidationSchema = yup.object().shape({
    name: yup.string().matches(nameReg,'Please enter a valid name').required('These field is Required'),
    phone: yup
      .string()
      .matches(phoneRegExp, 'Please enter a valid number')
      .required('These field is Required'),
    email: yup
      .string()
      .email('Email is not valid')
      .required('These field is Required'),
  });
  
  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      const data = await axios.get(URL.BASE_URL + '/account', requestOptions);

      let arr = [];
      data.data.data.accounts.map(temp => {
        let obj = {
          name: temp.name,
          email: temp.email,
          phone: temp.phone,
        };
        arr.push(obj);
      });
      console.log(arr);
      setNewData(arr);
    } catch (error) {
      console.log(error);
    }
  };
  const isExistname = name => {
    return newData.some(function (el) {
      return el.name === name;
    });
  };
  const isExistemail = email => {
    return newData.some(function (el) {
      return el.email === email;
    });
  };
  const isExistphone = phone => {
    return newData.some(function (el) {
      return el.phone === phone;
    });
  };
  //post
  const postUser = async values => {
    // console.log(values);
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
        URL.BASE_URL + '/account',
        values,
        requestOptions,
      );
       
      // console.log('check-----------', data);

      if (data.message) {
       
        Toast.showWithGravity('Accountant Added Successfully', Toast.LONG, Toast.BOTTOM);

      }
      navigation.goBack();
    } catch (err) {
      Toast.showWithGravity('Accountant Added Not Successfully', Toast.LONG, Toast.BOTTOM);

    }
  };
  const handleSubmit = values => {
    JSON.stringify(values);
    const {name: name, email: email, phone: phone} = values;
    //console.log(isExist(tech,Url));
    if (isExistname(name) == true) {
      setnameTouched(true);
    } else {
      setnameTouched(false);
    }

    if (isExistphone(phone) == true) {
      setphoneTouched(true);
    } else {
      setphoneTouched(false);
    }
    if (isExistemail(email) == true) {
      setemailTouched(true);
    } else {
      setemailTouched(false);
      postUser(values);
    }
  };
  useEffect(() => {
    getResource();
    isExistname();
    isExistemail();
    isExistphone();
  }, []);
  return (
    <SafeAreaView style={styles.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Accountant" />
      <View style={styles.container}>
        <Formik
          validationSchema={loginValidationSchema}
          initialValues={{name: '', phone: '', email: ''}}
          onSubmit={handleSubmit}>
          {({handleChange, handleBlur, handleSubmit, errors, touched}) => (
            <>
              <View style={{height: height / 1.2}}>
                <View
                  style={{
                    width: dpforWidth(90),
                    height: dpforHeight(7),
                    margin: 5,
                    flexDirection: 'row',
                    backgroundColor: COLORS.pureWhite,
                    marginStart: 25,
                    borderRadius: 10,
                    marginTop: 10,
                  }}>
                  <TextInput
                    placeholder="Name*"
                    maxLength={20}
                    style={styles.textInput}
                    onChangeText={handleChange('name')}
                    onBlur={handleBlur('name')}
                  />
                </View>
                {errors.name && touched.name && (
                  <Text style={styles.errorStyle}>{errors.name}</Text>
                )}
                {nameTouched === true ? (
                  <Text
                    style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                    Value Already Exist
                  </Text>
                ) : null}
                <View style={styles.textInputView}>
                  <View style={styles.innerBtn}>
                    <FontAwesome
                      color={COLORS.lightBlue}
                      name="phone"
                      size={20}
                      style={{right: 12, marginStart: 25}}
                    />
                  </View>
                  <TextInput
                    placeholder="Mobile*"
                    maxLength={10}
                    keyboardType ='phone-pad'
                    style={styles.textInput}
                    onChangeText={handleChange('phone')}
                    onBlur={handleBlur('phone')}
                  />
                </View>
                {errors.phone && touched.phone && (
                  <Text style={styles.errorStyle}>{errors.phone}</Text>
                )}
                {phoneTouched === true ? (
                  <Text
                    style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                    Value Already Exist
                  </Text>
                ) : null}
                <View style={styles.textInputView}>
                  <View style={styles.innerBtn}>
                    <MaterialCommunityIcons
                      color={COLORS.lightBlue}
                      name="email-outline"
                      size={25}
                      style={{right: 7, marginStart: 15}}
                    />
                  </View>
                  <TextInput
                    placeholder="Email Id*"
                    maxLength={40}
                    keyboardType = 'email-address'
                    style={styles.textInput}
                    onChangeText={handleChange('email')}
                    onBlur={handleBlur('email')}
                  />
                </View>
                {errors.email && touched.email && (
                  <Text style={styles.errorStyle}>{errors.email}</Text>
                )}
                {emailTouched === true ? (
                  <Text
                    style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                    Value Already Exist
                  </Text>
                ) : null}
              </View>
              <View
                style={{
                  flex: 1,
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                }}>
                <TouchableOpacity
                  style={GLOBALSTYLES.buttonStyle}
                  onPress={() => handleSubmit()}>
                  <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
                </TouchableOpacity>
              </View>
            </>
          )}
        </Formik>
      </View>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  textInputView: {
    width: dpforWidth(90),
    height: dpforHeight(7),
    margin: 5,
    flexDirection: 'row',
    backgroundColor: COLORS.pureWhite,
    marginStart: 25,
    borderRadius: 10,
  },
  textInput: {
    marginHorizontal: 20,
    fontSize:14,
    flex: 1,
  },
  innerBtn: {
    justifyContent: 'center',
    borderRadius: 10,
    padding: 15,
    backgroundColor: COLORS.whiteBlue,
  },
  errorStyle: {
    fontSize:14,
    color: COLORS.red,
    textAlign: 'center',
  },
  iconStyle: {
    right: 8,
    marginStart: 15,
  },
});
export default AddAccountant;