import React, { useEffect, useState } from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  StyleSheet,
  ToastAndroid,
  Dimensions
} from 'react-native';
import { dpforWidth,dpforHeight } from '../../constants/SizeScreen';
import { URL } from '../../constants/configure';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import { FONTS, COLORS, GLOBALSTYLES } from '../../constants/theme';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { Formik } from 'formik';
import axios from 'axios';
import * as yup from 'yup';
import Toast from 'react-native-simple-toast';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import AsyncStorage from '@react-native-async-storage/async-storage';
const { height, width } = Dimensions.get('window');

const EditScreen = ({ route, navigation }) => {
  const [data, setData] = useState({});
  const [name, setName] = useState('');

  // console.log('valuess', route.params.newData.id);
  useEffect(() => {
    setData(route.params.newData);
    setName(route.params.newData);
  }, []);
  // console.log('sadsd---------', route.params.newData);
  const phoneRegExp =
    /^(\+91)?(-)?\s*?(91)?\s*?(\d{3})-?\s*?(\d{3})-?\s*?(\d{4})$/;
  const nameReg = /^[^-\s][a-zA-Z\s-]+$/;


  const loginValidationSchema = yup.object().shape({
    name: yup.string().matches(nameReg, 'Please enter a valid name').required('These field is Required'),
    phone: yup
      .string()
      .matches(phoneRegExp, 'Please enter a valid number')
      .required('These field is Required'),
    email: yup
      .string()
      .email('Email is not valid')
      .required('These field is Required'),
  });

  // console.warn('Routes: ', data.email)

  //put
  const putUser = async values => {
    // console.log(values);
    const id = route.params.newData.id;
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };

      const { data } = await axios.put(
        URL.BASE_URL + `/account/${id}`,
        values,
        requestOptions,
      );

      // console.log(data);
      setData(route.params.newData);
      if (data.message) {
    
        Toast.showWithGravity('Accountant Updated Successfully', Toast.LONG, Toast.BOTTOM);

      }
      navigation.goBack();
    } catch (err) {
      Toast.showWithGravity('Accountant Not Updated Successfully', Toast.LONG, Toast.BOTTOM);

    }
  };
  const handleSubmit = values => {
    putUser(values);
    // console.log('values-------', values);
  };
  return (
    <SafeAreaView style={styles.mainContainer}>
      <CustomNavigationBar back={true} headername="Edit Accountant" />
      <View style={styles.container}>
        <Formik
          validationSchema={loginValidationSchema}
          initialValues={{
            name: data.name,
            phone: data.phone,
            email: data.email,
          }}
          enableReinitialize={true}
          onSubmit={values => {
            handleSubmit(values);
          }}>
          {({
            handleChange,
            handleBlur,
            handleSubmit,
            errors,
            touched,
            values,
          }) => (
            <>
              <View style={{ height: hp('80%') }}>
                <View
                  style={{
                    width: dpforWidth(90),
                    height: dpforHeight(7),
                    margin: 5,
                    flexDirection: 'row',
                    backgroundColor: COLORS.pureWhite,
                    marginStart: 20,
                    borderRadius: 10,
                    marginTop: 10,
                  }}>
                  <TextInput
                    placeholder="Name*"
                    value={values.name}
                    maxLength={25}
                    style={styles.textInput}
                    onChangeText={handleChange('name')}
                    onBlur={handleBlur('name')}
                  />
                </View>
                {errors.name && touched.name && (
                  <Text style={styles.errorStyle}>{errors.name}</Text>
                )}
                <View style={styles.textInputView}>
                  <View style={styles.innerBtn}>
                    <FontAwesome
                      name="phone"
                      color={COLORS.lightBlue}
                      size={30}
                      style={styles.iconStyle}
                    />
                  </View>
                  <TextInput
                    placeholder="Mobile*"
                    value={values.phone}
                    maxLength={10}
                    style={styles.textInput}
                    onChangeText={handleChange('phone')}
                    onBlur={handleBlur('phone')}
                    keyboardType="phone-pad"
                  />
                </View>
                {errors.phone && touched.phone && (
                  <Text style={styles.errorStyle}>{errors.phone}</Text>
                )}
                <View style={styles.textInputView}>
                  <View style={styles.innerBtn}>
                    <MaterialCommunityIcons
                      name="email-outline"
                      size={25}
                      color={COLORS.lightBlue}
                      style={styles.iconStyle}
                    />
                  </View>
                  <TextInput
                    placeholder="Email Id*"
                    value={values.email}
                    style={styles.textInput}
                    onChangeText={handleChange('email')}
                    onBlur={handleBlur('email')}
                    keyboardType="email-address"
                    maxLength={45}
                  />
                </View>
                {errors.email && touched.email && (
                  <Text style={styles.errorStyle}>{errors.email}</Text>
                )}
              </View>

              <View style={{ flex: 1, flexDirection: 'column', justifyContent: 'space-between' }}>

                <TouchableOpacity
                  style={GLOBALSTYLES.buttonStyle}
                  onPress={() => {
                    handleSubmit();
                  }}>
                  <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
                </TouchableOpacity>
              </View>
            </>
          )}
        </Formik>
      </View>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  textInputView: {
    width: dpforWidth(90),
    height: dpforHeight(7),
    margin: 5,
    flexDirection: 'row',
    backgroundColor: COLORS.pureWhite,
    marginStart: 25,
    borderRadius: 10,
  },
  textInput: {
    marginHorizontal: 20,
    fontSize:14,
    flex: 1,
  },
  innerBtn: {
    justifyContent: 'center',
    borderRadius: 10,
    padding: 15,
    backgroundColor: COLORS.whiteBlue,
  },

  iconStyle: {
    right: 8,
    marginStart: 15,
  },

  errorStyle: {
    fontSize:14,
    color: COLORS.red,
    textAlign: 'center',
  },
});

export default EditScreen;