import React, {useState, useEffect} from 'react';
import {Text, View, SafeAreaView, ToastAndroid,TouchableOpacity,TextInput,StyleSheet,Dimensions} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {Formik} from 'formik';
import * as yup from 'yup';
import axios from 'axios';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {dpforHeight, dpforWidth} from '../../constants/SizeScreen'

import {URL} from '../../constants/configure'
import AsyncStorage from '@react-native-async-storage/async-storage';
const {height, width} = Dimensions.get('window');

const AddUserSetting = ({route, navigation}) => {
  const [data, setData] = useState({});

  useEffect(() => {
    setData(route.params.newData);
  }, []);

  const putUser = async values => {

    console.log('check------------->>>>', values);
    const id = route.params.newData.id;

    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.put(
        URL.BASE_URL+`/user/${id}`,
        values,
        requestOptions,
      );

      console.log(data);
      setData(route.params.newData);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'User Updated Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
     navigation.goBack();

    } catch (err) {
      ToastAndroid.showWithGravity(
        'User Not Updated Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  
  };
  const handleSubmit = values => {
    putUser(values);
  };
  const nameReg = /^[^-\s][a-zA-Z\s-]+$/;

  const loginValidationSchema = yup.object().shape({
    name: yup.string().required('These field is Required').matches(nameReg, 'Please enter a valid name'),
    email: yup
      .string()
      .email('Email is not valid')
      .required('These field is Required'),
    other: yup
      .string(),
    password:  yup
    .string()
    .min(8, ({min}) => `Password must be at least ${min} characters`)
    .required('Please fill out this filed'),

  });
  return (
    <SafeAreaView style={styles.mainContainer}>
    <CustomNavigationBar back={true} headername="Edit User Setting" />
    <Formik
          validationSchema={loginValidationSchema}
          initialValues={{
            name:data.name,
            email:data.email,
            password:data.password,
          }}
          enableReinitialize={true}
          onSubmit={values => {
            handleSubmit(values);
          }}>
          {({
            handleChange,
            handleBlur,
            handleSubmit,
            errors,
            touched,
            values,
          }) => (
            <>
   <View style={{height: height/1.2,
}}>
                <View
                  style={{
                    width: dpforWidth(90),
                    height: dpforHeight(7),
                    margin: 5,
                    flexDirection: 'row',
                    backgroundColor: COLORS.pureWhite,
                    marginStart: 20,
                    borderRadius: 10,
                    marginTop: 10,
                  }}>
                  <TextInput
                    placeholder="Name*"
                    value={values.name}
                    style={styles.textInput}
                    maxLength={25}
                    keyboardType='default'
                    onChangeText={handleChange('name')}
                    onBlur={handleBlur('name')}
                  />
                </View>
                {errors.name && touched.name && (
                  <Text style={styles.errorStyle}>{errors.name}</Text>
                )}
              
                <View
                  style={styles.textInputView}>
                  <View
                    style={styles.innerBtn}>
                    <MaterialCommunityIcons
                      color={COLORS.lightBlue}
                      name="email-outline"
                      size={25}
                      style={styles.iconStyle}
                    />
                  </View>
                  <TextInput
                    placeholder="Email Id*"
                    value={values.email}
                    maxLength={45}
                    keyboardType='email-address'
                    style={styles.textInput}
                    onChangeText={handleChange('email')}
                    onBlur={handleBlur('email')}
                  />
                </View>
                {errors.email && touched.email && (
                  <Text style={styles.errorStyle}>{errors.email}</Text>
                )}
                  {/* <View
                  style={styles.textInputView}>
                  <TextInput
                    placeholder="other"
                    value={values.other}
                    editable={false} 
                    selectTextOnFocus={false}
                    style={styles.textInput}
                    onChangeText={handleChange('other')}
                    onBlur={handleBlur('other')}
                  />
                </View> */}
               

                  <View
                  style={styles.textInputView}>
                  <TextInput
                    placeholder="Password"
                    value={values.password}
                    maxLength={10}
                    keyboardType='default'
                    style={styles.textInput}
                    onChangeText={handleChange('password')}
                    onBlur={handleBlur('password')}
                  />
                </View>
                {errors.password && touched.password && (
                  <Text style={styles.errorStyle}>{errors.password}</Text>
                )}

              </View>

              <View
                style={{
                  flex: 1,
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                }}>
                <TouchableOpacity
                  style={styles.buttonStyle}
                  onPress={() => handleSubmit()}>
                  <Text style={styles.textStyle}>Submit</Text>
                </TouchableOpacity>
              </View>
            </>
          )}
        </Formik>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  textInputView: {
    width: dpforWidth(90),
    height: dpforHeight(7),
    margin: 5,
    flexDirection: 'row',
    backgroundColor: COLORS.pureWhite,
    marginStart: 20,
    borderRadius: 10,
  },
  textInput: {
    marginHorizontal: 20,
    ...FONTS.appFontSemiBold,
    width: dpforWidth(80),
    },
      innerBtn: {
    justifyContent: 'center',
    borderRadius: 10,
    padding: 5,

    backgroundColor: COLORS.whiteBlue,
  },

  iconStyle: {
    right: 10,
    marginStart: 20,
  },
  buttonStyle: {
    backgroundColor: COLORS.skyBlue,
    width: dpforWidth(90),
    height: dpforHeight(7),
     alignSelf: 'center',
     bottom:0,
     position:'absolute',
     borderRadius:10
   
  },
  textStyle: {
    alignSelf: 'center',
    ...FONTS.appFontSemiBold,
    marginVertical: 15,
    color: COLORS.pureWhite,
    fontWeight: 'bold',
  },
  errorStyle: {
    ...FONTS.appFontSemiBold,
    color: COLORS.red,
    textAlign: 'center',
  },
});
export default AddUserSetting;