import React, {useState} from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  ToastAndroid,
  TouchableOpacity,
  StyleSheet,
  Dimensions
} from 'react-native';
import { dpforHeight,dpforWidth } from '../../constants/SizeScreen';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';
import {Formik} from 'formik';
import axios from 'axios';
import * as yup from 'yup';

import AsyncStorage from '@react-native-async-storage/async-storage';
import { URL } from '../../constants/configure';
const {height, width} = Dimensions.get('window');

const AddExternalProduct = ({navigation}) => {
  const postUser = async values => {
    // console.log('check--------------',values);
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
        URL.BASE_URL+'/external-products',
        values,
        requestOptions,
      );

      // console.log(data);

      if (data.status) {
        ToastAndroid.showWithGravity(
          'External Product Added Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
      navigation.goBack();
    } catch (err) {
      ToastAndroid.showWithGravity(
        'ExternalProduct Added Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };
  const handleSubmit = values => {
    postUser(values);
  };

  const loginValidationSchema = yup.object().shape({
    name: yup.string().required('Please fill out this filed'),
    url: yup.string().required('Please fill out this filed'),
    description: yup.string().required('Please fill out this filed'),
  });
  // navigation = useNavigation();

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Add External Product" />

      <Formik
        validationSchema={loginValidationSchema}
        initialValues={{name: '', url: '', description: ''}}
        onSubmit={handleSubmit}>
        {({handleChange, handleBlur, handleSubmit, errors, touched}) => (
          <>
            <View style={{height: height / 1.2}}>
              <View
                style={{
                  width: dpforWidth(90),
                  height: dpforHeight(7),
                  margin: 5,
                  flexDirection: 'row',
                  backgroundColor: COLORS.pureWhite,
                  marginStart: 20,
                  borderRadius: 10,
                  marginTop: 10,
                }}>
                <TextInput
                  placeholder="Name*"
                  style={GLOBALSTYLES.textInput}
                  maxLength={25}
                  keyboardType='default'
                  onChangeText={handleChange('name')}
                  onBlur={handleBlur('name')}
                />
              </View>
              {errors.name && touched.name && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.name}</Text>
              )}

              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="URL*"
                  style={GLOBALSTYLES.textInput}
                  maxLength={40}
                  keyboardType='default'
                  onChangeText={handleChange('url')}
                  onBlur={handleBlur('url')}
                />
              </View>
              {errors.url && touched.url && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.url}</Text>
              )}

              <View
                style={{
                  width: dpforWidth(90),
                  height: dpforHeight(7),
                  margin: 5,
                  marginStart: 20,
                  backgroundColor: COLORS.pureWhite,
                  borderRadius: 10,
                }}>
                <TextInput
                  placeholder="Description*"
                  style={{ marginHorizontal: 20,
                    fontSize:14,
    
                    marginTop: 1,}}
                  maxLength={200}
                  keyboardType='default'
                  onChangeText={handleChange('description')}
                  onBlur={handleBlur('description')}
                />
              </View>
              {errors.description && touched.description && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.description}</Text>
              )}
            </View>
            <View
              style={{
                flex: 1,
                flexDirection: 'column',
                justifyContent: 'space-between',
              }}>
              <TouchableOpacity
                style={{  
                  width: dpforWidth(90),
                  borderRadius: 10,
                  alignSelf: 'center',
                  bottom: 5,
                  backgroundColor: COLORS.skyBlue,
                  position: 'absolute',}}
                onPress={() => handleSubmit()}>
                <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </Formik>
    </SafeAreaView>
  );
};

export default AddExternalProduct;
