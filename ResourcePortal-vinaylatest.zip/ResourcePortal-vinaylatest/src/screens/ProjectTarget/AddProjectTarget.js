import React, { useState, useEffect } from 'react';
import {
  Text,
  View,
  SafeAreaView,
  ToastAndroid,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import { COLORS, FONTS, GLOBALSTYLES } from '../../constants/theme';
import { Picker } from '@react-native-picker/picker';
import { URL } from '../../constants/configure';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DatePicker from 'react-native-datepicker';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import { Formik } from 'formik';
import * as yup from 'yup';
import { dpforHeight, dpforWidth } from '../../constants/SizeScreen';
const { height, width } = Dimensions.get('window');

const AddProjectTarget = ({ navigation }) => {
  const [newData, setNewData] = useState([]);

  useEffect(() => {
    getResource();
  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/resource', requestOptions);

      // console.log(data.data.data.projectTarget);

      setNewData(data.data.data.resources);
    } catch (error) {
      console.log(error);
    }
  };
  const postUser = async values => {

    // console.log('check------------->>>>', values);

    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };

      const { data } = await axios.post(
        URL.BASE_URL + '/project-target',
        values,
        requestOptions,
      );

      // console.log('check-------------->', data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Project Target Added Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
      navigation.goBack();
    } catch (err) {
      ToastAndroid.showWithGravity(
        'Project Target Not Added Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };
  const handleSubmit = values => {
    postUser(values);
  };
  const loginValidationSchema = yup.object().shape({
    resource: yup.string().required('These field is Required'),
    date: yup
      .date().required('These field is Required')
  });
  const clientsOptions = newData.filter(t => t.resources !== null);
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Project Target" />
      <Formik
        validationSchema={loginValidationSchema}
        initialValues={{
          resource: '',
          date: '',

        }}
        enableReinitialize={true}
        onSubmit={values => {
          handleSubmit(values);
        }}>
        {({
          handleChange,
          handleBlur,
          handleSubmit,
          setFieldValue,
          errors,
          touched,
          values,
        }) => (
          <>
            <View style={{ height: height / 1.2 }}>
              <View
                style={{
                  width: dpforWidth(90),
                  height: dpforHeight(7),
                  margin: 5,
                  marginStart: 20,
                  backgroundColor: COLORS.pureWhite,
                  borderRadius: 10,
                  marginTop: 10,
                }}>
                <Picker
                  selectedValue={values.resource}
                  style={{ margin: 4, bottom: 0 }}
                  mode="dropdown"
                  onValueChange={(itemValue) => (
                    setFieldValue('resource', itemValue)
                  )}>
                  <Picker.Item label="Select Resource*" value="" color="grey" />
                  {clientsOptions.map((item, index) => (
                    <Picker.Item
                      key={item.id}
                      label={`${item.fname} ${item.lname}`}
                      value={item.id}
                    />
                  ))}
                </Picker>
              </View>
              {errors.resource && touched.resource && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.resource}</Text>
              )}
              <TouchableOpacity
                style={{
                  width: dpforWidth(90),
                  height: dpforHeight(7),
                  margin: 5,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  backgroundColor: COLORS.pureWhite,
                  marginStart: 20,
                  borderRadius: 10,
                }}>
                <DatePicker
                  style={{ width: '100%', top: 7 }}
                  date={values.date}
                  mode="date"
                  placeholder="Start Date*"
                  format="DD MMMM YYYY"
                  confirmBtnText="Confirm"
                  cancelBtnText="Cancel"
                  showIcon={false}
                  customStyles={{
                    dateInput: {
                      borderWidth: 0,

                      position: 'absolute',
                      left: 20,
                      fontSize:14,
                    },
                  }}
                  onDateChange={(itemValue) => (
                    setFieldValue('date', itemValue)
                  )}
                />
                <FontAwesome
                  name="calendar-o"
                  size={20}
                  style={{ alignSelf: 'center', right: 30 }}
                />
              </TouchableOpacity>
              {errors.date && touched.date && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.date}</Text>
              )}
            </View>

            <View
              style={{
                flex: 1,
                flexDirection: 'column',
                justifyContent: 'space-between',
              }}>
              <TouchableOpacity
                style={{
                  width: dpforWidth(90),
                  height: dpforHeight(7),
                  borderRadius:10,
                  alignSelf: 'center',
                  bottom: 5,
                  backgroundColor: COLORS.skyBlue,
                  position: 'absolute',
                }}
                onPress={() => handleSubmit()}>
                <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </Formik>
    </SafeAreaView>
  );
};

export default AddProjectTarget;
