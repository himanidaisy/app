import React, { useState, useEffect } from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  Alert,
  Modal,
  StyleSheet,
  TextInput,
  Dimensions,
  ScrollView,
  ActivityIndicator,
  FlatList,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { URL } from '../../constants/configure';
import { COLORS, GLOBALSTYLES } from '../../constants/theme';
import axios from 'axios';
const { height, width } = Dimensions.get('window');
const ViewModal = ({ navigation, route }) => {
  const [loadData, setLoadData] = useState([]);

  // const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [data, setData] = useState({});

  useEffect(() => {
    getResource();
    setData(route.params.newData.resource);

  }, []);
  console.log('datachek------------------->', data);

  //get
  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      // console.log(requestOptions);
      const id = route.params.newData.resource
      console.log('final------------------->', `/resource/${id}`);
      const datass = await axios.get(URL.BASE_URL + `/resource/${id}`, requestOptions);
      console.log('findsome------------------->', datass.data.data.resource);

      setLoadData(datass.data.data.resource);

      setLoding(false);
    } catch (error) {
      console.log(error);
      setLoding(true);
    }
  };
  console.log('omecheck---->', loadData)
  return (
    <SafeAreaView>
      <View style={{ height: height / 1 }}>
        <ScrollView>
          <View style={{ height: height / 0.8 }}>
            <View style={{ backgroundColor: 'white' }}>
              <View style={styles.labelView}>
                <Text style={GLOBALSTYLES.lebal}>Name</Text>
                <View style={styles.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {
                      loadData.fname}
                  </Text>
                </View>
              </View>
              <View style={{ flexDirection: 'column' }}>
                <View style={styles.labelView}>
                  <Text style={GLOBALSTYLES.lebal}>Mobile</Text>
                  <View style={styles.contentView}>

                    <Text style={GLOBALSTYLES.content}>
                      {loadData.phone === null ? '-' : loadData.phone}
                    </Text>
                  </View>
                </View>
                <View style={styles.labelView}>
                  <Text style={GLOBALSTYLES.lebal}>Email</Text>
                  <View style={styles.contentView}>

                    <Text style={GLOBALSTYLES.content}>
                      {loadData.email === null ? '-' : loadData.email}
                    </Text>
                  </View>
                </View>
                <View style={styles.labelView}>
                  <Text style={GLOBALSTYLES.lebal}>Primary Skill</Text>
                  <View style={styles.contentView}>

                    <Text style={GLOBALSTYLES.content}>
                      {loadData.email === null ? '-' : loadData.email}
                    </Text>
                  </View>
                </View>
                <View style={styles.labelView}>
                  <Text style={GLOBALSTYLES.lebal}>Locality</Text>
                  <View style={styles.contentView}>

                    <Text style={GLOBALSTYLES.content}>
                      {loadData.resident_address === null ? '-' : loadData.resident_address}
                    </Text>
                  </View>
                </View>
                <View style={styles.labelView}>
                  <Text style={GLOBALSTYLES.lebal}>DOJ</Text>
                  <View style={styles.contentView}>

                    <Text style={GLOBALSTYLES.content}>
                      {loadData.contract_start_date === null ? '-' : loadData.contract_start_date}
                    </Text>
                  </View>
                </View>
                <View style={styles.labelView}>
                  <Text style={GLOBALSTYLES.lebal}>Passing Year</Text>
                  <View style={styles.contentView}>

                    <Text style={GLOBALSTYLES.content}>
                      {loadData.passing_year === null ? '-' : loadData.passing_year}
                    </Text>
                  </View>
                </View>
                <View style={styles.labelView}>
                  <Text style={GLOBALSTYLES.lebal}>Status</Text>
                  <View style={styles.contentView}>

                    <Text style={GLOBALSTYLES.content}>
                      {loadData.on_bench === null ? '-' : loadData.on_bench}
                    </Text>
                  </View>
                </View>
                <View style={styles.labelView}>
                  <Text style={GLOBALSTYLES.lebal}>On Bench From</Text>
                  <View style={styles.contentView}>

                    <Text style={GLOBALSTYLES.content}>
                      {loadData.end_date === null ? '-' : loadData.end_date}
                    </Text>
                  </View>
                </View>
                <View style={styles.labelView}>
                  <Text style={GLOBALSTYLES.lebal}>Cost</Text>
                  <View style={styles.contentView}>

                    <Text style={GLOBALSTYLES.content}>
                      {loadData.cost === null ? '-' : loadData.cost}
                    </Text>
                  </View>
                </View>
                <View style={styles.labelView}>
                  <Text style={GLOBALSTYLES.lebal}>Vendor</Text>
                  <View style={styles.contentView}>

                    <Text style={GLOBALSTYLES.content}>
                      {loadData.vendor === null ? '-' : loadData?.vendor?.company_name}
                    </Text>
                  </View>
                </View>
              </View>
              <View style={styles.labelView}>
                <Text style={GLOBALSTYLES.lebal}>CV</Text>
                <View style={styles.contentView}>

                  <Text style={GLOBALSTYLES.content}>
                    {loadData.resume === null ? '-' : loadData.resume}
                  </Text>
                </View>
              </View>
              <View style={styles.labelView}>
                <Text style={GLOBALSTYLES.lebal}>Exp Year</Text>
                <View style={styles.contentView}>

                  <Text style={GLOBALSTYLES.content}>
                    {loadData.exp_date === null ? '-' : loadData.exp_date}
                  </Text>
                </View>
              </View>
              <View style={styles.labelView}>
                <Text style={GLOBALSTYLES.lebal}>No. of selected interviews</Text>
                <View style={styles.contentView}>

                  <Text style={GLOBALSTYLES.content}>
                    {/* {loadData.exp_date === null ? '-' : loadData.exp_date} */}
                    1
                  </Text>
                </View>
              </View>
              <View style={styles.labelView}>
                <Text style={GLOBALSTYLES.lebal}>No. of rejected interviews</Text>
                <View style={styles.contentView}>

                  <Text style={GLOBALSTYLES.content}>
                    2
                  </Text>
                </View>
              </View>
              <View style={styles.labelView}>
                <Text style={GLOBALSTYLES.lebal}>No. of hold interviews</Text>
                <View style={styles.contentView}>

                  <Text style={GLOBALSTYLES.content}>
                    2
                  </Text>
                </View>
              </View>
              <View style={styles.labelView}>
                <Text style={GLOBALSTYLES.lebal}>Rec. Questions</Text>
                <View style={styles.contentView}>

                  <Text style={GLOBALSTYLES.content}>
                    yes
                  </Text>
                </View>
              </View>
              <View style={styles.labelView}>
                <Text style={GLOBALSTYLES.lebal}>Scheduled By</Text>
                <View style={styles.contentView}>

                  <Text style={GLOBALSTYLES.content}>
                    Vinay
                  </Text>
                </View>
              </View>

            </View>
          </View>
        </ScrollView>
      </View>
      <View
        style={{
          flex: 1,
          flexDirection: 'column',
          justifyContent: 'space-between',
        }}>
        <TouchableOpacity
          style={{
            width: width - 40,
            borderRadius: 10,
            alignSelf: 'center',
            bottom: 5,
            backgroundColor: 'lightgrey',
            position: 'absolute',
          }}
          onPress={()=> navigation.goBack()}
        >
          <Text style={{
            alignSelf: 'center',
            marginVertical: 15,
            color:'black',
            fontWeight: 'bold',
          }}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  cancelButton: {
    flex: 1,
    backgroundColor: COLORS.redOrange,
    borderRadius: 10,
    padding: 20,
    margin: 15,
    position: 'relative',
    alignSelf: 'center',
    marginEnd: 20,
  },
  editButton: {
    flex: 1,
    backgroundColor: COLORS.skyBlue,
    borderRadius: 10,
    padding: 20,
    margin: 15,
    position: 'relative',
    alignSelf: 'center',
    marginStart: 20,
  },
  cancelButtonText: {
    color: 'black',
    fontSize: 15,
    alignSelf: 'center',
  },
  editButtonText: {
    color: 'black',
    fontSize: 15,
    alignSelf: 'center',
  },

  labelView: {
    flexDirection: 'row',
    margin: 10,
    },
  modalView: {
    width: width - 50,
    backgroundColor: 'yellow',
    borderRadius: 10,
    alignSelf: 'center',
    marginTop: width / 5,
    height: height / 1.3,
    elevation: 1,
  },
  contentView: {
    position: 'absolute', right: 40,

  }
});
export default ViewModal;