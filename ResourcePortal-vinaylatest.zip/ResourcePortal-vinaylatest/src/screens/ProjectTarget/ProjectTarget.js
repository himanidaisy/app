import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  Linking,
  ToastAndroid,
  ActivityIndicator,
  Modal,
  TextInput,
  StyleSheet,
  Dimensions,
} from 'react-native';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';
import SearchBox from '../../components/SearchBox';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import {URL} from '../../constants/configure';
const {height, width} = Dimensions.get('window');

import ErrorBox from 'react-native-vector-icons/MaterialCommunityIcons';
const ProjectTarget = ({navigation}) => {
  const [isModalVisible, setisModalVisible] = useState(false);
  const [isdeleteModalVisible, setisdeleteModalVisible] = useState(false);
  const [choosedeletedata, setchoosedeletedata] = useState();
  const [choosedata, setchoosedata] = useState();
  const changeModalVisible = bool => {
    setisModalVisible(bool);
  };
  const setData = data => {
    setchoosedata(data);
  };
  const changedeleteModalVisible = bool => {
    setisdeleteModalVisible(bool);
  };
  const setdeleteData = data => {
    setchoosedeletedata(data);
  };
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [filterData, setFilterData] = useState([]);

  useEffect(() => {
    getResource();
    getAccountFilterData();
  }, [search, loding, newData]);

  //get
  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/project-target',
        requestOptions,
      );

      //  console.log('find------------------->',data.data.data.projectTarget[0]);
      setNewData(data.data.data.project);

      setLoding(false);
    } catch (error) {
      console.log(error);
      setLoding(true);
    }
  };
  const setSearchValue = value => {
    setSearch(value);
  };
  const getAccountFilterData = () => {
    if (!loding) {
      const filterValue = newData?.filter(data => {
        if (search.length === 0) {
          return data;
        } else if (
          data.resources.fname.toLowerCase().includes(search.toLowerCase()) ||
          data.resources.lname.toLowerCase().includes(search.toLowerCase()) ||
          data.resources.language[0].technology
            .toLowerCase()
            .includes(search.toLowerCase()) ||
          data.resources.resident_address.includes(search.toLowerCase()) ||
          data.date.includes(search)
        ) {
          console.log(data);
          return data;
        }
      });
      setFilterData(filterValue);
    }
  };

  //Delete User
  const deleteUser = async values => {
    // console.log('check__', values);
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'DELETE',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      const {data} = await axios.delete(
        URL.BASE_URL + `/project-target/${values}`,
        // values,
        requestOptions,
      );
      // console.log(data);
      setSearch('');
      const remaningData = newData.filter(t => t.id !== values);
      setFilterData([...remaningData]);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Project Target Deleted Successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
      }
    } catch (err) {
      // console.log(err.response)
      ToastAndroid.showWithGravity(
        'Project Target Not Deleted Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };

  const handleDelete = item => {
    console.log('Delte hit', deleteUser(item.id));
    // deleteUser(item.id);
    getResource();
    console.log('check id', item.id);
    changedeleteModalVisible(false);
  };

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <SearchBox setSearchValue={setSearchValue} />

      {loding ? (
        <ActivityIndicator
          animating={true}
          size="large"
          style={{
            opacity: 1,
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        />
      ) : (
        filterData.length !==0? 

        <FlatList
          data={filterData}
          renderItem={({item}) => (
            <View style={GLOBALSTYLES.appContainer}>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Name</Text>

                <TouchableOpacity onPress={() =>navigation.navigate('Modal Project',{newData:item})}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.resources === null
                      ? '-'
                      : `${item.resources.fname} ${item.resources.lname}`}
                  </Text>
                </TouchableOpacity>
              </View>

              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Locality</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.resources === null
                      ? '-'
                      : item?.resources.resident_address}
                  </Text>
                </View>
              </View>
              <View
                style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                <View style={GLOBALSTYLES.lebalView}>
                  <Text style={GLOBALSTYLES.lebal}>Skill</Text>

                  <Text style={GLOBALSTYLES.content}>
                    {item.resources === null
                      ? '-'
                      : item?.resources.language[0] === null? '-': item?.resources.language[0].technology}
                  </Text>
                </View>
                <View
                  style={{
                    right: 40,
                    flexDirection: 'column',
                    // padding: 10,
                    margin: 10,
                  }}>
                  <Text style={GLOBALSTYLES.lebal}>Target Date</Text>

                  <Text style={GLOBALSTYLES.content}>
                    {item.date === null ? '-' : new Date(item.date).toDateString('en-US', {})
                        .split(' ')
                        .slice(1)
                        .join(' ')}
                  </Text>
                </View>
              </View>
              <View
                style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                <View style={GLOBALSTYLES.lebalView}>
                  <Text style={GLOBALSTYLES.lebal}>Resource Profile</Text>

                  
                  <TouchableOpacity
                    onPress={() =>
                      Linking.openURL(
                        item.resources === null
                          ? '-'
                          : item?.resources.language[0].url,
                        console.log('hey', item.resources.language.url),
                      )
                    }>
                    <Text
                      style={{
                        fontSize:14,
                        color: '#2832C2',
                        marginStart: 3,
                      }}>
                      View
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>

              <View style={{flexDirection: 'row', margin: 10}}>
                <TouchableOpacity
                  style={GLOBALSTYLES.editBtn}
                  onPress={() =>
                    navigation.navigate('Edit Project Target', {newData: item})
                  }>
                  <Text style={GLOBALSTYLES.editText}>Edit</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={GLOBALSTYLES.deleteBtn}
                  onPress={() => changedeleteModalVisible(true)}>
                  <Text style={GLOBALSTYLES.deleteText}>Delete</Text>
                </TouchableOpacity>
                <Modal
                  animationType="fade"
                  transparent={true}
                  visible={isdeleteModalVisible}
                  onRequestClose={() => changedeleteModalVisible(false)}>
                  <View styte={styles.viewContainerView}>
                    <View style={styles.modalView}>
                      <ErrorBox
                        style={styles.iconStyle}
                        name={'alert-box-outline'}
                        size={80}
                        color="red"
                      />
                      <Text style={styles.titleText}> Are you sure?</Text>
                      <View>
                        <Text style={styles.subTitleText}>
                          You won't be able to revert this!
                        </Text>
                        <View
                          style={{
                            flexDirection: 'row',
                            justifyContent: 'space-evenly',
                          }}>
                          <TouchableOpacity
                            style={styles.deleteButton}
                            onPress={() => handleDelete(item)}>
                            <Text style={styles.deleteButtonText}>
                              Yes,delete it!
                            </Text>
                          </TouchableOpacity>
                          <TouchableOpacity
                            style={styles.cancelButton}
                            onPress={() => changedeleteModalVisible(false)}>
                            <Text style={styles.cancelButtonText}>Cancel</Text>
                          </TouchableOpacity>
                        </View>
                      </View>
                    </View>
                  </View>
                </Modal>
              </View>
            </View>
          )}
        /> :<View style={GLOBALSTYLES.mainContainer}><Text style={{alignSelf:'center', margin:'20%',color:'black'}}>No Data Found</Text></View>

      )}
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  viewContainerView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  deleteButton: {
    backgroundColor: 'skyblue',
    borderRadius: 10,
    padding: '5%',
    margin: '6%',
    position: 'relative',
    top: 10,
    width: width / 3,
    left: 15,
  },
  deleteButtonText: {
    fontSize: 17,
    alignSelf: 'center',
    fontWeight: 'bold',
    padding: 1,
    color: 'white',
  },

  cancelButton: {
    backgroundColor: 'red',
    borderRadius: 10,
    padding: '5%',
    margin: '6%',
    position: 'relative',
    top: 10,
    width: width / 3,
  },
  cancelButtonText: {
    alignSelf: 'center',
    fontWeight: 'bold',
    color: 'white',
    fontSize: 17,
    color: 'white',
  },

  textInput: {
    fontSize: 16,
  },
  iconStyledrop: {
    marginLeft: '5%',
    marginTop: 15,
  },

  titleText: {
    fontSize: 17,
    fontWeight: 'bold',
    alignSelf: 'center',
    margin: 10,
    marginTop: 20,
  },
  subTitleText: {
    fontSize: 17,
    alignSelf: 'center',
  },

  iconStyle: {
    alignSelf: 'center',
    marginTop: 15,
  },

  modalView: {
    width: width - 50,
    backgroundColor: 'white',
    borderRadius: 10,
    alignSelf: 'center',
    marginTop: width / 1.3,
    height: height / 3.3,
    elevation: 1,
  },
});
export default ProjectTarget;