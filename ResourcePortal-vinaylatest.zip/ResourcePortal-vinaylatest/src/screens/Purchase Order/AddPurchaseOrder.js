import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  ToastAndroid,
  TouchableOpacity,
  Dimensions,
  StyleSheet,
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, GLOBALSTYLES, FONTS} from '../../constants/theme';
import {Picker} from '@react-native-picker/picker';
import {URL} from '../../constants/configure';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DatePicker from 'react-native-datepicker/datepicker';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Upload from 'react-native-vector-icons/AntDesign';
import DocumentPicker from 'react-native-document-picker';
import {Formik} from 'formik';
import * as yup from 'yup';
import {dpforHeight, dpforWidth} from '../../constants/SizeScreen';
const {height, width} = Dimensions.get('window');

const AddPurchaseOrder = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [res, setRes] = useState([]);

  const [singleFile, setSingleFile] = useState(null);

  useEffect(() => {
    getResource();
    getRes();
  }, []);
  //get client
  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/client', requestOptions);

      // console.log(data.data.data.clients);
      setNewData(data.data.data.clients);
    } catch (error) {
      console.log(error);
    }
  };

  //get resource
  const getRes = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/resource', requestOptions);

      // console.log(data.data.data.projectTarget);

      setRes(data.data.data.resources);
    } catch (error) {
      console.log(error);
    }
  };
  //put
  const postUser = async values => {
    // const store = {

    //   resource_id:getResources,
    //     client_id:id,
    //     order_number:order,
    //     start_date:startDate,
    //     end_date:endDate,
    //     pdf_file:singleFile
    // };
    console.log('valu--------', values);

    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
        URL.BASE_URL + '/purchase',
        values,

        requestOptions,
      );
      console.log('check-------------->', data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Purchase Order Created Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
      navigation.goBack();
    } catch (err) {
      console.log(err.response);
      ToastAndroid.showWithGravity(
        'Purchase Order Not Created Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };
  const handleSubmit = values => {
    postUser(values);
    console.log('values-------', values);
  };
  //get
  const selectFile = async () => {
    try {
      const res = await DocumentPicker.pick({
        type: [DocumentPicker.types.allFiles],
      });
      // console.log('res : ' + JSON.parse(res));
      setSingleFile(res);
    } catch (err) {
      setSingleFile(null);
      if (DocumentPicker.isCancel(err)) {
      } else {
        throw err;
      }
    }
  };
  const nameReg = /^[^-\s][a-zA-Z\s-]+$/;
  const file = /^[a-z0-9_()\-\[\]]+\.pdf$/i;
  const loginValidationSchema = yup.object().shape({
    resource_id: yup.string().required('These field is Required'),
    client_id: yup.string().required('These field is Required'),
    order_number: yup.string().required('These field is Required'),
    start_date: yup.date().required('These field is Required'),
    end_date: yup.date().required('These field is Required'),
    pdf_file: yup
      .string()
      .matches(file, 'Please enter a valid pdf')
      .required('These field is Required'),
  });

  const clientsOptions = newData.filter(t => t.client_name !== null);
  const resOptions = res.filter(t => t.resources !== null);

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Purchase Order" />
      <Formik
        validationSchema={loginValidationSchema}
        initialValues={{
          resource_id: '',
          client_id: '',
          order_number: '',
          start_date: '',
          end_date: '',
          pdf_file: '',
        }}
        enableReinitialize={true}
        onSubmit={values => {
          handleSubmit(values);
        }}>
        {({
          handleChange,
          handleBlur,
          handleSubmit,
          errors,
          touched,
          values,
          setFieldValue,
        }) => (
          <>
            <View style={{height: height / 1.2}}>
              <ScrollView>
                <View style={{height: height / 1.0}}>
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10,
                      marginTop: 10,
                    }}>
                    <Picker
                      selectedValue={values.client_id}
                      style={{margin: 4, bottom: 0}}
                      mode="dropdown"
                      onValueChange={itemValue =>
                        setFieldValue('client_id', itemValue)
                      }>
                      <Picker.Item
                        label="Select Client*"
                        value=""
                        color="grey"
                      />
                      {clientsOptions.map((item, index) => (
                        <Picker.Item
                          key={item.id}
                          label={item.client_name}
                          value={item.id}
                        />
                      ))}
                    </Picker>
                  </View>
                  {errors.client_id && touched.client_id && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.client_id}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      selectedValue={values.resource_id}
                      style={{margin: 4, bottom: 0}}
                      mode="dropdown"
                      onValueChange={itemValue =>
                        setFieldValue('resource_id', itemValue)
                      }>
                      <Picker.Item
                        label="Select Resource*"
                        value=""
                        color="grey"
                      />
                      {resOptions.map((item, index) => (
                        <Picker.Item
                          key={item.id}
                          label={`${item.fname} ${item.lname}`}
                          value={item.id}
                        />
                      ))}
                    </Picker>
                  </View>
                  {errors.resource_id && touched.resource_id && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.resource_id}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Purchase Order Number*"
                      style={GLOBALSTYLES.textInput}
                      // value={order}
                      maxLength={10}
                      keyboardType="numeric"
                      onChangeText={handleChange('order_number')}
                      onBlur={handleBlur('order_number')}
                    />
                  </View>
                  {errors.order_number && touched.order_number && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.order_number}
                    </Text>
                  )}
                  <TouchableOpacity
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <DatePicker
                      style={{width: '100%', top: 7}}
                      date={values.start_date}
                      mode="date"
                      placeholder="Start Date*"
                      format="DD MMMM YYYY"
                      confirmBtnText="Confirm"
                      cancelBtnText="Cancel"
                      showIcon={false}
                      customStyles={{
                        dateInput: {
                          borderWidth: 0,

                          position: 'absolute',
                          left: 20,
                          fontSize:14,
                        },
                      }}
                      onDateChange={itemValue =>
                        setFieldValue('start_date', itemValue)
                      }
                    />
                    <FontAwesome
                      name="calendar-o"
                      size={20}
                      style={{alignSelf: 'center', right: 50}}
                    />
                  </TouchableOpacity>
                  {errors.start_date && touched.start_date && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.start_date}
                    </Text>
                  )}
                  <TouchableOpacity
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <DatePicker
                      style={{width: '100%', top: 7}}
                      date={values.end_date}
                      minDate={values.start_date}
                      mode="date"
                      placeholder="End Date*"
                      format="DD MMMM YYYY"
                      confirmBtnText="Confirm"
                      cancelBtnText="Cancel"
                      showIcon={false}
                      customStyles={{
                        dateInput: {
                          borderWidth: 0,

                          position: 'absolute',
                          left: 20,
                          fontSize:14,
                        },
                      }}
                      onDateChange={itemValue =>
                        setFieldValue('end_date', itemValue)
                      }
                    />
                    <FontAwesome
                      name="calendar-o"
                      size={20}
                      style={{alignSelf: 'center', right: 50}}
                    />
                  </TouchableOpacity>
                  {errors.end_date && touched.end_date && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.end_date}
                    </Text>
                  )}
                <View style={GLOBALSTYLES.textInputView}>
            <TouchableOpacity
                      style={{ flex: 1 }}
                      onPress={() => selectFile()}>
                      <Upload
                        name="upload"
                        color='green'
                        size={20}
                        style={{ left: 10, top: 15 }}
                      />
                    </TouchableOpacity>   
              <TextInput
                placeholder="Upload PDF*"
                style={{fontSize:14,
                  flex: 1,
                  left: 40,
                  bottom: 13,}}
                value={values.pdf_file}
                onChangeText={data => {
                  setFieldValue('pdf_file',data);
                }}
              />
            </View>
                  {errors.pdf_file && touched.pdf_file && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.pdf_file}
                    </Text>
                  )}
                </View>
              </ScrollView>
            </View>

            <TouchableOpacity
              style={styles.buttonStyle}
              onPress={() => handleSubmit()}>
              <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
            </TouchableOpacity>
          </>
        )}
      </Formik>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  buttonStyle: {
    backgroundColor: COLORS.skyBlue,
    width: dpforWidth(90),
    height: dpforHeight(7),
    borderRadius: 10,
    alignSelf: 'center',
    justifyContent: 'center',
    position: 'relative',
    bottom: -10,
  },
});
export default AddPurchaseOrder;