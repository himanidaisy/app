import React, { useState, useEffect } from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  ScrollView,
  Dimensions,
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import { COLORS, FONTS, GLOBALSTYLES } from '../../constants/theme';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import { Picker } from '@react-native-picker/picker';
import axios from 'axios';
import { dpforHeight,dpforWidth } from '../../constants/SizeScreen';
import DatePicker from 'react-native-datepicker';
import Upload from 'react-native-vector-icons/AntDesign';
import DocumentPicker from 'react-native-document-picker';
import { URL } from '../../constants/configure';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Formik } from 'formik';
import * as yup from 'yup';
const { height, width } = Dimensions.get('window');

const EditClientAgreement = ({ route,navigation }) => {

  const [newData, setNewData] = useState([]);
  const [singleFile, setSingleFile] = useState(null);
  const [data, setData] = useState({});
  useEffect(() => {
    getResource();
    setData(route.params.newData);

  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/client', requestOptions);

      //  console.log(data.data.data.clientAgreements);

      setNewData(data.data.data.clients);
    } catch (error) {
      console.log(error);
    }
  };

  const putUser = async values => {
    const id = route.params.newData.id;

    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };

      const { data } = await axios.put(
        URL.BASE_URL + `/client-agreement/${id}`,
        values,

        requestOptions,
      );
      // console.log('check-------------->', data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Purchase Order Updated Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
      navigation.goBack();
    } catch (err) {
      console.log(err.response);
      ToastAndroid.showWithGravity(
        'Purchase Order Not Updated Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };
  const handleSubmit = values => {
    putUser(values);
  };

  const selectFile = async () => {
    try {
      const res = await DocumentPicker.pick({
        type: [DocumentPicker.types.allFiles],
      });
      console.log('res : ' + JSON.stringify(res));
      setSingleFile(res);
    } catch (err) {
      setSingleFile(null);
      if (DocumentPicker.isCancel(err)) {
      } else {
        throw err;
      }
    }
  };
  const nameReg = /^[^-\s][a-zA-Z\s-]+$/;
  const pdf = /^[a-z0-9_()\-\[\]]+\.pdf$/i

  const loginValidationSchema = yup.object().shape({
    client_id: yup.string().required('These field is Required'),
    start_date: yup.date().required('These field is Required'),
    end_date: yup.date().required('These field is Required'),
    title: yup.string().matches(nameReg, 'Please enter a valid name').required('These field is Required'),
    description: yup.string().required('These field is Required'),
    pdf_file: yup.string().matches(pdf, 'Please enter a valid pdf').required('These field is Required'),
    sow: yup.string().matches(nameReg, 'Please enter a valid name').required('These field is Required'),
  });
  const clientsOptions = newData.filter(t => t.client_name !== null);

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Edit Client Agreement" />
      <Formik
        validationSchema={loginValidationSchema}
        initialValues={{

          "client_id":data.client_id,
          "start_date": data.start_date,
          "end_date":data.end_date,
          "title":data.title,
          "description":data.description,
          "pdf_file":data.pdf_file,
          "sow":data.sow,
        }}
        enableReinitialize={true}
        onSubmit={values => {
          handleSubmit(values);
        }}>
        {({
          handleChange,
          handleBlur,
          handleSubmit,
          errors,
          touched,
          values,
          setFieldValue
        }) => (
          <>
            <View style={{ height: height / 1.2 }}>

              <ScrollView>

                <View style={{ height: height / 1.0 }}>

                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10,
                      marginTop: 10,
                    }}>
                    <Picker
                      selectedValue={values.client_id}
                      style={{ margin: 4, bottom: 0 }}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('client_id', itemValue)
                      )}>
                      <Picker.Item label=" Client Name*" value="" color="grey" />
                      {clientsOptions.map((item, index) => (
                        <Picker.Item
                          key={item.id}
                          label={item.client_name}
                          value={item.id}
                        />
                      ))}
                    </Picker>
                  </View>
                  {errors.client_id && touched.client_id && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.client_id}</Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <DatePicker
                      style={{ width: '100%', top: 7 }}
                      date={values.start_date}
                      mode="date"
                      placeholder="Start Date*"
                      format="DD MMMM YYYY"
                      confirmBtnText="Confirm"
                      cancelBtnText="Cancel"
                      showIcon={false}
                      customStyles={{
                        dateInput: {
                          borderWidth: 0,

                          position: 'absolute',
                          left: 20,
                          fontSize:14,
                        },
                      }}
                      onDateChange={(itemValue) => (
                        setFieldValue('start_date', itemValue)
                      )}
                    />
                    <FontAwesome
                      name="calendar-o"
                      size={20}
                      style={{ alignSelf: 'center', right: 50 }}
                    />
                  </View>
                  {errors.start_date && touched.start_date && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.start_date}</Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <DatePicker
                      style={{ width: '100%', top: 7 }}
                      date={values.end_date}
                      mode="date"
                      placeholder="End Date*"
                      minDate={values.start_date}
                      format="DD MMMM YYYY"
                      confirmBtnText="Confirm"
                      cancelBtnText="Cancel"
                      showIcon={false}
                      customStyles={{
                        dateInput: {
                          borderWidth: 0,

                          position: 'absolute',
                          left: 20,
                          fontSize:14,
                        },
                      }}
                      onDateChange={(itemValue) => (
                        setFieldValue('end_date', itemValue)
                      )}
                    />
                    <FontAwesome
                      name="calendar-o"
                      size={20}
                      style={{ alignSelf: 'center', right: 50 }}
                    />
                  </View>
                  {errors.end_date && touched.end_date && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.end_date}</Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Title"
                      style={GLOBALSTYLES.textInput}
                      maxLength={45}
                      value={values.title}
                      onChangeText={handleChange('title')}
                      onBlur={handleBlur('title')}

                    />
                  </View>
                  {errors.title && touched.title && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.title}</Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(15),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10,
                    }}>
                    <TextInput
                      placeholder="Description"
                      style={{
                        marginHorizontal: 20,
                        fontSize:14,
                        marginTop: 1,
                      }}

                      maxLength={200}
                      multiline={true}
                      keyboardType='default'
                      value={values.description}
                      onChangeText={handleChange('description')}
                      onBlur={handleBlur('description')}

                    />
                  </View>
                  {errors.description && touched.description && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.description}</Text>
                  )}

                  <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      selectedValue={values.sow}
                      style={{ margin: 4, bottom: 0 }}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('sow', itemValue)
                      )}>
                      <Picker.Item
                        label="SOW*"
                        value=""
                        color="grey"
                      />
                      <Picker.Item label="sow" value="sow" />
                      <Picker.Item label="po" value="po" />

                    </Picker>
                  </View>
                  {errors.sow && touched.sow && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.sow}</Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TouchableOpacity
                      style={{ flex: 1 }}
                      onPress={() => selectFile()}>
                      <Upload
                        name="upload"
                        color='green'
                        size={20}
                        style={{ left: 10, top: 15 }}
                      />
                    </TouchableOpacity>
                    <TextInput
                      placeholder="SOW Attach*"
                      style={{
                        fontSize:14,
                        flex: 1,
                        left: 40,
                        bottom: 13,marginEnd:50,
                      }}
                      onChangeText={handleChange('pdf_file')}
                      onBlur={handleBlur('pdf_file')}
                      value={values.pdf_file}
                    />
                  </View>
                  {errors.pdf_file && touched.pdf_file && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.pdf_file}
                    </Text>
                  )}
                </View>
              </ScrollView>
            </View>
            <View
              style={{
                flex: 1,
                flexDirection: 'column',
                justifyContent: 'space-between',
              }}>
              <TouchableOpacity
                style={{
                  width: dpforWidth(90),
                  height: dpforHeight(7),
                  alignSelf: 'center',
                  borderRadius:10,
                  bottom: 5,
                  backgroundColor: COLORS.skyBlue,
                  position: 'absolute',
                }}
                onPress={() => handleSubmit()}>
                <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </Formik>
    </SafeAreaView>
  );
};
export default EditClientAgreement;