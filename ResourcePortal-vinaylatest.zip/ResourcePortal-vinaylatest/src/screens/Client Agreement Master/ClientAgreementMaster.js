import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
 Linking,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';
import SearchBox from '../../components/SearchBox';
import axios from 'axios';
import {URL} from '../../constants/configure';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ClientAgreementMaster = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [filterData, setFilterData] = useState([]);


  useEffect(() => {
    getResource();
    getAccountFilterData();
  }, [search, loding, newData]);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/client-agreement',
        requestOptions,
      );
      // console.log(data.data.data.clientAgreements);
      setNewData(data.data.data.clientAgreements);
      setLoding(false);
    } catch (error) {
      // console.log(error);
      setLoding(true);
    }
  };

  const setSearchValue = value => {
    setSearch(value);
  };

  const getAccountFilterData = () => {
    if (!loding) {
      const filterValue = newData?.filter(data => {
        if (search.length === 0) {
          return data;
        } else if (
          data?.title?.toLowerCase().includes(search.toLowerCase()) ||
          data?.description?.toLowerCase().includes(search.toLowerCase()) ||
            data?.start_date?.includes(search) ||
          data?.end_date?.includes(search) ||
          data?.client?.client_name.toLowerCase().includes(search.toLowerCase()))
          // data.start_date.includes(search) ||
          // data.end_date.includes(search))
          {
          // console.log(data);
          return data;
        }
      });
      setFilterData(filterValue);
    }
  };

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <SearchBox search={search} setSearchValue={setSearchValue} />
      {loding ? (
        <ActivityIndicator
          animating={true}
          size="large"
          style={{
            opacity: 1,
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        />
      ) : (
        filterData.length !==0? 

        <FlatList
          data={filterData}
          renderItem={({item}) => (
            <View style={GLOBALSTYLES.appContainer}>
              <View style={GLOBALSTYLES.lebalView}>
                <Text
                  style={GLOBALSTYLES.lebal}>
                  Client Name
                </Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text
                    style={GLOBALSTYLES.content
                    }>
                    {item.client?.client_name === null
                      ? '-'
                      : item?.client?.client_name}
                  </Text>
                </View>
              </View>

                <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
              
               <View style={GLOBALSTYLES.lebalView}>
                  <Text style={GLOBALSTYLES.lebal}>Title</Text>

                  <Text style={GLOBALSTYLES.content}>
                  {item.title === null ? '-' : item.title}

                  </Text>
                </View>
                <View
                  style={{
                    right: 40,
                    flexDirection: 'column',
                    // padding: 10,
                    margin: 10,
                  }}>
                  <Text style={GLOBALSTYLES.lebal}>Start Date</Text>

                  <Text style={GLOBALSTYLES.content}>
                    {item.start_date === null ? '-' : new Date(item.start_date).toDateString('en-US', {})
                        .split(' ')
                        .slice(1)
                        .join(' ')}
                  </Text>
                </View>
               
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                   <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>PDF</Text>

                <Text
                  style={{
                    fontSize:14,
                    color: COLORS.skyBlue,
                    margin: 3,
                  }}
                  onPress={() => {
                    Linking.openURL(
                      item.pdf_file === null ? '-' : item.pdf_file,
                    );
                  }}>
                  View
                </Text>
              </View>
                <View
                  style={{
                    right: 40,
                    flexDirection: 'column',
                    // padding: 10,
                    margin: 10,
                  }}>
                  <Text style={GLOBALSTYLES.lebal}>End Date</Text>

                  <Text style={GLOBALSTYLES.content}>
                    {item.end_date === null ? '-' : new Date(item.end_date).toDateString('en-US', {})
                        .split(' ')
                        .slice(1)
                        .join(' ')}
                  </Text>
                </View>
              </View>

              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Description</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text
                    style={GLOBALSTYLES.content}>
                    {item.description === null ? '-' : item.description}
                  </Text>
                </View>
              </View>
             

              <TouchableOpacity
                style={GLOBALSTYLES.editBtn}
                onPress={() =>
                  navigation.navigate('Edit Client Agreenent', {newData: item})
                }>
                <Text
                  style={{
                    alignSelf: 'center',
                    fontSize:14,
                    marginVertical: 5,
                    color: COLORS.pureWhite,
                    fontWeight: 'bold',
                  }}>
                  Edit
                </Text>
              </TouchableOpacity>
            </View>
          )}
        /> :<View style={GLOBALSTYLES.mainContainer}><Text style={{alignSelf:'center', margin:'20%',color:'black'}}>No Data Found</Text></View>

      )}
    </SafeAreaView>
  );
};


export default ClientAgreementMaster;
