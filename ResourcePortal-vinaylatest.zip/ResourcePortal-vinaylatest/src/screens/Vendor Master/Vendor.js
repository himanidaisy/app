import React, {useEffect, useState} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  ToastAndroid,
} from 'react-native';
import {GLOBALSTYLES, COLORS, FONTS} from '../../constants/theme';
import SearchBox from '../../components/SearchBox';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {URL} from '../../constants/configure';
const Vendor = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [filterData, setFilterData] = useState([]);

  useEffect(() => {
    getResource();
    getAccountFilterData();
  }, [search, loding, newData]);

  //get

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/vendor', requestOptions);

      // console.log(data.data.data.technologies);
      setNewData(data.data.data.vendors);
      setLoding(false);
    } catch (error) {
      console.log(error);
      setLoding(true);
    }
  };

  const setSearchValue = value => {
    setSearch(value);
  };
  const getAccountFilterData = () => {
    if (!loding) {
      const filterValue = newData?.filter(data => {
        if (search.length === 0) {
          return data;
        } else if (
          data.company_name.toLowerCase().includes(search.toLowerCase()) ||
          data.contact_person.toLowerCase().includes(search.toLowerCase()) ||
          // data.nick_name.toLowerCase().includes(search.toLowerCase()) ||

          data.contact_number.toLowerCase().includes(search.toLowerCase()) ||
          data.contact_email.toLowerCase().includes(search.toLowerCase()) ||
          data.pan.toLowerCase().includes(search.toLowerCase()) ||
          data.gst.toLowerCase().includes(search.toLowerCase())
        ) {
          // console.log(data);
          return data;
        }
      });
      setFilterData(filterValue);
    }
  };

  //Delete User
  const deleteUser = async values => {
    console.log('check__', values);
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'DELETE',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      const {data} = await axios.delete(
        URL.BASE_URL+ `/vendor/${values}`,
        //  values,
        requestOptions,
      );
      // console.log(data);
      setSearch('');
      const remaningData = newData.filter(t => t.id !== values);
      setFilterData([...remaningData]);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Vendor Deleted Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
    } catch (err) {
      // console.log(err.response);
      ToastAndroid.showWithGravity(
        'Vendor Not Deleted Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };

  const handleDelete = item => {
    console.log('Delte hit', deleteUser(item.id));
    // deleteUser(item.id);
    getResource();
    console.log('check id', item.id);
  };

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <SearchBox search={search} setSearchValue={setSearchValue} />
      {loding ? (
        <ActivityIndicator
          animating={true}
          size="large"
          style={{
            opacity: 1,
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        />
      ) : (
        filterData.length !==0? 

        <FlatList
          data={filterData}
          renderItem={({item}) => (

            <View style={GLOBALSTYLES.appContainer}>

                <View
                style={{flexDirection: 'row', justifyContent: 'space-between', }}>
                <View style={{flexDirection: 'column'}}>

                <View style={{margin:5}}>
                <Text style={GLOBALSTYLES.lebal}> Company Name</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text
                    style={{
                      ...FONTS.appFontSemiBold,
                      color: 'black',
                      padding: 3,
                      marginStart: 5,
                    }}>
                    {item.company_name === null ? '-' : item.company_name}
                  </Text>
                </View>
              </View>
               <View style={{margin:5,left: 4,}}>
                    <Text style={GLOBALSTYLES.lebal}>Nick Name</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.nick_name == null ? '-' : item.nick_name}
                    </Text>
                  </View>
                  <View style={{margin:10}}>
                <Text style={GLOBALSTYLES.lebal}>Email Id</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text
                    style={GLOBALSTYLES.content}>
                    {item.contact_email === null ? '-' : item.contact_email}
                  </Text>
                </View>
              </View>
              <View style={{margin:5,left: 4 ,}}>
                    <Text style={GLOBALSTYLES.lebal}>CP</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.credit_period == null ? '-' : item.credit_period}
                    </Text>
                  </View>
                 </View>

                <View tyle={{flexDirection: 'column',}}>
                 <View style={{ flexDirection: 'column',
                      margin: 10,
                      position: 'relative',
                      right: 10,}}>
                    <Text style={GLOBALSTYLES.lebal}>Contact Person</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.contact_person == null ? '-' : item.contact_person}
                    </Text>
                  </View>
                  <View style={{ flexDirection: 'column',
                      margin: 10,
                      position: 'relative',
                      right: 10,}}>
                    <Text style={GLOBALSTYLES.lebal}>Mobile</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.contact_number == null ? '-' : item.contact_number}
                    </Text>
                  </View>
                  {/* <View style={{lexDirection: 'column',
                      margin: 10,
                      position: 'relative',
                      top:50,
                      right: 10,}}>
                    <Text style={GLOBALSTYLES.lebal}>PAN Number</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.pan === null ? '-' : item.pan}
                    </Text>
                  </View> */}
                </View>
              </View>
              <View style={{flexDirection: 'row', margin: 10}}>
                <TouchableOpacity
                  style={GLOBALSTYLES.editBtn}
                  onPress={() =>
                    navigation.navigate('Edit Vendor', {newData: item})
                  }>
                  <Text style={GLOBALSTYLES.editText}>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={GLOBALSTYLES.deleteBtn}
                  onPress={() => handleDelete(item)}>
                  <Text style={GLOBALSTYLES.deleteText}>Delete</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        /> :<View style={GLOBALSTYLES.mainContainer}><Text style={{alignSelf:'center', margin:'20%',color:'black'}}>No Data Found</Text></View>

      )}
    </SafeAreaView>
  );
};

export default Vendor;
