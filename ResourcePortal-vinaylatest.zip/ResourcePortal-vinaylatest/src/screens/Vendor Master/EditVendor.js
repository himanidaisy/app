import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  StyleSheet,
  ToastAndroid,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { dpforHeight,dpforWidth} from '../../constants/SizeScreen';
import DatePicker from 'react-native-datepicker';
import { URL } from '../../constants/configure';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import { FONTS, COLORS, GLOBALSTYLES } from '../../constants/theme';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Upload from 'react-native-vector-icons/AntDesign';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { Formik } from 'formik';
import * as yup from 'yup';

import DocumentPicker from 'react-native-document-picker';

const { height, width } = Dimensions.get('window');

const EditVendor = ({ route,navigation }) => {
  const [File, setFile] = useState(null);
  const [data, setData] = useState({});
  useEffect(() => {
    setData(route.params.newData);
  }, []);
  //get
  const selectFile = async () => {
    try {
      const res = await DocumentPicker.pick({
        type: [DocumentPicker.types.allFiles],
      });
      console.log('res : ' + JSON.stringify(res));
      setFile(res);
    } catch (err) {
      setFile(null);
      if (DocumentPicker.isCancel(err)) {
      } else {
        throw err;
      }
    }
  };

  const putUser = async values => {
    const id = route.params.newData.id;

    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };

      const { data } = await axios.put(
        URL.BASE_URL + `/vendor/${id}`,
        values,

        requestOptions,
      );
      // console.log('check-------------->', data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Vendor Updated Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
      navigation.goBack();
    } catch (err) {
      console.log(err.response);
      ToastAndroid.showWithGravity(
        'Vendor Not Updated Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };
  const handleSubmit = values => {
    putUser(values);
  };
  const phoneRegExp =
  /^(\+91)?(-)?\s*?(91)?\s*?(\d{3})-?\s*?(\d{3})-?\s*?(\d{4})$/;
  const nameReg = /^[^-\s][a-zA-Z\s-]+$/;
const pan = /([A-Z]){5}([0-9]){4}([A-Z]){1}$/
const gst = /\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}/
const pdf = /^[a-z0-9_()\-\[\]]+\.pdf$/i
  const loginValidationSchema = yup.object().shape({
    company_name: yup.string().matches(nameReg, 'Please enter a valid name').required('These field is Required'),
    contact_person: yup.string().matches(nameReg, 'Please enter a valid name').required('These field is Required'),
    company_address: yup.string().required('These field is Required'),
    contact_number: yup.string().matches(phoneRegExp, 'Please enter a valid number').required('These field is Required'),
    contact_email: yup.string().email('Email is not valid').required('These field is Required'),
    gst_link: yup.string().matches(pdf, 'Please enter a valid pdf').required('These field is Required'),
    gst: yup.string().matches(gst, 'Please enter a valid gst').required('These field is Required'),
    pan: yup.string().matches(pan, 'Please enter a valid PAN').required('These field is Required'),
    agreement_link: yup.string().matches(pdf, 'Please enter a valid pdf').required('These field is Required'),
    pan_link: yup.string().matches(pdf, 'Please enter a valid pdf').required('These field is Required'),
    credit_period: yup.string().required('These field is Required'),
    invoice_date: yup.date().required('These field is Required'),
    nick_name: yup.string().matches(nameReg, 'Please enter a valid name').required('These field is Required'),

  });

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Edit Vendor" />
      <Formik
        validationSchema={loginValidationSchema}
        initialValues={{
  
            "company_name":data.company_name,
            "contact_person":data.contact_person,
            "company_address":data.company_address,
            "contact_number":data.contact_number,
            "contact_email":data.contact_email,
            "pan":data.pan,
            "gst":data.gst,
            "gst_link":data.gst_link,
            "pan_link":data.pan_link,
            "agreement_link":data.agreement_link,
            "credit_period":data.credit_period,
            "invoice_date":data.invoice_date,
            "nick_name":data.nick_name
        
        }}
        enableReinitialize={true}
        onSubmit={values => {
          handleSubmit(values);
        }}>
        {({
          handleChange,
          handleBlur,
          handleSubmit,
          errors,
          touched,
          values,
          setFieldValue
        }) => (
          <>
            <View style={{ height: height / 1.2 }}>
              <ScrollView>
                <View style={{ height: height / 0.6 }}>
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10,
                      marginTop: 10,
                    }}>
                    <TextInput
                      placeholder="Company Name"
                      style={GLOBALSTYLES.textInput}
                      value={values.company_name}
                      onChangeText={handleChange('company_name')}
                      onBlur={handleBlur('company_name')}
                      keyboardType="default"
                      maxLength={25}
                    />
                  </View>
                  {errors.company_name && touched.company_name && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.company_name}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Nick Name*"
                      style={GLOBALSTYLES.textInput}
                      value={values.nick_name}
                      onChangeText={handleChange('nick_name')}
                      onBlur={handleBlur('nick_name')}
                      keyboardType="default"
                      maxLength={25}

                    />
                  </View>
                  {errors.nick_name && touched.nick_name && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.nick_name}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Contact Person*"
                      style={GLOBALSTYLES.textInput}
                      value={values.contact_person}
                      onChangeText={handleChange('contact_person')}
                      onBlur={handleBlur('contact_person')}
                      keyboardType="default"
                      maxLength={25}
                    />
                  </View>
                  {errors.contact_person && touched.contact_person && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.contact_person}
                    </Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      flexDirection: 'row',

                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 5,

                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <FontAwesome
                        color={COLORS.lightBlue}
                        name="phone"
                        size={30}
                        style={{ right: 10, marginStart: 20 }}
                      />
                    </View>
                    <TextInput
                      placeholder="Mobile*"
                      style={GLOBALSTYLES.textInput}
                      value={values.contact_number}
                      onChangeText={handleChange('contact_number')}
                      onBlur={handleBlur('contact_number')}
                      keyboardType="phone-pad"
                      maxLength={10}
                    />
                  </View>
                  {errors.contact_number && touched.contact_number && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.contact_number}
                    </Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      flexDirection: 'row',

                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 5,

                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <MaterialCommunityIcons
                        color={COLORS.lightBlue}
                        name="email-outline"
                        size={25}
                        style={{ right: 10, marginStart: 20 }}
                      />
                    </View>
                    <TextInput
                      placeholder="Email Id*"
                      style={GLOBALSTYLES.textInput}
                      value={values.contact_email}
                      onChangeText={handleChange('contact_email')}
                      onBlur={handleBlur('contact_email')}
                      keyboardType="email-address"
                      maxLength={45}

                    />
                  </View>
                  {errors.contact_email && touched.contact_email && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.contact_email}
                    </Text>
                  )}

                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10,
                    }}>
                    <TextInput
                      placeholder="Company Address"
                      style={{
                        marginHorizontal: 20,
                        ...FONTS.appFontSemiBold,

                        marginTop: 1,
                      }}
                      value={values.company_address}
                      onChangeText={handleChange('company_address')}
                      onBlur={handleBlur('company_address')}
                      keyboardType='default'
                      maxLength={200}
                      multiline={true}

                    />
                  </View>
                  {errors.company_address && touched.company_address && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.company_address}
                    </Text>
                  )}

                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="PAN Number"
                      style={GLOBALSTYLES.textInput}
                      value={values.pan}
                      onChangeText={handleChange('pan')}
                      onBlur={handleBlur('pan')}
                      keyboardType="default"
                      maxLength={10}
                    />
                  </View>
                  {errors.pan && touched.pan && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.pan}</Text>
                  )}

                  <View style={GLOBALSTYLES.textInputView}>
                    <TouchableOpacity
                      style={{ flex: 1 }}
                      onPress={() => selectFile()}>
                      <Upload
                        name="upload"
                        size={20}
                        color='green'
                        style={{ left: 10, top: 15 }}
                      />
                    </TouchableOpacity>
                    <TextInput
                      placeholder="Upload PAN"
                      style={{
                        ...FONTS.appFontSemiBold,
                        flex: 1,
                        left: 40,
                        bottom: 13,
                        padding:4,
                        marginRight:50
                      }}
                      value={values.pan_link}
                      onChangeText={handleChange('pan_link')}
                      onBlur={handleBlur('pan_link')}
                      keyboardType="default"
                    />
                  </View>
                  {errors.pan_link && touched.pan_link && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.pan_link}
                    </Text>
                  )}

                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="GST Number"
                      style={GLOBALSTYLES.textInput}
                      value={values.gst}
                      onChangeText={handleChange('gst')}
                      onBlur={handleBlur('gst')}
                      keyboardType="default"
                      maxLength={15}
                    />
                  </View>
                  {errors.gst && touched.gst && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.gst}</Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TouchableOpacity
                      style={{ flex: 1 }}
                      onPress={() => selectFile()}>
                      <Upload
                        name="upload"
                        color='green'
                        size={20}
                        style={{ left: 10, top: 15 }}
                      />
                    </TouchableOpacity>
                    <TextInput
                      placeholder="Upload GST"
                      style={{
                        ...FONTS.appFontSemiBold,
                        flex: 1,
                        left: 40,
                        bottom: 13,
                        padding:4,
                        marginRight:50
                      }}
                      value={values.gst_link}
                      onChangeText={handleChange('gst_link')}
                      onBlur={handleBlur('gst_link')}
                      keyboardType="default"
                    />
                  </View>
                  {errors.gst_link && touched.gst_link && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.gst_link}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TouchableOpacity
                      style={{ flex: 1 }}
                      onPress={() => selectFile()}>
                      <Upload
                        name="upload"
                        color='green'
                        size={20}
                        style={{ left: 10, top: 15 }}
                      />
                    </TouchableOpacity>
                    <TextInput
                      placeholder="Upload Agreement"
                      style={{
                        ...FONTS.appFontSemiBold,
                        flex: 1,
                        left: 40,
                        bottom: 13,
                        padding:4,
                        marginRight:50
                      }}
                      value={values.agreement_link}
                      onChangeText={handleChange('agreement_link')}
                      onBlur={handleBlur('agreement_link')}
                      keyboardType="default"
                      
                    />
                  </View>
                  {errors.agreement_link && touched.agreement_link && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.agreement_link}
                    </Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Credit Period"
                      style={GLOBALSTYLES.textInput}
                      value={values.credit_period}
                      onChangeText={handleChange('credit_period')}
                      onBlur={handleBlur('credit_period')}
                      keyboardType='numeric'
                      maxLength={3}
                    />
                  </View>
                  {errors.credit_period && touched.credit_period && (
                    <Text style={GLOBALSTYLES.errorStyle}>
                      {errors.credit_period}
                    </Text>
                  )}
               
                  <TouchableOpacity
          style={{
            width: dpforWidth(90),
            height: dpforHeight(7),
            margin: 5,
            flexDirection: 'row',
            justifyContent: 'space-between',
            backgroundColor: COLORS.pureWhite,
            marginStart: 20,
            borderRadius: 10,
          }}>
          <DatePicker
            style={{    width: dpforWidth(100),
              top: 7}}
            date={values.invoice_date}
            mode="date"
            placeholder="Invoice Date*"
            format="DD MMMM YYYY"
            confirmBtnText="Confirm"
            cancelBtnText="Cancel"
            showIcon={false}
            customStyles={{
              dateInput: {
                borderWidth: 0,

                position: 'absolute',
                left: 20,
                ...FONTS.appFontSemiBold,
              },
            }}
            onDateChange={(itemValue) => (
              setFieldValue('invoice_date', itemValue)
            )} 
          />
          <FontAwesome
            name="calendar-o"
            size={20}
            style={{alignSelf: 'center', position:'absolute',right: 15}}
          />
        </TouchableOpacity>
        {errors.invoice_date && touched.invoice_date && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.invoice_date}</Text>
                  )}
                </View>
              </ScrollView>
            </View>
            <View style={{ flex: 1, flexDirection: 'column' }}>
              <TouchableOpacity
                style={{
                  width: dpforWidth(90),
                  height: dpforHeight(7),
                  alignSelf: 'center',
                  bottom: 0,
                  backgroundColor: COLORS.skyBlue,
                  borderRadius:10,
                  position: 'absolute',
                }}
                onPress={() => {
                  handleSubmit();
                }}>
                <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </Formik>
    </SafeAreaView>
  );
};
export default EditVendor;