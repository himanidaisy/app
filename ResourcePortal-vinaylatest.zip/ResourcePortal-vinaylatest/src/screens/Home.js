import React from 'react';
import {
  Text,
  View,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
} from 'react-native';
import {COLORS, GLOBALSTYLES, FONTS} from '../constants/theme';
import AntDesign from 'react-native-vector-icons/AntDesign';
import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons';
const {height, width} = Dimensions.get('window');
const Home = () => {
  return (
    <SafeAreaView>
      <ScrollView>
        <ScrollView horizontal={true}>
          <View style={{flexDirection: 'row'}}>
            <View
              style={{
                backgroundColor: 'white',
                width: width / 2.3,
                borderRadius: 10,
                height: height / 10,
                marginTop: 15,
                marginStart: 22,
              }}>
              <View style={{flexDirection: 'column'}}>
                <Text style={styles.numberText}>150</Text>
                <Text style={styles.titleText}>Total Resources</Text>
              </View>
            </View>
            <View
              style={{
                backgroundColor: 'white',
                width: width / 2.3,
                borderRadius: 10,
                height: height / 10,
                marginTop: 15,
                marginStart: 20,
              }}>
              <View style={{flexDirection: 'column'}}>
                <Text style={styles.inumberText}>112</Text>
                <Text style={styles.titleText}>In House Resources</Text>
              </View>
            </View>
            <View
              style={{
                backgroundColor: 'white',
                width: width / 2.3,
                borderRadius: 10,
                height: height / 10,
                marginTop: 15,
                marginStart: 20,
              }}>
              <View style={{flexDirection: 'column'}}>
                <Text style={styles.inumberText}>112</Text>
                <Text style={styles.titleText}>Client Side Resource</Text>
              </View>
            </View>
            <View
              style={{
                backgroundColor: 'white',
                width: width / 2.3,
                borderRadius: 10,
                height: height / 10,
                marginTop: 15,
                marginStart: 20,
              }}>
              <View style={{flexDirection: 'column'}}>
                <Text style={styles.inumberText}>112</Text>
                <Text style={styles.titleText}>Total Clients</Text>
              </View>
            </View>

            <View
              style={{
                backgroundColor: 'white',
                width: width / 2.3,
                borderRadius: 10,
                height: height / 10,
                marginTop: 15,
                marginStart: 20,
              }}>
              <View style={{flexDirection: 'column'}}>
                <Text style={styles.inumberText}>112</Text>
                <Text style={styles.titleText}> Active Clients</Text>
              </View>
            </View>
          </View>
        </ScrollView>
        <View style={styles.boxcontainer}>
          <View style={styles.boxcontainerstyle}>
            <Text style={styles.boxtitleText}> Top Clients </Text>
            <TouchableOpacity>
              <AntDesign
                style={styles.iconStyle}
                name={'arrowright'}
                size={26}
                color={COLORS.pureWhite}
              />
            </TouchableOpacity>
          </View>
          <View style={{padding: 10, marginBottom: 5}}>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Sharekhan </Text>
              <Text style={styles.headingtext}> 25 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Linkin Time </Text>
              <Text style={styles.headingtext}> 63 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Brand Catalyst Media </Text>
              <Text style={styles.headingtext}> 88 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Linkin Time </Text>
              <Text style={styles.headingtext}> 24 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Happiest Minds </Text>
              <Text style={styles.headingtext}> 65 </Text>
            </View>
          </View>
        </View>
        <View style={styles.boxcontainer}>
          <View style={styles.boxcontainerstyle}>
            <Text style={styles.boxtitleText}> Notes </Text>
            <TouchableOpacity>
              <AntDesign
                style={styles.iconStyle}
                name={'plus'}
                size={26}
                color={COLORS.pureWhite}
              />
            </TouchableOpacity>
          </View>
          <View style={{padding: 15, marginBottom: 5}}>
            <View style={styles.textStyle}>
              <Text style={{fontSize: 17, color: 'black'}}>
                Soniya payment pending
              </Text>
            </View>
            <View style={{flexDirection: 'row'}}>
              <Text
                style={{
                  fontSize: 13,
                  color: 'grey',
                  marginStart: 15,
                }}>
                Added by: Sagar
              </Text>
              <TouchableOpacity style={{marginStart: width / 2.2}}>
                <SimpleLineIcons
                  style={styles.iconStyle}
                  name="pencil"
                  color={COLORS.orange}
                  size={20}
                />
              </TouchableOpacity>
              <TouchableOpacity style={{marginStart: '6%'}}>
                <AntDesign
                  style={styles.iconStyle}
                  name={'delete'}
                  size={20}
                  color={COLORS.red}
                />
              </TouchableOpacity>
            </View>
            <Text
              style={{
                fontSize: 13,
                color: 'grey',
                marginStart: 15,
              }}>
              Last Modified: 23 Oct 2020 (by Sagar)
            </Text>
          </View>
          <View
            style={{
              padding: 15,
              position: 'relative',
              bottom: 20,
            }}>
            <View style={styles.textStyle}>
              <Text style={{fontSize: 17, color: 'black'}}>
                Amit payment pending
              </Text>
            </View>
            <View style={{flexDirection: 'row'}}>
              <Text
                style={{
                  fontSize: 13,
                  color: 'grey',
                  marginStart: 15,
                }}>
                Added by: Sagar
              </Text>
              <TouchableOpacity style={{marginStart: width / 2.2}}>
                <SimpleLineIcons
                  style={styles.iconStyle}
                  name="pencil"
                  color={COLORS.orange}
                  size={20}
                />
              </TouchableOpacity>
              <TouchableOpacity style={{marginStart: '6%'}}>
                <AntDesign
                  style={styles.iconStyle}
                  name={'delete'}
                  size={20}
                  color={COLORS.red}
                />
              </TouchableOpacity>
            </View>
            <Text
              style={{
                fontSize: 13,
                color: 'grey',
                marginStart: 15,
              }}>
              Last Modified: 23 Oct 2020 (by Sagar)
            </Text>
          </View>
        </View>
        <View style={styles.boxcontainer}>
          <View style={styles.boxcontainerstyle}>
            <Text style={styles.boxtitleText}> Resources </Text>
          </View>

          <View style={{padding: 10, marginBottom: 5}}>
            <View
              style={{flexDirection: 'row', justifyContent: 'space-between'}}>
              <View style={{flexDirection: 'column'}}>
                <Text style={styles.rnumberText}>345</Text>
                <Text style={styles.rtitleText}>Current</Text>
              </View>
              <View style={{flexDirection: 'column'}}>
                <Text style={styles.rnumberText}>547</Text>
                <Text style={styles.rtitleText}>Upcoming</Text>
              </View>
              <View style={{flexDirection: 'column'}}>
                <Text style={styles.rnumberText}>245</Text>
                <Text style={styles.rtitleText}>External</Text>
              </View>
              <View style={{flexDirection: 'column'}}>
                <Text style={styles.rnumberText}>876</Text>
                <Text style={styles.rtitleText}>Project</Text>
              </View>
            </View>
          </View>
        </View>
        <View style={styles.infocontainer}>
          <View style={{padding: 10}}>
            <Text style={GLOBALSTYLES.lebal}>Name</Text>

            <Text style={GLOBALSTYLES.content}> Shwetali Sangle</Text>
          </View>
          <View style={GLOBALSTYLES.lebalView}>
            <Text style={GLOBALSTYLES.lebal}>Address</Text>

            <Text style={GLOBALSTYLES.content}>36 China town</Text>
          </View>
          <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
            <View style={{flexDirection: 'column'}}>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Technology</Text>

                <Text style={GLOBALSTYLES.content}>Business Analyst</Text>
              </View>

              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>CV</Text>

                <Text style={GLOBALSTYLES.content}> 1 year</Text>
              </View>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Email Id</Text>

                <Text style={GLOBALSTYLES.content}>abc@gmail.com</Text>
              </View>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>SR</Text>

                <Text style={GLOBALSTYLES.content}>23/56</Text>
              </View>
            </View>
            <View tyle={{flexDirection: 'column'}}>
              <View style={GLOBALSTYLES.secondlabelView}>
                <Text style={GLOBALSTYLES.lebal}>Experience</Text>
                <Text style={GLOBALSTYLES.content}>1 year</Text>
              </View>
              <View style={GLOBALSTYLES.secondlabelView}>
                <Text style={GLOBALSTYLES.lebal}>Client Name</Text>

                <Text style={GLOBALSTYLES.content}>Happiest Minds</Text>
              </View>

              <View style={GLOBALSTYLES.secondlabelView}>
                <Text style={GLOBALSTYLES.lebal}>Mobile</Text>

                <Text style={GLOBALSTYLES.content}>4623461284</Text>
              </View>

              <View style={GLOBALSTYLES.secondlabelView}>
                <Text style={GLOBALSTYLES.lebal}>Idle</Text>

                <Text style={GLOBALSTYLES.content}>374</Text>
              </View>
            </View>
          </View>

          <View style={GLOBALSTYLES.lebalView}>
            <Text style={GLOBALSTYLES.lebal}>End date</Text>

            <Text style={GLOBALSTYLES.content}>31 dec</Text>
          </View>
        </View>
        <View style={styles.boxcontainer}>
          <View style={styles.boxcontainerstyle}>
            <Text style={styles.boxtitleText}> Resource Contract Ends </Text>
            <Text style={styles.contractboxtitleText}> 30d </Text>
            <TouchableOpacity>
              <AntDesign
                style={styles.iconStyle}
                name={'arrowright'}
                size={26}
                color={COLORS.pureWhite}
              />
            </TouchableOpacity>
          </View>
          <View style={{padding: 10, marginBottom: 5}}>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Sharekhan </Text>
              <Text style={styles.headingtext}> 30 May 2021 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Illena D'Cruz </Text>
              <Text style={styles.headingtext}> 30 May 2021 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Omkar Joshi </Text>
              <Text style={styles.headingtext}> 30 May 2021 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Rajesh Jain </Text>
              <Text style={styles.headingtext}> 30 May 2021 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Ajay Kumbhar </Text>
              <Text style={styles.headingtext}> 30 May 2021 </Text>
            </View>
          </View>
        </View>
        <View style={styles.boxcontainer}>
          <View style={styles.boxcontainerstyle}>
            <Text style={styles.boxtitleText}> Purchase Order Ends </Text>
            <Text style={styles.contractboxtitleText}> 30d </Text>
            <TouchableOpacity>
              <AntDesign
                style={styles.iconStyle}
                name={'arrowright'}
                size={26}
                color={COLORS.pureWhite}
              />
            </TouchableOpacity>
          </View>
          <View style={{padding: 10, marginBottom: 5}}>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Sharekhan </Text>
              <Text style={styles.headingtext}> 30 May 2021 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Illena D'Cruz </Text>
              <Text style={styles.headingtext}> 30 May 2021 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Omkar Joshi </Text>
              <Text style={styles.headingtext}> 30 May 2021 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Rajesh Jain </Text>
              <Text style={styles.headingtext}> 30 May 2021 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Ajay Kumbhar </Text>
              <Text style={styles.headingtext}> 30 May 2021 </Text>
            </View>
          </View>
        </View>

        <View style={styles.boxcontainer}>
          <View style={styles.boxcontainerstyle}>
            <Text style={styles.boxtitleText}> Client Agreement Ends </Text>
            <Text style={styles.contractboxtitleText}> 30d </Text>
            <TouchableOpacity>
              <AntDesign
                style={styles.iconStyle}
                name={'arrowright'}
                size={26}
                color={COLORS.pureWhite}
              />
            </TouchableOpacity>
          </View>
          <View style={{padding: 10, marginBottom: 5}}>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Sharekhan </Text>
              <Text style={styles.headingtext}> 30 May 2021 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Illena D'Cruz </Text>
              <Text style={styles.headingtext}> 30 May 2021 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Omkar Joshi </Text>
              <Text style={styles.headingtext}> 30 May 2021 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Rajesh Jain </Text>
              <Text style={styles.headingtext}> 30 May 2021 </Text>
            </View>
            <View style={styles.textStyle}>
              <Text style={styles.headingtext}> Ajay Kumbhar </Text>
              <Text style={styles.headingtext}> 30 May 2021 </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  numberText: {
    color: 'darkorange',
    fontSize: 40,
    fontWeight: 'bold',
    marginStart: 20,
    marginTop: 10,
  },
  titleText: {
    fontSize: 20,
    color: 'grey',
    marginStart: 20,
  },
  rtitleText: {
    fontSize: 18,
    color: 'grey',
    marginStart: 20,
  },
  contractboxtitleText: {
    color: COLORS.pureWhite,
    fontWeight: 'bold',
    fontSize: 17,
    marginStart: width / 4,
  },
  inumberText: {
    color: 'skyblue',
    fontSize: 40,
    fontWeight: 'bold',
    marginStart: 20,
    marginTop: 10,
  },
  viewcontainer: {
    flex: 1,
    backgroundColor: 'white',
    borderRadius: 10,
    marginTop: 15,
    marginStart: 20,
  },
  infocontainer: {
    borderRadius: 10,
    marginStart: 20,
    marginTop: 10,
    backgroundColor: COLORS.pureWhite,
  },
  boxcontainer: {
    borderRadius: 10,
    marginHorizontal: 20,
    marginTop: 10,
    backgroundColor: COLORS.pureWhite,
  },
  boxcontainerstyle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: 'skyblue',
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  boxtitleText: {
    color: COLORS.pureWhite,
    fontWeight: 'bold',
    fontSize: 17,
  },
  textStyle: {
    flexDirection: 'row',
    padding: '3%',
    justifyContent: 'space-between',
  },
  headingtext: {
    color: 'black',
    fontSize: 16,
  },
  rnumberText: {
    color: 'black',
    fontSize: 18,
    fontWeight: 'bold',
    marginStart: 20,
  },
});
export default Home;