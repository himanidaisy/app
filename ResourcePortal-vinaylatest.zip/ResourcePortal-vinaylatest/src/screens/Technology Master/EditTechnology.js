import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  ToastAndroid,
  TouchableOpacity,
  Dimensions,
  StyleSheet,
  ActivityIndicator

} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import { dpforWidth,dpforHeight } from '../../constants/SizeScreen';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';
import {Formik} from 'formik';
import {URL} from '../../constants/configure';
import axios from 'axios';
import * as yup from 'yup';
import AsyncStorage from '@react-native-async-storage/async-storage';
const {height, width} = Dimensions.get('window');

const EditTechnology = ({route, navigation}) => {
  const [data, setData] = useState({});
  const [name, setName] = useState('');

  useEffect(() => {
    setData(route.params.newData);
    setName(route.params.newData);
  }, []);

  const nameReg = /^[^-\s][a-zA-Z\s-]+$/;
  const logo = '((http|https)://)(www.)?[a-zA-Z0-9@:%.\\+~#?&//=]{2,256}\\.[a-z]{2,6}\\b([-a-zA-Z0-9@:%.\\+~#?&//=]*)';

  const loginValidationSchema = yup.object().shape({
    technology: yup.string().required('These field is Required').matches(nameReg, 'Please enter a valid name'),
    url: yup.string().required('Please fill out this filed').matches(logo, 'Please enter a valid url'),
  });
  //put
  const putUser = async values => {
    console.log(values);
    const id = route.params.newData.id;
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.put(
        URL.BASE_URL+`/technology/${id}`,
        values,
        requestOptions,
      );
      // console.log(data);
      setData(route.params.newData);
      setName(route.params.newData);
      
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Technology Data Updated Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
      navigation.goBack();
    } catch (err) {
      console.log(err.response);
      ToastAndroid.showWithGravity(
        'Technology Data Not Updated Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };
  const handleSubmit = values => {
    putUser(values);
    // console.log('values-------', values);
  };

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Edit Technology" />
      
      <Formik
        validationSchema={loginValidationSchema}
        initialValues={{technology: data.technology, url: data.url}}
        enableReinitialize={true}
        onSubmit={values => {
          handleSubmit(values);
        }}>
        {({
          handleChange,
          handleBlur,
          handleSubmit,
          errors,
          touched,
          values,
        }) => (
          <>
      
      <View style={{height: height/1.2}}>

            <View
              style={{
                height: dpforHeight(7),
                width: dpforWidth(90),
                margin: 5,
                marginStart: 20,
                backgroundColor: COLORS.pureWhite,
                borderRadius: 10,
                marginTop: 10,
              }}>
              <TextInput
                placeholder="Name*"
                value={values.technology}
                style={GLOBALSTYLES.textInput}
                onChangeText={handleChange('technology')}
                onBlur={handleBlur('technology')}
                maxLength={25}
                keyboardType='default'
              />
            </View>
            {errors.technology && touched.technology && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.technology}</Text>
            )}

            <View style={GLOBALSTYLES.textInputView}>
              <TextInput
                placeholder="URL*"
                value={values.url}
                style={GLOBALSTYLES.textInput}
                onChangeText={handleChange('url')}
                onBlur={handleBlur('url')}
              />
            </View>
            {errors.url && touched.url && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.url}</Text>
            )}
          </View>
          <View
                style={{
                  flex: 1,
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                }}>
            <TouchableOpacity
              style={GLOBALSTYLES.buttonStyle}
              onPress={() => {
                handleSubmit();
              }}>
              <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
            </TouchableOpacity>
            </View>
          </>
      

        )}
      </Formik>
      
    </SafeAreaView>
  );
};

export default EditTechnology;
