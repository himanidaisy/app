import React, { useEffect, useState } from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  ToastAndroid,
  ActivityIndicator,
  Linking
} from 'react-native';
import { GLOBALSTYLES, COLORS, FONTS } from '../../constants/theme';
import SearchBox from '../../components/SearchBox';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { URL } from '../../constants/configure';
const TechnologyMaster = ({ navigation }) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [filterData, setFilterData] = useState([]);

  useEffect(() => {
    getResource();
    getAccountFilterData();
  }, [search, loding, newData]);

  //get

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      const data = await axios.get(
        URL.BASE_URL + '/technology',
        requestOptions,
      );

      // console.log(data.data.data.technologies);
      setNewData(data.data.data.technologies);
      setLoding(false);
    } catch (error) {
      console.log(error);
      setLoding(true);
    }
  };

  const setSearchValue = value => {
    setSearch(value);
  };
  const getAccountFilterData = () => {
    if (!loding) {
      const filterValue = newData?.filter(data => {
        if (search.length === 0) {
          return data;
        } else if (
          data.technology.toLowerCase().includes(search.toLowerCase()) ||
          data.url.toLowerCase().includes(search.toLowerCase())

        ) {
          console.log(data);
          return data;
        }
      });
      setFilterData(filterValue);
    }
  };

  //Delete User
  const deleteUser = async values => {
    console.log('check__', values);
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'DELETE',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      const { data } = await axios.delete(
        URL.BASE_URL + `/technology/${values}`,
        // values,
        requestOptions,
      );
      console.log(data);
      setSearch('');
      const remaningData = newData.filter(t => t.id !== values);
      setFilterData([...remaningData]);
      setLoding(true);

      if (data.message) {
        ToastAndroid.showWithGravity(
          'Technology Data Deleted Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
    } catch (err) {
      console.log(err.response);
      setLoding(false);

      ToastAndroid.showWithGravity(
        'Technology Data Not Deleted Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );

    }
  };

  const handleDelete = item => {
    console.log('Delte hit', deleteUser(item.id));
    // deleteUser(item.id);
    getResource();
    console.log('check id', item.id);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.white }}>
      <SearchBox search={search} setSearchValue={setSearchValue} />
      {loding ? (
        <ActivityIndicator
          animating={true}
          size="large"

          style={{
            opacity: 1,
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        />
      ) : (
        filterData.length !== 0 ?

          <FlatList

            data={filterData}
            renderItem={({ item }) => (
              <View style={GLOBALSTYLES.appContainer}>
                <View style={GLOBALSTYLES.lebalView}>
                  <Text style={GLOBALSTYLES.lebal}>Technology</Text>
                  <View style={GLOBALSTYLES.contentView}>
                    <Text
                      style={{
                        ...FONTS.appFontSemiBold,
                        color: 'black',
                        margin: 2,
                        marginStart: 5,
                      }}>
                      {item.technology === null ? '-' : item.technology}
                    </Text>
                  </View>
                </View>
                <View style={{ flexDirection: 'row' }}>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Primary Skill</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.count?.primary_resource === null
                        ? '-'
                        : item?.count?.primary_resource}
                    </Text>
                  </View>

                  <View style={{
                    flexDirection: 'column',
                    margin: 10, right: 50, position: 'absolute'
                  }}>
                    <Text style={GLOBALSTYLES.lebal}>URL</Text>

                    <Text
                      style={{
                        ...FONTS.appFontSemiBold,
                        color: COLORS.skyBlue,
                        margin: 3,
                      }}
                      onPress={() => {
                        Linking.openURL(
                          item.url === null ? '-' : item.url,
                        );
                      }}>
                      View
                    </Text>
                  </View>
                </View>




                <View style={{ flexDirection: 'row', margin: 10 }}>
                  <TouchableOpacity
                    style={GLOBALSTYLES.editBtn}
                    onPress={() =>
                      navigation.navigate('Edit Technology', { newData: item })
                    }>
                    <Text style={GLOBALSTYLES.editText}>Edit</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={GLOBALSTYLES.deleteBtn}
                    onPress={() => handleDelete(item)}>
                    <Text style={GLOBALSTYLES.deleteText}>Delete</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          /> : <View style={GLOBALSTYLES.mainContainer}><Text style={{ alignSelf: 'center', margin: '20%', color: 'black' }}>No Data Found</Text></View>

      )}
    </SafeAreaView>
  );
};

export default TechnologyMaster;
