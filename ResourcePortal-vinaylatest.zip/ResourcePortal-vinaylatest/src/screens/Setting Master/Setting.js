import {
  View,
  ActivityIndicator,
  Dimensions,
  Modal,
  Text,
  Linking,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  FlatList,
  StyleSheet,
  TextInput,
} from 'react-native';
import React, { useState, useEffect } from 'react';
import { GLOBALSTYLES, FONTS, COLORS } from '../../constants/theme';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { URL } from '../../constants/configure';
import axios from 'axios';
import SearchBox from '../../components/SearchBox';

const { height, width } = Dimensions.get('window');
const Setting = ({ navigation }) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [filterData, setFilterData] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    getResource();
    getAccountFilterData();
  }, [search, loding, newData]);

  const getAccountFilterData = () => {
    if (!loding) {
      const filterValue = newData?.filter(data => {
        if (search.length === 0) {
          return data;
        } else if (
          data.contact.toLowerCase().includes(search.toLowerCase()) ||
          data.accountant_email.toLowerCase().includes(search.toLowerCase()) ||
          data.cc_email.toLowerCase().includes(search.toLowerCase()) ||
          data.salesperson.toLowerCase().includes(search.toLowerCase()) ||
          data.from_email.toLowerCase().includes(search.toLowerCase()) ||
          data.tech_head_email.toLowerCase().includes(search.toLowerCase()) ||
          data.geofence_email.toLowerCase().includes(search.toLowerCase()) ||
          data.admin_email.toLowerCase().includes(search.toLowerCase()) ||
          data.hr_email.toLowerCase().includes(search.toLowerCase()) ||
          data.reminder_email.toLowerCase().includes(search.toLowerCase()) ||
          data.reminder_days.toLowerCase().includes(search.toLowerCase())
        ) {
          console.log(data);
          return data;
        }
      });
      setFilterData(filterValue);
    }
  };
  const setSearchValue = value => {
    setSearch(value);
  };
  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/setting', requestOptions);
      // console.log(data.data.data.clientAgreements);
      setNewData(data.data.data.settings);
      setLoding(false);
    } catch (error) {
      // console.log(error);
      setLoding(true);
    }
  };

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <ScrollView>
        {/* <SearchBox search={search} setSearchValue={setSearchValue} /> */}
        {loding ? (
          <ActivityIndicator
            animating={true}
            size="large"
            style={{
              opacity: 1,
              position: 'absolute',
              left: 0,
              right: 0,
              top: 0,
              bottom: 0,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          />
        ) : (
          filterData.length !== 0 ?

            <FlatList
              data={filterData}
              renderItem={({ item }) => (
                <View style={GLOBALSTYLES.appContainer}>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Contact</Text>
                    <Text style={styles.content}>
                      {item.contact === null ? '-' : item.contact}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Accountant Email</Text>
                    <Text style={styles.content}>
                      {item.accountant_email === null
                        ? '-'
                        : item.accountant_email}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>CC Email</Text>
                    <Text style={styles.content}>
                      {item.cc_email === null ? '-' : item.cc_email}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Salesperson</Text>
                    <Text style={styles.content}>
                      {item.salesperson === null ? '-' : item.salesperson}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>From Email</Text>
                    <Text style={styles.content}>
                      {item.from_email === null ? '-' : item.from_email}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Tech Head Email</Text>
                    <Text style={styles.content}>
                      {item.tech_head_email === null ? '-' : item.tech_head_email}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Geofence email</Text>
                    <Text style={styles.content}>
                      {item.geofence_email === null ? '-' : item.geofence_email}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Admin Email</Text>
                    <Text style={styles.content}>
                      {item.admin_email === null ? '-' : item.admin_email}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Hr Email</Text>
                    <Text style={styles.content}>
                      {item.hr_email === null ? '-' : item.hr_email}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Reminder Email</Text>
                    <Text style={styles.content}>
                      {item.reminder_email === null ? '-' : item.reminder_email}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Reminder Days</Text>
                    <Text style={styles.content}>
                      {item.reminder_days === null ? '-' : item.reminder_days}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Open Link</Text>
                    <Text
                      style={{
                        ...FONTS.appFontSemiBold,
                        color: COLORS.skyBlue,
                        marginStart: 3,
                      }}
                      onPress={() => {
                        Linking.openURL(
                          'http://144.91.79.237:7500/open-register',
                        );
                      }}>
                      Open Client Register
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'space-evenly',
                    }}>
                    <TouchableOpacity
                      style={styles.editBtn}
                      onPress={() =>
                        navigation.navigate('Edit Setting', { newData: item })
                      }>
                      <Text
                        style={{
                          alignSelf: 'center',
                          ...FONTS.appFontSemiBold,
                          marginVertical: 15,
                          color: COLORS.pureWhite,
                          fontWeight: 'bold',
                        }}>
                        Edit
                      </Text>
                    </TouchableOpacity>
                    <View style={styles.centeredView}>
                      <Modal
                        animationType="slide"
                        transparent={true}
                        visible={modalVisible}
                        onRequestClose={() => {
                          Alert.alert('Modal has been closed.');
                          setModalVisible(!modalVisible);
                        }}>
                        <View style={styles.centeredView}>
                          <View style={styles.modalView}>
                            <TextInput
                              style={styles.modalText}
                              editable={false}
                              selectTextOnFocus={false}>
                              {item.address === null ? '-' : item.address}
                            </TextInput>

                            <TextInput
                              style={styles.modalText}
                              editable={false}
                              selectTextOnFocus={false}>
                              {item.contact === null ? '-' : item.contact}
                            </TextInput>
                            <TextInput
                              style={styles.modalText}
                              editable={false}
                              selectTextOnFocus={false}>
                              {item.accountant_email === null
                                ? '-'
                                : item.accountant_email}
                            </TextInput>

                            <TouchableOpacity
                              style={GLOBALSTYLES.editBtn}
                              onPress={() => setModalVisible(!modalVisible)}>
                              <Text style={{
                                marginHorizontal: 20,
                                color: 'white',
                                flex: 1,
                                marginTop: 5,
                              }}>Cancel</Text>
                            </TouchableOpacity>
                          </View>
                        </View>
                      </Modal>
                      <TouchableOpacity
                        style={[styles.button, styles.buttonOpen]}
                        onPress={() => setModalVisible(true)}>
                        <Text style={styles.textStyle}>View</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              )}
            /> : <View style={GLOBALSTYLES.mainContainer}><Text style={{ alignSelf: 'center', margin: '20%', color: 'black' }}>No Data Found</Text></View>

        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  content: {
    ...FONTS.appFontSemiBold,
    color: 'black',
    margin: 2,
  },
  editBtn: {
    backgroundColor: COLORS.skyBlue,
    flex: 1,
    borderRadius: 10,
    margin: 10,
    right: 0,
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalView: {
    margin: 10,
    backgroundColor: 'white',
    borderRadius: 10,
    height: height / 2.5,
    width: width / 1.5,
    alignItems: 'center',
    shadowColor: '#000',
    elevation: 5,
  },
  // button: {
  //   borderRadius: 20,
  //   padding: 10,
  //   // elevation: 2,
  //   // borderWidth:1
  // },
  // buttonOpen: {
  //   backgroundColor:COLORS.skyBlue,
  //   borderWidth:1
  // },
  buttonClose: {
    backgroundColor: COLORS.white,
    position: 'absolute',
    // width: width / 4,
    flex: 1,
    bottom: 0,
    padding: 20,
    margin: 10,
    borderRadius: 10,
  },
  textStyle: {
    color: COLORS.skyBlue,
    fontWeight: 'bold',
    alignSelf: 'center',
  },
  modalText: {
    marginBottom: 5,
    textAlign: 'center',
    borderWidth: 1,
    borderColor: 'grey',
    padding: 15,
    marginTop: 15,
    color: 'black',
    width: width / 2,
    borderRadius: 10,
    //  flex:1
  },
});
export default Setting;
