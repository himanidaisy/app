import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  Text,
  TextInput,
  View,
  ToastAndroid,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, GLOBALSTYLES, FONTS} from '../../constants/theme';
import {URL} from '../../constants/configure';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ScrollView } from 'react-native-gesture-handler';
import {Formik} from 'formik';
import * as yup from 'yup';
import { dpforHeight,dpforWidth } from '../../constants/SizeScreen';
const {height, width} = Dimensions.get('window');

const EditSetting = ({navigation, route}) => {
  const [newData, setNewData] = useState([]);
  const [data, setData] = useState({});

  
  console.log('valuess', route.params.newData.id);
  useEffect(() => {
    setData(route.params.newData);

  }, []);

  console.log('get----------', route.params.newData);

  
  //put
  const putUser = async values => {

    console.log('check------------->>>>', values);
    const id = route.params.newData.id;

    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.put(
        URL.BASE_URL + `/setting/${id}`,
        values,
        requestOptions,
      );
    console.log('checks-------------->',route.params.newData );
    setData(route.params.newData);


      if (data.message) {
        ToastAndroid.showWithGravity(
          'Setting Updated Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
      navigation.goBack();
    } catch (err) {
      console.log(err);
      ToastAndroid.showWithGravity(
        'Setting Not Updated Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
     console.log('check-------------->', data);
  };
  const phoneRegExp =
  /^(\+91)?(-)?\s*?(91)?\s*?(\d{3})-?\s*?(\d{3})-?\s*?(\d{4})$/;
  const nameReg = /^[^-\s][a-zA-Z\s-]+$/;
  const logo = /\.(gif|jpg|jpeg|tiff|png)$/i;
const length = /^[0-9]*$/;

  const validationSchema = yup.object().shape({
    contact:yup.string().matches(phoneRegExp, 'Please enter a valid number')
    .required('These field is Required'),
    accountant_email:yup.string().email('Email is not valid').required('These field is Required'),
    cc_email:yup.string().email('Email is not valid').required('These field is Required'),
    salesperson:yup.string().required('These field is Required').matches(nameReg, 'Please enter a valid name'),
    from_email:yup.string().email('Email is not valid').required('These field is Required'),
    tech_head_email:yup.string().email('Email is not valid').required('These field is Required'),
    geofence_email:yup.string().email('Email is not valid').required('These field is Required'),
    address:yup.string().required('These field is Required'),
    admin_email:yup.string().email('Email is not valid').required('These field is Required'),
    hr_email:yup.string().email('Email is not valid').required('These field is Required'),
    reminder_email:yup.string().email('Email is not valid').required('These field is Required'),
    reminder_email2:yup.string().email('Email is not valid').required('These field is Required'),
    reminder_days:yup.string().required('These field is Required').matches(length, 'Please enter a valid day'),
    reminder_months:yup.string().required('These field is Required').matches(length, 'Please enter a valid month'),
    telegram_group_name:yup.string().required('These field is Required').matches(nameReg, 'Please enter a valid day'),
    logo:yup.string().required('These field is Required').matches(logo, 'Please enter a valid link'),
    interview_report_email:yup.string().email('Email is not valid').required('These field is Required'),
    bench_email:yup.string().email('Email is not valid').required('These field is Required'),
})
  const handleSubmit = values => {
    putUser(values);
    // console.log('values-------', values);
  };
  return (
    
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Edit Setting" />
      <ScrollView>
      <Formik
          validationSchema={validationSchema}
          initialValues={{
            contact:data.contact,
            accountant_email:data.accountant_email,
            cc_email:data.cc_email,
            salesperson:data.salesperson,
            from_email:data.from_email,
            tech_head_email:data.tech_head_email,
            hr_email:data.hr_email,
            geofence_email:data.geofence_email,
            address:data.address,
            admin_email:data.admin_email,
            reminder_email:data.reminder_email,
            reminder_email2:data.reminder_email2,
            reminder_days:data.reminder_days,
            reminder_months:data.reminder_months,
            telegram_group_name:data.telegram_group_name,
            logo:data.logo,
            interview_report_email:data.interview_report_email,
            bench_email:data.bench_email,
          }}
          enableReinitialize={true}
          onSubmit={values => {
            handleSubmit(values);
          }}>
          {({
            handleChange,
            handleBlur,
            handleSubmit,
            errors,
            touched,
            values,
          }) => (
            <>
      <View style={{height: height /0.5}}>
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Contact"
            style={GLOBALSTYLES.textInput}
            value={values.contact}
            
              onChangeText={handleChange('contact')}
                  onBlur={handleBlur('contact')}
                  keyboardType='phone-pad'
                  maxLength={10}
            />
           
          </View>
          {errors.contact && touched.contact && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.contact}</Text>
              )}
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Accountant Email"
            style={GLOBALSTYLES.textInput}
            value={values.accountant_email}
            onChangeText={handleChange('accountant_email')}
                onBlur={handleBlur('accountant_email')}
                keyboardType='email-address'
                maxLength={45}
          />
         
        </View>
        {errors.accountant_email && touched.accountant_email && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.accountant_email}</Text>
            )}
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="CC Email"
            style={GLOBALSTYLES.textInput}
            value={values.cc_email}
            onChangeText={handleChange('cc_email')}
                onBlur={handleBlur('cc_email')}
                keyboardType='email-address'
                maxLength={45}

          />
         
        </View>
        {errors.cc_email && touched.cc_email && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.cc_email}</Text>
            )}
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Sales Person"
            style={GLOBALSTYLES.textInput}
            value={values.salesperson}
            onChangeText={handleChange('salesperson')}
                onBlur={handleBlur('salesperson')}
                maxLength={25}

          />
         
        </View>
        {errors.salesperson && touched.salesperson && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.salesperson}</Text>
            )}
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="From Email"
            style={GLOBALSTYLES.textInput}
            value={values.from_email}
            onChangeText={handleChange('from_email')}
                onBlur={handleBlur('from_email')}
                keyboardType='email-address'
                maxLength={45}

          />
         
        </View>
        {errors.from_email && touched.from_email && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.from_email}</Text>
            )}
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Tech Head Email"
            style={GLOBALSTYLES.textInput}
            value={values.tech_head_email}
            onChangeText={handleChange('tech_head_email')}
                onBlur={handleBlur('tech_head_email')}
                keyboardType='email-address'
                maxLength={45}

          />
         
        </View>
        {errors.tech_head_email && touched.tech_head_email && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.tech_head_email}</Text>
            )}

        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Geofence Email"
            style={GLOBALSTYLES.textInput}
            value={values.geofence_email}
            onChangeText={handleChange('geofence_email')}
                onBlur={handleBlur('geofence_email')}
                keyboardType='email-address'
                maxLength={45}

          />
         
        </View>
        {errors.geofence_email && touched.geofence_email && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.geofence_email}</Text>
            )}
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Address"
            style={GLOBALSTYLES.textInput}
            value={values.address}
            maxLength={200}
            multiline={true}
            onChangeText={handleChange('address')}
                onBlur={handleBlur('address')}
                keyboardType='email-address'
          />
         
        </View>
        {errors.geofence_email && touched.geofence_email && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.geofence_email}</Text>
            )}
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Admin Email"
            style={GLOBALSTYLES.textInput}
            value={values.admin_email}
            onChangeText={handleChange('admin_email')}
                onBlur={handleBlur('admin_email')}
                keyboardType='email-address'
                maxLength={45}

          />
         
        </View>
        {errors.admin_email && touched.admin_email && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.admin_email}</Text>
            )}
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="HR Email"
            style={GLOBALSTYLES.textInput}
            value={values.hr_email}
            onChangeText={handleChange('hr_email')}
                onBlur={handleBlur('hr_email')}
                keyboardType='email-address'
                maxLength={45}

          />
         
        </View>
        {errors.hr_email && touched.hr_email && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.hr_email}</Text>
            )}
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Reminder Email"
            style={GLOBALSTYLES.textInput}
            value={values.reminder_email}
            onChangeText={handleChange('reminder_email')}
                onBlur={handleBlur('reminder_email')}
                keyboardType='email-address'
                maxLength={45}

          />
         
        </View>
        {errors.reminder_email && touched.reminder_email && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.reminder_email}</Text>
            )}
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Reminder Days"
            style={GLOBALSTYLES.textInput}
            maxLength={2}
            value={values.reminder_days}
            onChangeText={handleChange('reminder_days')}
                onBlur={handleBlur('reminder_days')}
                keyboardType='numeric'

          />
         
        </View>
        {errors.reminder_days && touched.reminder_days && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.reminder_days}</Text>
            )}
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Working Age Reminder Email"
            style={GLOBALSTYLES.textInput}
            value={values.reminder_email2}
            onChangeText={handleChange('reminder_email2')}
                onBlur={handleBlur('reminder_email2')}
                keyboardType='email-address'
                maxLength={45}

          />
         
        </View>
        {errors.reminder_email2 && touched.reminder_email2 && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.reminder_email2}</Text>
            )}
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Reminder Months"
            style={GLOBALSTYLES.textInput}
            value={values.reminder_months}
            maxLength={2}
            onChangeText={handleChange('reminder_months')}
                onBlur={handleBlur('reminder_months')}
                keyboardType='numeric'

          />
         
        </View>
        {errors.reminder_months && touched.reminder_months && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.reminder_months}</Text>
            )}
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Telegram Group Name"
            style={GLOBALSTYLES.textInput}
            value={values.telegram_group_name}
            onChangeText={handleChange('telegram_group_name')}
                onBlur={handleBlur('telegram_group_name')}
                maxLength={25}

                // keyboardType='default'
          />
         
        </View>
        {errors.telegram_group_name && touched.telegram_group_name && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.telegram_group_name}</Text>
            )}
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Company Logo"            
            style={GLOBALSTYLES.textInput}
            value={values.logo}
            onChangeText={handleChange('logo')}
                onBlur={handleBlur('logo')}
                keyboardType='url'
          />
         
        </View>
        {errors.logo && touched.logo && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.logo}</Text>
            )}
       
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Bench Email"
            style={GLOBALSTYLES.textInput}
            value={values.bench_email}
            onChangeText={handleChange('bench_email')}
                onBlur={handleBlur('bench_email')}
                keyboardType='email-address'
                maxLength={45}

          />
         
        </View>
        {errors.bench_email && touched.bench_email && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.bench_email}</Text>
            )}
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Interview Report Email"
            style={GLOBALSTYLES.textInput}
            value={values.interview_report_email}
            onChangeText={handleChange('interview_report_email')}
                onBlur={handleBlur('interview_report_email')}
                keyboardType='email-address'
                maxLength={45}

          />
         
        </View>
        {errors.interview_report_email && touched.interview_report_email && (
              <Text style={GLOBALSTYLES.errorStyle}>{errors.interview_report_email}</Text>
            )}
      </View>
      <View
        style={{
          flex: 1,
          flexDirection: 'column',
          justifyContent: 'space-between',
        }}>
        <TouchableOpacity
          style={{  backgroundColor: COLORS.skyBlue,
            width: dpforWidth(90),
            height: dpforHeight(7),
            borderRadius: 10,
            alignSelf: 'center',
            justifyContent: 'center',
            position: 'absolute',
            bottom: 0,
         }}
         onPress={() => {
          handleSubmit();
        }}>     
             <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
        </TouchableOpacity>
      </View>
      </>
          )}
        </Formik>
      </ScrollView>
    </SafeAreaView>
  );
};

export default EditSetting;