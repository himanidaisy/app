import React, { useEffect, useState } from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  ToastAndroid,
  Dimensions,
  StyleSheet,
  ScrollView,
  TextInput,
  
  Button,
} from 'react-native';
import Toast from 'react-native-simple-toast';

import { dpforHeight, dpforWidth } from '../../constants/SizeScreen';
import DatePicker from 'react-native-datepicker';
import moment from 'moment';
import SearchBox from '../../components/SearchBox';
import { GLOBALSTYLES, COLORS } from '../../constants/theme';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { URL } from '../../constants/configure';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo';
const { height, width } = Dimensions.get('window');

const ExternalProjectInvoiceHistory = ({ navigation }) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [startDate, setStartDate] = useState(new Date());
  // const [modalVisible, setModalVisible] = useState(false);
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  const [year, setYear] = useState(new Date().getFullYear());
  const [sortedData, setSortedData] = useState([]);
  const [visible, setVisible] = React.useState(false);
  const [viewID, setViewID] = useState()
  const showModal = (id) => {
    setVisible(true)
    setViewID(id)
  };
 
  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      // console.log(requestOptions);
      const { data } = await axios.get(
        URL.BASE_URL + '/internal-invoice-history',
        requestOptions,
      );
      // console.log(data.data.monthlyRecords);
      setNewData(data.data.internalInvoiceHistory);
      setLoding(false);
    } catch (error) {
      console.log(error);
      setLoding(true);
    }
  };
  //  not done payment

  const noteDone = async (e,res) => {
    console.log("res------------>", res)
    setVisible(!visible)
    let option = "0";
    let sheet = res.timesheet.toString();
    let voc = res.invoice.toString();
    let fp = res.pf.toString();
    const newValue = {
      ...res,
      timesheet: sheet,
      pf: fp,
      invoice: voc,
      payment: option,
    };
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };

      const { data } = await axios.put(
        URL.BASE_URL + `/internal-invoice-history/${res.id}`, newValue, requestOptions

      );
      console.log('check-------------->', data);
      console.log('newValue--->', newValue)
      setLoding(!loding);

      if (data.message) {

        Toast.showWithGravity('Invoice Data Updated Successfully', Toast.LONG, Toast.BOTTOM);

      }
    } catch (err) {
      console.log(err.response);
      setLoding(!loding);

  Toast.showWithGravity('Invoice Data Not Updated Successfully', Toast.LONG, Toast.BOTTOM);

    }

  }
  // Full done payment

  const FullDone = async (e,ress) => {
    console.log("res------------>", ress)
    setVisible(!visible)
    let option = "1";
    let sheet = ress.timesheet.toString();
    let voc = ress.invoice.toString();
    let fp = ress.pf.toString();
    const newValu = {
      ...ress,
      timesheet: sheet,
      pf: fp,
      invoice: voc,
      payment: option,
    };
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };

      const { data } = await axios.put(
        URL.BASE_URL + `/internal-invoice-history/${ress.id}`, newValu, requestOptions

      );
      console.log('check-------------->', data);
      console.log('newValue--->', newValu)
      setLoding(!loding);
      if (data.message) {
    Toast.showWithGravity('Invoice Data Updated Successfully', Toast.LONG, Toast.BOTTOM);

      }
    } catch (err) {
      console.log(err.response);
      setLoding(!loding);

      Toast.showWithGravity('Invoice Data Not Updated Successfully', Toast.LONG, Toast.BOTTOM);

    }

  }

    // Partial done payment

  const PartialDone = async (e,resh) => {
    console.log("res------------>", resh)
    setVisible(!visible)
    let option = "2";
    let sheet = resh.timesheet.toString();
    let voc = resh.invoice.toString();
    let fp = resh.pf.toString();
    const newValues = {
      ...resh,
      timesheet: sheet,
      pf: fp,
      invoice: voc,
      payment: option,
    };
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };

      const { data } = await axios.put(
        URL.BASE_URL + `/internal-invoice-history/${resh.id}`, newValues, requestOptions

      );
      console.log('check-------------->', data);
      console.log('newValue--->', newValues)
      setLoding(!loding);

      if (data.message) {
        Toast.showWithGravity('Invoice Data Updated Successfully', Toast.LONG, Toast.BOTTOM);

      }
    } catch (err) {
      console.log(err.response);
      setReloadloding(true);

      Toast.showWithGravity('Invoice Data Not Updated Successfully', Toast.LONG, Toast.BOTTOM);

    }

  }


  //invoice
  const toggle = async (e, res) => {
    console.log("best-----<",res)
    if (res.invoice == "0") {
      let voc = "1";
      let clients = res.client_id.toString();
      // console.log('clients', clients);
      let hrd = res.hard_copy.toString();
      let fp = res.pf.toString();
      let option = res.payment.toString();
      let sheet = res.timesheet.toString();
      const newValue = {
        ...res,
        client_id: clients,
        timesheet: sheet,
        hard_copy: hrd,
        pf: fp,
        invoice: voc,
        payment: option,
      };
     
      try {
        const token = await AsyncStorage.getItem('token');
  
        const requestOptions = {
          method: 'PUT',
          Accept: 'application/json',
          'Content-Type': 'application/json',
          headers: { Authorization: 'Bearer ' + token },
        };
  
        const { data } = await axios.put(
          URL.BASE_URL + `/internal-invoice-history/${res.id}`, newValue, requestOptions
  
        );
        console.log('check-------------->', data);
        console.log('newValue--->', newValue)
        setLoding(!loding);
  
        if (data.message) {
          Toast.showWithGravity('Invoice Data Updated Successfully', Toast.LONG, Toast.BOTTOM);

        }
      } catch (err) {
        console.log(err.response);
        setLoding(!loding);
  
        Toast.showWithGravity('Invoice Data Not Updated Successfully', Toast.LONG, Toast.BOTTOM);

      }

    } else {
      let voc = "0";
      let hrd = res.hard_copy.toString();
      let clients = res.client_id.toString();
      let fp = res.pf.toString();
      let option = res.payment.toString();
      let sheet = res.timesheet.toString();
      const newres = {
        ...res,
        client_id: clients,
        timesheet: sheet,
        hard_copy: hrd,
        pf: fp,
        invoice: voc,
        payment: option,
      };
      try {
        const token = await AsyncStorage.getItem('token');
  
        const requestOptions = {
          method: 'PUT',
          Accept: 'application/json',
          'Content-Type': 'application/json',
          headers: { Authorization: 'Bearer ' + token },
        };
  
        const { data } = await axios.put(
          URL.BASE_URL + `/internal-invoice-history/${res.id}`, newres, requestOptions
  
        );
        console.log('check-------------->', data);
        console.log('newValue--->', newres)
        setLoding(!loding);
  
        if (data.message) {
  
          Toast.showWithGravity('Invoice Data Updated Successfully', Toast.LONG, Toast.BOTTOM);

        }
      } catch (err) {
        console.log(err.response);
        setLoding(!loding);
        Toast.showWithGravity('Invoice Data Not Updated Successfully', Toast.LONG, Toast.BOTTOM);

      }

    }
  };

  const setSearchValue = value => {
    setSearch(value);
  };
  const getFilterData = () => {
    // if (!isDataFetch)
    const allids = newData.map(data => {
      return data.client_id;
    });
    const clientid = [...new Set(allids)];
    console.log('clientid', clientid);
    const selectedData = [];
    for (let id of clientid) {
      selectedData.push(
        ...newData.filter(res => {
          if (res.client_id == id && res.month == month && res.year == year) {
            return res;
          }
        }),
      );
    }
    const filteredData = selectedData.filter(data => {
      if (search === '') {
        return data;
      } else if (
        data.client.client_name.toLowerCase().includes(search.toLowerCase())
      ) {
        return data;
      }
    });
    setSortedData(filteredData);
    // }
  };

  const internet = (e,res) => {
    console.log("internet",res.id)
    setModalVisible(!modalVisible)
  }

  const handleDateChange = value => {
    console.log('value', value);
    setYear(new Date(value).getFullYear());
    setMonth(new Date(value).getMonth() + 1);
    setStartDate(value);
  };
  // console.log('month,year', month, year);
  // console.log('sortedData', sortedData);
  useEffect(() => {
    getResource();
    // getAccountFilterData();
    getFilterData();
  }, [search, loding, month, year]);
  // console.log('filterData', filterData)
  return (
         <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <ScrollView>
        <SearchBox search={search} setSearchValue={setSearchValue} />

        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <TouchableOpacity
            style={{
              width: dpforWidth(90),
              height: dpforHeight(7),
              margin: 5,
              flexDirection: 'row',
              justifyContent: 'space-between',
              backgroundColor: COLORS.pureWhite,
              marginStart: 20,
              borderRadius: 10,
            }}>
            <DatePicker
              style={{ width: '100%', top: 7 }}
              date={startDate}
              value={startDate}
              mode="date"
              placeholder="Start Date"
              format="  MMMM YYYY"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              showIcon={false}
              customStyles={{
                dateInput: {
                  borderWidth: 0,

                  position: 'absolute',
                  left: 15,
                  fontSize:14,
                },
              }}
              onDateChange={startDate => {
                handleDateChange(startDate);
              }}
            />
            <FontAwesome
              name="calendar-o"
              size={20}
              style={{ alignSelf: 'center', right: 30 }}
            />
          </TouchableOpacity>
        </View>
        {loding ? (
          <ActivityIndicator
            animating={true}
            size="large"
            style={{
              opacity: 1,
              position: 'absolute',
              left: 0,
              right: 0,
              top: 0,
              bottom: 0,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          />
        ) : (
          sortedData.map((item)=>(
            <View style={GLOBALSTYLES.appContainer}>
            <View style={{ flexDirection: 'row' }}>
              <View style={{ flexDirection: 'column', flex: 1 }}>
                <Text style={styles.titletext}>Month</Text>
                <Text style={styles.titletext}>Client Name</Text>
                <Text style={styles.titletext}>Resource Count</Text>
              </View>
              <View style={{ flexDirection: 'column', flex: 1 }}>
                <Text style={styles.subheadingtext}>
                  {/* {item.month === null ? '-' : item.month} */}
                  {moment(startDate).format('MMMM YYYY')}
                </Text>
                <Text style={styles.subheadingtext}>
                  {item.client?.client_name === null
                    ? '-'
                    : item.client?.client_name}
                </Text>
                <Text style={styles.subheadingtext}>{item.count === null
                    ? '-'
                    : item.count}</Text>
              </View>
            </View>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-around',
              }}>
              <Text style={styles.checkboxtext}>Pay</Text>
           
               <Text style={styles.checkboxtext}>Inv</Text>
               </View>

            <View
              style={{
                flexDirection: 'row',
                bottom: 10,
                justifyContent: 'space-around',
              }}>
             
                <View style={{position:'relative'}}>
              <TouchableOpacity
                style={{ padding: 5, borderWidth: 1 }}
                onPress={()=>showModal(item.id)}
                >
                {item.payment === 0 ? <Entypo
                  name="check"
                  size={20}
                  style={{ alignSelf: 'center' ,color: 'white' }}
                /> : item.payment === 1 ? <Entypo
                  name="check"
                  size={20}
                  style={{ alignSelf: 'center', color: 'green' }}
                /> : item.payment === 2 ? <Entypo
                  name="check"
                  size={20}
                  style={{ alignSelf: 'center', color: 'orange' }}
                /> : "-"}
              </TouchableOpacity>
            
              </View>
              <TouchableOpacity
                style={{ padding: 5, borderWidth: 1 }}
                onPress={(e) => toggle(e,item)}>
                {item.invoice === 0 ? <Entypo
                  name="check"
                  size={20}
                  style={{ alignSelf: 'center' ,color: 'white' }}
                /> : item.invoice === 1 ? <Entypo
                  name="check"
                  size={20}
                  style={{ alignSelf: 'center', color: 'green' }}
                /> : "-"}
              </TouchableOpacity>
            </View>
            {
             viewID === item.id && 
             <View style={{Padding:20,display:visible?"flex":"none",margin:10,alignContent:'center'}}>

                <Text style={{margin:10,left:40,color:'black'}} onPress={(e)=>noteDone(e,item)}>Not Done</Text>
                <Text style={{margin:10,left:40,color:'green'}} onPress={(e)=>FullDone(e,item)}>Full Done</Text>
                <Text style={{margin:10,left:40,color:'orange'}} onPress={(e)=>PartialDone(e,item)}>Partial Done</Text>
              </View>
              }
          </View>
          
              ))
          
        )}
      </ScrollView>
      

    </SafeAreaView>
   
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },

  iconStyledrop: {
    left: width / 4,
    bottom: 25,
  },
  appContainer: {
    marginTop: 20,
    borderRadius: 10,
    margin: 10,
    backgroundColor: COLORS.pureWhite,
  },
  searchcontainer: {
    padding: 10,
    margin: 20,

    backgroundColor: COLORS.pureWhite,
    marginStart: 20,
    borderRadius: 10,
    marginTop: 20,
    border: 'solid',
    borderColor: 'grey',
    borderWidth: 1,
  },
  showtext: {
    marginStart: 20,
    fontSize: 15,
    color: 'black',
    top: 40,
  },
  textValue: {
    fontSize: 15,
    fontWeight: 'bold',
    alignSelf: 'center',
    margin: 10,
    padding: 5,
    color: 'black',
  },
  showbox: {
    backgroundColor: COLORS.pureWhite,
    marginStart: 15,
    borderRadius: 10,
    margin: 20,
    flex: 1,
    border: 'solid',
    borderColor: 'grey',
    borderWidth: 1,
    bottom: 5,
  },
  exportbox: {
    backgroundColor: 'skyblue',
    borderRadius: 10,
    position: 'relative',
    margin: 20,
    alignItems: 'center',
    flex: 1,
    bottom: 5,
    justifyContent: 'center',
  },
  viewContainerView: {
    flex: 1,
  },
  modalView: {
    width: width / 3,
    backgroundColor: COLORS.white,
    borderRadius: 10,
    alignSelf: 'center',
    top: width / 1.15,
    height: height / 5.5,
    right: 20,
  },
  container: {
    borderColor: 'grey',
    borderWidth: 1,
    flex: 1,

    padding: 10,
    margin: 20,
    borderRadius: 10,
  },
  titletext: {
    fontSize:14,
    color: 'grey',
    padding: 10,
    start: 10,
  },
  subheadingtext: {
    fontSize:14,
    color: 'black',
    padding: 10,
  },
  checkboxtext: {
    fontSize:14,
    color: 'grey',
    padding: 20,

  },
});
 export default ExternalProjectInvoiceHistory;