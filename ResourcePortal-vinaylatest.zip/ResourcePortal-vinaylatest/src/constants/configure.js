const BASE_URL = 'http://newresourcing.nimapinfotech.com/api';
export const URL = {
    BASE_URL,
}