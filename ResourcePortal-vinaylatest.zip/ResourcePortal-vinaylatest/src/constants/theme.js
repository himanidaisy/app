import {StyleSheet, Dimensions} from 'react-native';
import {dpforWidth,dpforHeight} from '../constants/SizeScreen'

export const COLORS = {
  black: '#101011',
  lightBlack: '#777777',
  darkPink: '#F9485A',
  blue: '#4A68FF',
  lightBlue: '#91A3FF',
  orange: '#FEAD00',
  brown: '#FF6F00',
  lightPink: '#F38EB0',
  lightGrey: '#C4C4CF',
  navyBlue: '#14153F',
  grey: '#707070',
  white: '#EBEDF2',
  lightBlueC: '#67A0C0',
  red: '#FF0000',
  pureWhite: '#FFFFFF',
  green: '#58A158',
  skyBlue: '#87ceeb',
  whiteBlue: '#CCE5FF',
  lightGreen: '#78BE21',
  redOrange: '#F87750',
};

export const FONTS = {
  appFontSemiBold: {fontSize: 14},
  appFontSemi: {fontSize: 17},
  appFontSmallBold: { fontSize: 12},
  appFontBold: { fontSize: 20},
};

const nimaplogo = require('../../assets/images/nimap-logo.png');
const spalsh = require('../../assets/images/splsh.png');
const menu = require('../../assets/images/menu-bg.jpeg');
const userprofile = require('../../assets/images/user-profile.jpg');
const notes = require('../../assets/images/node.jpeg');

export const IMAGES = {
  nimaplogo,
  spalsh,
  menu,
  userprofile,
  notes
};

export const GLOBALSTYLES = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },

  appContainer: {
    flex: 1,
    backgroundColor: 'white',
    marginVertical: '1%',
    padding: 10,
    marginHorizontal: 20,
    borderRadius: 10,
    backgroundColor: COLORS.pureWhite,
  },
  lebalView: {
    flexDirection: 'column',
    margin: 10,
  },
  secondlabelView: {
    flex: 1,
    flexDirection: 'column',
    margin: 10,
    position: 'relative',
    right: 30,
  },
  lebal: {
    fontSize:14,
    color: 'grey',
    padding: 2,
  },
  content: {
    fontSize:14,
    color: 'black',
    padding: 3,
  },
  editBtn: {
    backgroundColor: COLORS.skyBlue,
    padding: 15,
    flex: 1,
    borderRadius: 10,
    margin: 10,
    right: 7,
  },
  editText: {
    fontSize:17,
    alignSelf: 'center',
    color: COLORS.pureWhite,
    fontWeight: 'bold',
  },
  deleteBtn: {
    backgroundColor: COLORS.darkPink,
    padding: 15,
    flex: 1,
    borderRadius: 10,
    margin: 10,
    left: 5,
  },
  deleteText: {
    fontSize:17,
    alignSelf: 'center',
    color: COLORS.pureWhite,
    fontWeight: 'bold',
  },
  textInputView: {
    width: dpforWidth(90),
    height: dpforHeight(7),
    margin: 5,
    marginStart: 20,
    backgroundColor: COLORS.pureWhite,
    borderRadius: 10,
  },
  textInput: {
    marginHorizontal: 20,
    fontSize:14,
    flex: 1,
    marginTop: 1,
  },
  buttonStyle: {
    width: dpforWidth(90),
    height: dpforHeight(7),
    borderRadius: 10,
    alignSelf: 'center',
    bottom: 1,
    backgroundColor: COLORS.skyBlue,
    position: 'absolute',
  },
  textStyle: {
    alignSelf: 'center',
    fontSize:17,
    marginVertical: 15,
    color: COLORS.pureWhite,
    fontWeight: 'bold',
  },
  iconStyle: {
    alignSelf: 'center',
    marginEnd: 15,
  },
  errorStyle: {
    color: COLORS.red,
    left:'8%'
  },
});
