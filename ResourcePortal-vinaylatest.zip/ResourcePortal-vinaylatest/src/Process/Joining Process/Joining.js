import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  StyleSheet,
  Linking,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import Toast from 'react-native-simple-toast';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';
import SearchBox from '../../components/SearchBox';

import axios from 'axios';
import {URL} from '../../constants/configure';
import AsyncStorage from '@react-native-async-storage/async-storage';
const {height, width} = Dimensions.get('window');
const Joining = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [filterData, setFilterData] = useState([]);

  useEffect(() => {
    getResource();
    getAccountFilterData();
  }, [search, loding, newData]);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/joining', requestOptions);
      // console.log(data.data.data.clientAgreements);
      setNewData(data.data.data.joining);
      setLoding(false);
    } catch (error) {
      // console.log(error);
      setLoding(true);
    }
  };
  const setSearchValue = value => {
    setSearch(value);
  };
  const getAccountFilterData = () => {
    if (!loding) {
      const filterValue = newData?.filter(data => {
        if (search.length === 0) {
          return data;
        } else if (
          data.client?.client_name
            .toLowerCase()
            .includes(!!search && search.toLowerCase()) ||
          data.resource?.fname
            .toLowerCase()
            .includes(!!search && search.toLowerCase()) ||
          data.resource?.lname
            .toLowerCase()
            .includes(!!search && search.toLowerCase()) ||
            data.start_date.includes(!!search && search.toLowerCase()) ||
            data.contract_type
            .toLowerCase()
            .includes(!!search && search.toLowerCase()) ||
            data.end_date.includes(!!search && search.toLowerCase())
        ) {
          return data;
        }
      });
      setFilterData(filterValue);
    }
  }; 
  
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <SearchBox search={search} setSearchValue={setSearchValue} />
      {loding ? (
        <ActivityIndicator
          animating={true}
          size="large"
          style={{
            opacity: 1,
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        />
      ) : (
        filterData.length !==0? 

        <FlatList
          data={filterData}
          renderItem={({item}) => (
            <View style={GLOBALSTYLES.appContainer}>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Resources</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {[
                      item.resource?.fname === null
                        ? '-'
                        : item?.resource?.fname,
                      '  ',
                      item.resource?.lname === null
                        ? '-'
                        : item?.resource?.lname,
                    ]}
                  </Text>
                </View>
              </View>
              <View
                style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                <View style={{flexDirection: 'column'}}>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Client</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.client?.client_name === null
                        ? '-'
                        : item?.client?.client_name}
                    </Text>
                  </View>

                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Start Date</Text>
                    <View style={GLOBALSTYLES.contentView}>
                      <Text style={GLOBALSTYLES.content}>
                      {new Date(item.start_date).toDateString('en-US', {})
                        .split(' ')
                        .slice(1)
                        .join(' ')}


                      </Text>
                    </View>
                  </View>
                </View>
                <View style={{flexDirection: 'column'}}>
                  <View style={GLOBALSTYLES.secondlabelView}>
                    <Text style={GLOBALSTYLES.lebal}>Contract Type</Text>

                    <Text style={GLOBALSTYLES.content}>
                    {item.contract_type === null ? '-' : item.contract_type}
                    </Text>
                  </View>

                  <View style={GLOBALSTYLES.secondlabelView}>
                    <Text style={GLOBALSTYLES.lebal}>Tentative End Date</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {/* {item.end_date === null ? '-' : item.end_date} */}
                      {new Date(item.end_date).toDateString('en-US', {})
                        .split(' ')
                        .slice(1)
                        .join(' ')}
                    </Text>
                  </View>
                </View>
              </View>
              <TouchableOpacity
                style={{    backgroundColor: COLORS.skyBlue,
                  width: wp('80%'),
                  height: hp('7%'),
                  borderRadius: 10,
                  alignSelf: 'center',}}
                onPress={() =>
                  navigation.navigate('Edit Joining', {newData: item})
                }>
                <Text
                  style={GLOBALSTYLES.textStyle}>
                  Edit
                </Text>
              </TouchableOpacity>
            </View>
          )}
        /> :<View style={GLOBALSTYLES.mainContainer}><Text style={{alignSelf:'center', margin:'20%',color:'black'}}>No Data Found</Text></View>

      )}
    </SafeAreaView>
  );
};

export default Joining;