import React, { useState, useEffect } from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  Dimensions,
  ScrollView,
  StyleSheet
} from 'react-native';
import Toast from 'react-native-simple-toast';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import { COLORS, FONTS, GLOBALSTYLES } from '../../constants/theme';
import { dpforHeight,dpforWidth } from '../../constants/SizeScreen';
import { Picker } from '@react-native-picker/picker';
import axios from 'axios';
import DatePicker from 'react-native-datepicker';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { URL } from '../../constants/configure';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Formik } from 'formik';
import * as yup from 'yup';
import moment, { isMoment } from 'moment';
const { height, width } = Dimensions.get('window');

const EditJoining = ({ route,navigation }) => {
  const [newData, setNewData] = useState([]);
  const [res, setRes] = useState([]);
  const [clients, setClients] = useState([]);
  const [data, setData] = useState({});

  useEffect(() => {
    getJoining();
    getResource();
    getClient();
    setData(route.params.newData);

  }, []);

  const getJoining = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/joining', requestOptions);

      // console.log(data.data.data.resources);

      setNewData(data.data.data.joining);
    } catch (error) {
      console.log(error);
    }
  };
  //get res
  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/resource', requestOptions);

      // console.log(data.data.data.resources);

      setRes(data.data.data.resources);
    } catch (error) {
      console.log(error);
    }
  };
  //get client
  const getClient = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/client', requestOptions);

      // console.log(data.data.data.externalResource);

      setClients(data.data.data.clients);
    } catch (error) {
      console.log(error);
    }
  };

  //put
  const postUser = async values => {
    const id = route.params.newData.id;

    const obj = {
      ...values,
      start_date: moment(values.start_date).format("YYYY-MM-DD"), end_date: moment(values.end_date).format("YYYY-MM-DD"),
    }
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };

      const { data } = await axios.put(
        URL.BASE_URL + `/joining/${id}`,
        obj,
        requestOptions,
      );
      setData(route.params.newData)
      console.log('check-------------->', data);
      if (data.message) {
     
        Toast.showWithGravity('Joining Data Updated Successfully', Toast.LONG, Toast.BOTTOM);

      }
      navigation.goBack();
    } catch (err) {
      console.log(err.response);
      Toast.showWithGravity('Joining Data Not Updated Successfully', Toast.LONG, Toast.BOTTOM);

    }
  };
  const handleSubmit = values => {
    postUser(values);
    console.log('values-------', values);
  };
  const resourceOptions = res.filter(t => t.resources !== null);
  const clientsOptions = clients.filter(t => t.client_name !== null);
  const conOptions = newData.filter(t => t.contract_type !== null);
  const phoneRegExp =
    /^(\+91)?(-)?\s*?(91)?\s*?(\d{3})-?\s*?(\d{3})-?\s*?(\d{4})$/;
  const nameReg = /^[^-\s][a-zA-Z\s-]+$/;
  const length = /^[0-9]*$/;
  const loginValidationSchema = yup.object().shape({
    resource_id: yup.string(),
    resources_email: yup.string().email('Email is not valid').required('These field is Required'),
    client_id: yup.string().required('These field is Required'),
    reporting_name: yup.string().matches(nameReg, 'Please enter a valid name').required('These field is Required'),
    reporting_email: yup.string().email('Email is not valid').required('These field is Required'),
    reporting_contact: yup.string().matches(phoneRegExp, 'Please enter a valid number').required('These field is Required'),
    account_name: yup.string().matches(nameReg, 'Please enter a valid name').required('These field is Required'),
    account_email: yup.string().email('Email is not valid').required('These field is Required'),
    contract_type: yup.string().required('These field is Required'),
    start_date: yup.date().required('These field is Required'),
    end_date: yup.date().required('These field is Required'),
    address: yup.string().required('These field is Required'),

  });
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Edit Joining" />
      <Formik
        validationSchema={loginValidationSchema}

        initialValues={{ 
        "resource_id": data.resource_id, 
        "resources_email": data?.resource?.email, 
        "client_id": data.client_id, 
        "reporting_name":data?.client?.reporting_name, 
        "reporting_email": data?.client?.reporting_email, 
        "reporting_contact": data?.client?.reporting_contact, 
        "account_name": data?.client?.account_name, 
        "account_email": data?.client?.account_email, 
        "contract_type": data.contract_type, 
        "start_date": data.start_date, 
        "end_date": data.end_date, 
        "address": data?.client?.address
      }}
        enableReinitialize={true}
        onSubmit={values => {
          handleSubmit(values);
        }}>
        {({ handleChange, handleBlur, values, setFieldValue, handleSubmit, errors, touched }) => (
          <>
            <View style={{ height: height / 1.2 }}>
              <ScrollView>
                <View style={{ height: height / 0.7 }}>
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10,
                      marginTop: 10,
                    }}>
                    <Picker
                      selectedValue={values.resource_id}
                      style={{ margin: 4, bottom: 0 }}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('resource_id', itemValue)
                      )}>
                      <Picker.Item label="Select Resources" value="" color="grey" />
                      {resourceOptions.map((item, index) => (
                        <Picker.Item
                          key={item.id}
                          label={`${item.fname} ${item.lname}`}
                          value={item.id}
                        />
                      ))}
                    </Picker>
                  </View>
                  {errors.resource_id && touched.resource_id && (
                    <Text style={styles.errorStyle}>{errors.resource_id}</Text>
                  )}

                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 12,

                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <MaterialCommunityIcons
                        name="email"
                        size={25}
                        style={{ right: 12, marginStart: 20, color: COLORS.blue }}
                      />
                    </View>
                    <TextInput
                      placeholder="Resource Email*"
                      style={GLOBALSTYLES.textInput}
                      value={values.resources_email}
                      maxLength={45}
                      keyboardType='email-address'
                      onChangeText={handleChange('resources_email')}
                      onBlur={handleBlur('resources_email')}
                    />
                  </View>
                  {errors.resources_email && touched.resources_email && (
                    <Text style={styles.errorStyle}>{errors.resources_email}</Text>
                  )}


                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10,
                      marginTop: 5,
                    }}>
                    <Picker
                      selectedValue={values.client_id}
                      style={{ margin: 4, bottom: 0 }}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('client_id', itemValue)
                      )}>
                      <Picker.Item label="Select Client*" value="" color="grey" />

                      {clientsOptions.map(item => (
                        <Picker.Item
                          key={item.id}
                          label={item.client_name}
                          value={item.id}
                        />
                      ))}
                    </Picker>
                  </View>
                  {errors.client_id && touched.client_id && (
                    <Text style={styles.errorStyle}>{errors.client_id}</Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Reporting Manager Name*"
                      style={GLOBALSTYLES.textInput}
                      maxLength={25}
                      value={values.reporting_name}
                      keyboardType='default'
                      onChangeText={handleChange('reporting_name')}
                      onBlur={handleBlur('reporting_name')}
                    />
                  </View>
                  {errors.reporting_name && touched.reporting_name && (
                    <Text style={styles.errorStyle}>{errors.reporting_name}</Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 12,
                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <MaterialCommunityIcons
                        name="email"
                        size={25}
                        style={{ right: 12, marginStart: 20, color: COLORS.blue }}
                      />
                    </View>

                    <TextInput
                      placeholder="Reporting Manager Email*"
                      style={GLOBALSTYLES.textInput}
                      maxLength={45}
                      value={values.reporting_email}
                      keyboardType='email-address'
                      onChangeText={handleChange('reporting_email')}
                      onBlur={handleBlur('reporting_email')}
                    />
                  </View>
                  {errors.reporting_email && touched.reporting_email && (
                    <Text style={styles.errorStyle}>{errors.reporting_email}</Text>
                  )}

                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 12,

                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <FontAwesome
                        name="phone"
                        size={30}
                        style={{ right: 12, marginStart: 20, color: COLORS.blue }}
                      />
                    </View>
                    <TextInput
                      placeholder="Reporting manager contact*"
                      style={GLOBALSTYLES.textInput}
                      value={values.reporting_contact}
                      onChangeText={handleChange('reporting_contact')}
                      onBlur={handleBlur('reporting_contact')}
                      maxLength={10}
                      keyboardType='phone-pad'

                    />
                  </View>
                  {errors.reporting_contact && touched.reporting_contact && (
                    <Text style={styles.errorStyle}>{errors.reporting_contact}</Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Accountant*"
                      style={GLOBALSTYLES.textInput}
                      value={values.account_name}
                      maxLength={25}
                      keyboardType='default'
                      onChangeText={handleChange('account_name')}
                      onBlur={handleBlur('account_name')}
                    />
                  </View>
                  {errors.account_name && touched.account_name && (
                    <Text style={styles.errorStyle}>{errors.account_name}</Text>
                  )}

                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 12,

                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <MaterialCommunityIcons
                        name="email"
                        size={25}
                        style={{ right: 12, marginStart: 20, color: COLORS.blue }}
                      />
                    </View>
                    <TextInput
                      placeholder="Accountant Email Id*"
                      style={GLOBALSTYLES.textInput}
                      maxLength={45}
                      value={values.account_email}
                      keyboardType='email-address'
                      onChangeText={handleChange('account_email')}
                      onBlur={handleBlur('account_email')}
                    />
                  </View>
                  {errors.account_email && touched.account_email && (
                    <Text style={styles.errorStyle}>{errors.account_email}</Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      selectedValue={values.contract_type}
                      style={{ margin: 4, bottom: 0 }}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('contract_type', itemValue)
                      )}>
                      <Picker.Item label="Contract Type*" value="" color="grey" />
                      <Picker.Item
                        label="Monday To Friday"
                        value="Monday to Friday"
                      />
                      <Picker.Item label="All Saturday" value="All Saturday" />
                      <Picker.Item
                        label="Alternate Saturday"
                        value="Alternate Saturday"
                      />
                    </Picker>
                  </View>
                  {errors.contract_type && touched.contract_type && (
                    <Text style={styles.errorStyle}>{errors.contract_type}</Text>
                  )}
                  <TouchableOpacity
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <DatePicker
                      date={values.start_date}
                      style={{ width: '100%', top: 7 }}
                      mode="date"
                      placeholder="Tentative Start Date*"
                      format="DD MMMM YYYY"
                      confirmBtnText="Confirm"
                      cancelBtnText="Cancel"
                      showIcon={false}
                      customStyles={{
                        dateInput: {
                          borderWidth: 0,

                          position: 'absolute',
                          left: 20,
                          fontSize:14,
                        },
                      }}
                      onDateChange={(itemValue) => (
                        setFieldValue('start_date', itemValue)
                      )} />

                    <FontAwesome
                      name="calendar-o"
                      size={20}
                      style={{ alignSelf: 'center', right: 30 }}
                    />
                  </TouchableOpacity>
                  {errors.start_date && touched.start_date && (
                    <Text style={styles.errorStyle}>{errors.start_date}</Text>
                  )}
                  <TouchableOpacity
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <DatePicker
                      date={values.end_date}
                      style={{ width: '100%', top: 7 }}
                      mode="date"
                      placeholder="Tentative End Date*"
                      format="DD MMMM YYYY"
                      minDate={values.start_date}
                      confirmBtnText="Confirm"
                      cancelBtnText="Cancel"
                      showIcon={false}
                      customStyles={{
                        dateInput: {
                          borderWidth: 0,

                          position: 'absolute',
                          left: 20,
                          fontSize:14,
                        },
                      }}
                      onDateChange={(itemValue) => (
                        setFieldValue('end_date', itemValue)
                      )} />

                    <FontAwesome
                      name="calendar-o"
                      size={20}
                      style={{ alignSelf: 'center', right: 30 }}
                    />
                  </TouchableOpacity>
                  {errors.end_date && touched.end_date && (
                    <Text style={styles.errorStyle}>{errors.end_date}</Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(15),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10,

                    }}>
                    <TextInput
                      placeholder="Address*"
                      style={{
                        marginHorizontal: 20,
                        fontSize:14,
                        marginTop: 1,
                      }}
                      maxLength={200}
                      keyboardType='default'
                      multiline={true}
                      value={values.address}
                      onChangeText={handleChange('address')}
                      onBlur={handleBlur('address')}
                    />
                  </View>
                  {errors.address && touched.address && (
                    <Text style={styles.errorStyle}>{errors.address}</Text>
                  )}
                </View>
              </ScrollView>
            </View>

            <View style={{ flex: 1 }}>
              <TouchableOpacity
                style={{
                  width: dpforWidth(90),
                  height: dpforHeight(7),
                  bottom: 5,
                  borderRadius:10,
                  alignSelf:'center',
                  backgroundColor: COLORS.skyBlue,
                  position: 'absolute',
                }}
                onPress={() => handleSubmit()}>
                <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </Formik>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  errorStyle: {
    fontSize:14,
    color: COLORS.red,
    textAlign: 'center',
  },
})
export default EditJoining;
