import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import DropDownPicker from 'react-native-dropdown-picker';
import { dpforHeight, dpforWidth } from '../../constants/SizeScreen'
import { URL } from '../../constants/configure';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import { GLOBALSTYLES, COLORS, FONTS } from '../../constants/theme';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import { Picker } from '@react-native-picker/picker';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DatePicker from 'react-native-datepicker';
import { Formik } from 'formik';
import * as yup from 'yup';
import Toast from 'react-native-simple-toast';
const { height, width } = Dimensions.get('window');

const AddInterview = ({ navigation }) => {
  const [newData, setNewData] = useState([]);
  const [interviews, setInterviews] = useState([]);
  const [technologys, setTechnologys] = useState([]);
  const [clients, setClients] = useState([]);
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([])

  const [use, setUse] = useState([]);
  useEffect(() => {
    getResource();
    getClient();
    getTechnology();
    getUser();
    getInterview();
  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/resource', requestOptions);

      // console.log(data.data.data.externalResource);

      setNewData(data.data.data.resources);
    } catch (error) {
      console.log(error);
    }
  };
  //get
  const getUser = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/user', requestOptions);

      // console.log(data.data.data.externalResource);

      setUse(data.data.data.users);
    } catch (error) {
      // console.log(error);
    }
  };
  //get
  const getInterview = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/interview', requestOptions);

      // console.log(data.data.data.externalResource);

      setInterviews(data.data.data.interview);
    } catch (error) {
      // console.log(error);
    }
  };
  const getClient = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/client', requestOptions);

      // console.log(data.data.data.externalResource);

      setClients(data.data.data.clients);
    } catch (error) {
      // console.log(error);
    }
  };
  const getTechnology = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      // console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/technology',
        requestOptions,
      );

      // console.log(data.data.data.externalResource);

      setTechnologys(data.data.data.technologies);
    } catch (error) {
      // console.log(error);
    }
  };

  //post
  const postUser = async values => {

    // console.log('store------>', values);
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };

      const { data } = await axios.post(
        URL.BASE_URL + '/interview', values,requestOptions,

      );
      // console.log('check-------------->', data);
      if (data.message) {
  
        Toast.showWithGravity('Interview Data Added Successfully', Toast.LONG, Toast.BOTTOM);

      }
      navigation.goBack();
    } catch (err) {
      Toast.showWithGravity('Interview Data Not Added Successfully', Toast.LONG, Toast.BOTTOM);

    }
  };
  const handleSubmit = values => {
    postUser(values);
    // console.log('values-------', values);
  };
  const clientsOptions = clients.filter(t => t.client_name !== null);
  const userCheck = use.filter(t => t.name !== null);
  const resourceCheck = newData.filter(t => t.resources !== null);

  const phoneRegExp =
    /^(\+91)?(-)?\s*?(91)?\s*?(\d{3})-?\s*?(\d{3})-?\s*?(\d{4})$/;
  const nameReg = /^[^-\s][a-zA-Z\s-]+$/;
  const length = /^[0-9]*$/;
  const loginValidationSchema = yup.object().shape({
    client: yup.string().required('These field is Required'),
    resource: yup.string().required('These field is Required'),
    contact_person: yup.string().required('These field is Required').matches(nameReg, 'Please enter a valid name'),
    contact: yup.string().matches(phoneRegExp, 'Please enter a valid number').required('These field is Required'),
    datetime: yup.string().required('These field is Required'),
    mode: yup.string().required('These field is Required'),
    location: yup.string().required('These field is Required'),
    address: yup.string().required('These field is Required'),
    interview_type: yup.string().required('These field is Required'),
    Schedule_id: yup.string().required('These field is Required'),
    isExternal: yup.string(),
    nick_name: yup.string().matches(nameReg, 'Please enter a valid name'),
  });

 
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Scheduled Interview" />
      <Formik
        validationSchema={loginValidationSchema}
        initialValues={{ "client": "", "resource": "", "contact_person": "", "contact": "", "datetime": "", "mode": "", "location": "", "address": "", "interview_type": "", "Schedule_id": "", "isExternal": "", "nick_name": "" }}
        enableReinitialize={true}

        onSubmit={values => {
          handleSubmit(values);
        }}>
        {({ handleChange, handleBlur, values, setFieldValue, handleSubmit, errors, touched }) => (
          <>
            <View style={{ height: height / 1.2 }}>
              <ScrollView>
                <View style={{ height: height / 0.6 }}>
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                      marginTop: 10,
                    }}>
                    {/* <Picker
                      style={{
                        margin: 4
                      }}
                      selectedValue={values.client}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('client', itemValue)
                      )}>
                      <Picker.Item label="Client List*" value="" color="grey" style={{}} />

                      {clientsOptions.map((item, index) => (
                        <Picker.Item
                          key={item.id}
                          label={item.client_name}
                          value={item.id}
                        />
                      ))}
                    </Picker> */}
              <DropDownPicker
               items={clientsOptions.map((item, index) => (
                <DropDownPicker.Item
                  key={item.id}
                  label={item.client_name}
                  value={item.id}
                />
              ))}
               defaultValue={values.client}
               containerStyle={{height: 40}}
               style={{backgroundColor: '#fafafa'}}
               itemStyle={{
                 justifyContent: 'flex-start',
               }}
               dropDownStyle={{backgroundColor: '#fafafa'}}
               onChangeItem={(itemValue) => (
                setFieldValue('client', itemValue)
              )}
             />
                  </View>
                  {errors.client && touched.client && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.client}</Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      style={{ margin: 4 }}
                      selectedValue={values.isExternal}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('isExternal', itemValue)
                      )}>
                      <Picker.Item
                        label="Select Internal/External"
                        value=""
                        color="grey"
                      />

                      <Picker.Item label="yes" value="true" />
                      <Picker.Item label="no" value="false" />
                    </Picker>
                  </View>
                  {errors.isExternal && touched.isExternal && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.isExternal}</Text>
                  )}

                  <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      style={{ margin: 4 }}
                      selectedValue={values.resource}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('resource', itemValue)
                      )}>
                      <Picker.Item label="Resource List*" value="" color="grey" />

                      {resourceCheck.map((item, index) => (
                        <Picker.Item
                          key={item.id}
                          label={`${item.fname} ${item.lname}`}
                          value={item.id}
                        />
                      ))}
                    </Picker>
                  </View>
                  {errors.resource && touched.resource && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.resource}</Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      style={{ margin: 4 }}
                      selectedValue={values.Schedule_id}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('Schedule_id', itemValue)
                      )}>
                      <Picker.Item label="Sheduled By*" value="" color="grey" />

                      {userCheck.map((item, index) => (
                        <Picker.Item
                          key={item.id}
                          label={item.name}
                          value={item.id}
                        />
                      ))}
                    </Picker>
                  </View>
                  {errors.Schedule_id && touched.Schedule_id && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.Schedule_id}</Text>
                  )}
                <TouchableOpacity
                style={{
                  width: dpforWidth(90),
                  height: dpforHeight(7),
                  margin: 5,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  backgroundColor: COLORS.pureWhite,
                  marginStart: 20,
                  borderRadius: 10,
                }}>
                <DatePicker
                  style={{ width: '100%', top: 7 }}
                  date={values.datetime}
                  mode='date'
                  placeholder="Select Date*"
                  format="DD MMMM YYYY"
                  confirmBtnText="Confirm"
                  cancelBtnText="Cancel"
                  showIcon={false}
                  customStyles={{
                    dateInput: {
                      borderWidth: 0,

                      position: 'absolute',
                      left: 20,
                      fontSize:14,
                    },
                  }}
                  onDateChange={(itemValue) => (
                    setFieldValue('datetime', itemValue)
                  )}
                />
                <FontAwesome
                  name="calendar-o"
                  size={20}
                  style={{ alignSelf: 'center', right: 30 }}
                />
              </TouchableOpacity>
              {errors.datetime && touched.datetime && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.datetime}</Text>
              )}

                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Nick Name"
                      style={GLOBALSTYLES.textInput}
                      maxLength={25}
                      autoCapitalize='words'
                      allowFontScaling={false}
                      keyboardType='default'
                      onChangeText={handleChange('nick_name')}
                      onBlur={handleBlur('nick_name')}
                    />
                  </View>
                  {errors.nick_name && touched.nick_name && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.nick_name}</Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <TextInput
                      placeholder="Point Of Contact*"
                      style={GLOBALSTYLES.textInput}
                      maxLength={25}
                      onChangeText={handleChange('contact_person')}
                      onBlur={handleBlur('contact_person')}
                    />
                  </View>
                  {errors.contact_person && touched.contact_person && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.contact_person}</Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(7),
                      margin: 5,
                      flexDirection: 'row',
                      backgroundColor: COLORS.pureWhite,
                      marginStart: 20,
                      borderRadius: 10,
                    }}>
                    <View
                      style={{
                        justifyContent: 'center',
                        borderRadius: 10,
                        padding: 12,

                        backgroundColor: COLORS.whiteBlue,
                      }}>
                      <FontAwesome
                        name="phone"
                        size={25}
                        style={{ right: 12, marginStart: 20 }}
                      />
                    </View>
                    <TextInput
                      placeholder="Phone Number*"
                      style={GLOBALSTYLES.textInput}
                      keyboardType="number-pad"
                      maxLength={10}
                      onChangeText={handleChange('contact')}
                      onBlur={handleBlur('contact')}
                    />
                  </View>
                  {errors.contact && touched.contact && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.contact}</Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      style={{ margin: 4 }}
                      selectedValue={values.mode}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('mode', itemValue)
                      )}>
                      <Picker.Item
                        label="Select Interview Mode*"
                        value=""
                        color="grey"
                      />

                      <Picker.Item label="Teliphonic" value="teliphonic" />
                      <Picker.Item label="F2F" value="f2f" />
                      <Picker.Item label="Skype" value="skype" />
                      <Picker.Item label="Google Hangouts" value="google hangouts" />
                      <Picker.Item label="Zoom" value="zoom" />
                    </Picker>
                  </View>
                  {errors.mode && touched.mode && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.mode}</Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      style={{ margin: 4 }}
                      selectedValue={values.location}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('location', itemValue)
                      )}>
                      <Picker.Item
                        label="Select Interview Loction*"
                        value=""
                        color="grey"
                      />

                      <Picker.Item label="Client office" value="Client office" />
                      <Picker.Item label="Nimap Office" value="Nimap Office" />
                      <Picker.Item label="Home" value="Home" />
                    </Picker>
                  </View>
                  {errors.location && touched.location && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.location}</Text>
                  )}
                  <View style={GLOBALSTYLES.textInputView}>
                    <Picker
                      style={{ margin: 4 }}
                      selectedValue={values.interview_type}
                      mode="dropdown"
                      onValueChange={(itemValue) => (
                        setFieldValue('interview_type', itemValue)
                      )}>
                      <Picker.Item
                        label="Select Interview Type*"
                        value=""
                        color="grey"
                      />

                      <Picker.Item label="L1" value="l1" />
                      <Picker.Item label="L2" value="l2" />
                      <Picker.Item label="Final" value="final" />
                    </Picker>
                  </View>
                  {errors.interview_type && touched.interview_type && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.interview_type}</Text>
                  )}
                  <View
                    style={{
                      width: dpforWidth(90),
                      height: dpforHeight(15),
                      margin: 5,
                      marginStart: 20,
                      backgroundColor: COLORS.pureWhite,
                      borderRadius: 10,
                    }}>
                    <TextInput
                      placeholder="Residetial Address*"
                      style={{
                        marginHorizontal: 20,
                        fontSize:14,
                        marginTop: 1,
                      }}
                      keyboardType="default"
                      maxLength={200}
                      multiline={true}
                      onChangeText={handleChange('address')}
                      onBlur={handleBlur('address')}
                    />
                  </View>
                  {errors.address && touched.address && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.address}</Text>
                  )}
                </View>
              </ScrollView>
            </View>

            <View style={{ flex: 1 }}>
              <TouchableOpacity
                style={{
                  width: dpforWidth(90),
                  height: dpforHeight(7),
                  alignSelf: 'center',
                  borderRadius: 10,
                  bottom: 5,
                  backgroundColor: COLORS.skyBlue,
                  position: 'absolute',
                }}
                onPress={() => handleSubmit()}>
                <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </Formik>
    </SafeAreaView>
  );
};

export default AddInterview;
