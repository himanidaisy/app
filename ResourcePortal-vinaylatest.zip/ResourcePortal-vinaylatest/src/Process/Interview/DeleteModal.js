import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  ToastAndroid,
  Dimensions,
  StyleSheet,
  Modal,
} from 'react-native';
import {GLOBALSTYLES, COLORS, FONTS} from '../../constants/theme';
import SearchBox from '../../components/SearchBox';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {URL} from '../../constants/configure';
const {height, width} = Dimensions.get('window');
import ErrorBox from 'react-native-vector-icons/MaterialCommunityIcons';
const Interview = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [filterData, setFilterData] = useState([]);
  const [isModalVisible, setisModalVisible] = useState(false);
  const [choosedata, setchoosedata] = useState();
  const changeModalVisible = bool => {
    setisModalVisible(bool);
  };

  useEffect(() => {
    getResource();
    getAccountFilterData();
  }, [search, loding, newData]);

  //get

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      //console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/interview', requestOptions);

      // console.log(data.data.data.technologies);
      setNewData(data.data.data.interview);
      setLoding(false);
    } catch (error) {
      // console.log(error);
      setLoding(true);
    }
  };
  const setSearchValue = value => {
    setSearch(value);
  };
  const getAccountFilterData = () => {
    if (!loding) {
      const filterValue = newData?.filter(data => {
        if (search.length === 0) {
          return data;
        } else if (
          data.clients?.client_name
            .toLowerCase()
            .includes(!!search && search.toLowerCase()) ||
          data.resources?.fname
            .toLowerCase()
            .includes(!!search && search.toLowerCase()) ||
          data.resources?.lname
            .toLowerCase()
            .includes(!!search && search.toLowerCase()) ||
          // data.mode.includes(search.toLowerCase()) ||
          // data.datetime.includes(search) ||
          data.scheduled_by?.name
            .toLowerCase()
            .includes(search.toLowerCase()) ||
          data.interview_status.toLowerCase().includes(search.toLowerCase())
        ) {
          // console.log(data);
          return data;
        }
      });
      setFilterData(filterValue);
    }
  };
  //Delete User
  const deleteUser = async values => {
    // console.log('check__', values);
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'DELETE',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      const {data} = await axios.delete(
        `http://newresourcing.nimapinfotech.com/api/interview/${values}`,
        //  values,
        requestOptions,
      );
      // console.log(data);
      setSearch('');
      const remaningData = newData.filter(t => t.id !== values);
      setFilterData([...remaningData]);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Interview Deleted successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
      }
    } catch (err) {
      // console.log(err.response);
      ToastAndroid.showWithGravity(
        'Interview not deleted',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };

  const handleDelete = item => {
    // console.log('Delte hit', deleteUser(item.id));
    // deleteUser(item.id);
    getResource();
    changeModalVisible(false);
    // console.log('check id', item.id);
  };

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <SearchBox search={search} setSearchValue={setSearchValue} />
      {loding ? (
        <ActivityIndicator
          animating={true}
          size="large"
          style={{
            opacity: 1,
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        />
      ) : (
        <FlatList
          data={filterData}
          renderItem={({item}) => (
            <View style={GLOBALSTYLES.appContainer}>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Resources</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.resources === null
                      ? '-'
                      : `${item.resources.fname} ${item.resources.lname}`}
                  </Text>
                </View>
              </View>
              <View style={{flexDirection: 'row'}}>
                <View style={{flexDirection: 'column', flex: 1}}>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Client</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.clients === null ? '-' : item?.clients?.client_name}
                    </Text>
                  </View>

                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Date & Time</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.datetime === null ? '-' : item.datetime}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Scheduled By</Text>
                    <View style={GLOBALSTYLES.contentView}>
                      <Text style={GLOBALSTYLES.content}>
                        {item.scheduled_by === null
                          ? '-'
                          : item?.scheduled_by?.name}
                      </Text>
                    </View>
                  </View>
                </View>
                <View style={{flexDirection: 'column', flex: 1}}>
                  <Text style={GLOBALSTYLES.lebal}>Mode</Text>

                  <Text style={GLOBALSTYLES.content}>
                    {item.mode === null ? '-' : item.mode}
                  </Text>
                  <View
                    style={{flexDirection: 'column', margin: 10, right: 10}}>
                    <Text style={GLOBALSTYLES.lebal}>Status</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.interview_status == 'cancel'
                        ? 'cancel'
                        : item.interview_status == 'select'
                        ? 'select'
                        : item.interview_status == 'reject'
                        ? 'reject'
                        : item.interview_status == 'onhold'
                        ? 'onhold'
                        : 'noData'}
                    </Text>
                  </View>
                </View>
              </View>

              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Receive Que?</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.receive_question == '1'
                      ? 'yes'
                      : item.receive_question == '0'
                      ? 'no'
                      : 'noData'}
                  </Text>
                </View>
              </View>

              <View style={{flexDirection: 'row', margin: 10}}>
                <TouchableOpacity
                  style={GLOBALSTYLES.editBtn}
                  onPress={() =>
                    navigation.navigate('Edit InterviewScreen', {newData: item})
                  }>
                  <Text style={GLOBALSTYLES.editText}>Edit</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={GLOBALSTYLES.deleteBtn}
                  onPress={() => changeModalVisible(true)}>
                  <Text style={GLOBALSTYLES.deleteText}>Delete</Text>
                </TouchableOpacity>
                <Modal
                  animationType="fade"
                  transparent={true}
                  visible={isModalVisible}
                  onRequestClose={() => changeModalVisible(false)}>
                  <View styte={styles.viewContainerView}>
                    <View style={styles.modalView}>
                      <ErrorBox
                        style={styles.iconStyle}
                        name={'alert-box-outline'}
                        size={80}
                        color="red"
                      />
                      <Text style={styles.titleText}> Are you sure?</Text>
                      <View>
                        <Text style={styles.subTitleText}>
                          You won't be able to revert this!
                        </Text>
                        <View
                          style={{
                            flexDirection: 'row',
                            justifyContent: 'space-evenly',
                          }}>
                          <TouchableOpacity
                            style={styles.deleteButton}
                            onPress={() => handleDelete(item)}>
                            <Text style={styles.deleteButtonText}>
                              Yes,delete it!
                            </Text>
                          </TouchableOpacity>
                          <TouchableOpacity
                            style={styles.cancelButton}
                            onPress={() => changeModalVisible(false)}>
                            <Text style={styles.cancelButtonText}>Cancel</Text>
                          </TouchableOpacity>
                        </View>
                      </View>
                    </View>
                  </View>
                </Modal>
              </View>
            </View>
          )}
        />
      )}
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  viewContainerView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  deleteButton: {
    backgroundColor: 'skyblue',
    borderRadius: 10,
    padding: '5%',
    margin: '6%',
    position: 'relative',
    top: 10,
    width: width / 3,
    left: 15,
  },
  deleteButtonText: {
    fontSize: 17,
    alignSelf: 'center',
    fontWeight: 'bold',
    padding: 1,
    color: 'white',
  },

  cancelButton: {
    backgroundColor: 'red',
    borderRadius: 10,
    padding: '5%',
    margin: '6%',
    position: 'relative',
    top: 10,
    width: width / 3,
  },
  cancelButtonText: {
    alignSelf: 'center',
    fontWeight: 'bold',
    color: 'white',
    fontSize: 17,
    color: 'white',
  },

  textInput: {
    fontSize: 16,
  },
  iconStyledrop: {
    marginLeft: '5%',
    marginTop: 15,
  },

  titleText: {
    fontSize: 17,
    fontWeight: 'bold',
    alignSelf: 'center',
    margin: 10,
    marginTop: 20,
  },
  subTitleText: {
    fontSize: 17,
    alignSelf: 'center',
  },

  iconStyle: {
    alignSelf: 'center',
    marginTop: 15,
  },

  modalView: {
    width: width - 50,
    backgroundColor: 'white',
    borderRadius: 10,
    alignSelf: 'center',
    marginTop: width / 1.3,
    height: height / 3.3,
    elevation: 1,
  },
});
export default Interview;
