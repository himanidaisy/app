import { StyleSheet, Text, View, TextInput, SafeAreaView, Dimensions, TouchableOpacity, ToastAndroid, Image } from 'react-native'
import React, { useState, useEffect } from 'react'
import { GLOBALSTYLES, COLORS, FONTS, IMAGES } from '../../constants/theme'
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { URL } from '../../constants/configure';

const { height, width } = Dimensions.get('window');

const NotesView = ({ navigation, route }) => {
    const [data, setData] = useState({});
    const [notes, setNotes] = useState('');
    useEffect(() => {

        setData(route.params.newData);
        setNotes(route.params.newData.message);

    }, []);
    const putUser = async () => {
        const store = {
            message: notes
        };
        console.log('store------>', store);
        const id = route.params.newData.id;

        try {
            const token = await AsyncStorage.getItem('token');

            const requestOptions = {
                method: 'PUT',
                Accept: 'application/json',
                'Content-Type': 'application/json',
                headers: { Authorization: 'Bearer ' + token },
            };

            const { data } = await axios.put(
                URL.BASE_URL + `/interview/note/${id}`,
                store,
                requestOptions,
            );
            setData(route.params.newData);

            console.log('check-------------->', data);
            if (data.message) {
                ToastAndroid.showWithGravity(
                    ' Notes Added Successfully',
                    ToastAndroid.LONG,
                    ToastAndroid.TOP,
                );
            }
            navigation.goBack();
        } catch (err) {
            console.log(err.response);
            ToastAndroid.showWithGravity(
                'Notes Not Added Successfully',
                ToastAndroid.SHORT,
                ToastAndroid.BOTTOM,
            );
        }
    };

    return (
        <SafeAreaView style={{ flex: 1 }}>
            <View style={{
                marginVertical: '1%',
                padding: 10,
                marginHorizontal: 20,
                borderRadius: 10,
                flex: 1
            }}>
                <View style={{ flex: 1, position: 'absolute', top: 70 }}>
                    <Text style={{ marginStart: 15, fontWeight: 'bold' }}>Notes/Message</Text>
                   
                    <View style={{
                        width: width - 60,
                        height: height / 4,
                        margin: 5,
                        marginStart: 30,
                        backgroundColor: COLORS.pureWhite,
                        borderRadius: 10,
                        top: 30, right: 20,
                    }}>

                        <TextInput
                            placeholder="Add Notes"
                            style={{
                                marginHorizontal: 20,
                                ...FONTS.appFontSemiBold,
                                marginTop: 1,
                            }}
                            value={notes}
                            maxLength={200}
                            onChangeText={data => setNotes(data)}
                            keyboardType='default'
                        />
                    </View>
                    <View style={{ flexDirection: 'row', margin: 10, top: 50 }}>
                        <TouchableOpacity
                            style={{
                                backgroundColor: COLORS.skyBlue,
                                padding: 15,
                                flex: 1,
                                borderRadius: 10,
                                margin: 15,
                                right: 5,
                            }}
                            onPress={() => putUser()}>
                            <Text style={GLOBALSTYLES.editText}>Submit</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={{
                                backgroundColor: COLORS.darkPink,
                                padding: 15,
                                flex: 1,
                                borderRadius: 10,
                                margin: 15,

                            }}
                            onPress={() => navigation.goBack()}>
                            <Text style={GLOBALSTYLES.deleteText}>Cancel</Text>
                        </TouchableOpacity>
                    </View>
                </View>

            </View>


        </SafeAreaView>
    )
}

export default NotesView

const styles = StyleSheet.create({})