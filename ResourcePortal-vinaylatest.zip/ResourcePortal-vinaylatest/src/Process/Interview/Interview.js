import React, { useEffect, useState } from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  ToastAndroid,
  Dimensions,
  Vibration,
  Modal,
} from 'react-native';
import MaterialIcons from 'react-native-vector-icons/Foundation';
import Toast from 'react-native-simple-toast';
import { GLOBALSTYLES, COLORS, FONTS } from '../../constants/theme';
import SearchBox from '../../components/SearchBox';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { URL } from '../../constants/configure';
import { Picker } from '@react-native-picker/picker';

const Interview = ({ navigation }) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [filterData, setFilterData] = useState([]);

  useEffect(() => {
    getResource();
    getAccountFilterData();
  }, [search, loding, newData]);

  //get

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/interview', requestOptions);

      // console.log(data.data.data.interview);
      setNewData(data.data.data.interview);
      setLoding(false);
    } catch (error) {
      console.log(error);
      setLoding(true);
    }
  };

  const setSearchValue = value => {
    setSearch(value);
  };
  const getAccountFilterData = () => {
    if (!loding) {
      const filterValue = newData?.filter(data => {
        if (search.length === 0) {
          return data;
        } else if (
          data.clients?.client_name
            .toLowerCase()
            .includes(search.toLowerCase()) ||
          data.resources?.fname.toLowerCase().includes(search.toLowerCase()) ||
          data.interview_status.toLowerCase().includes(search.toLowerCase()) ||
          data.resources?.lname
            .toLowerCase()
            .includes(search.toLowerCase())
        ) {
          // console.log(data);
          return data;
        }
      });
      setFilterData(filterValue);
    }
  };

  //Delete User
  const deleteUser = async values => {
    console.log('check__', values);
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'DELETE',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };
      const { data } = await axios.delete(
        URL.BASE_URL + `/interview/${values}`,
        //  values,
        requestOptions,
      );
      // console.log(data);
      setSearch('');
      const remaningData = newData.filter(t => t.id !== values);
      setFilterData([...remaningData]);
      if (data.message) {
   
        Toast.showWithGravity('External Interview Data Deleted Successfully', Toast.LONG, Toast.BOTTOM);

      }
    } catch (err) {
   
      Toast.showWithGravity('External Interview Data Not Deleted Successfully', Toast.LONG, Toast.BOTTOM);

    }
  };

  const handleDelete = item => {
    console.log('Delte hit', deleteUser(item.id));
    // deleteUser(item.id);
    getResource();
    console.log('check id', item.id);
  };

  //update api

  const handleChange = async (event, item) => {
    // console.log('my-------------->', item);
    // console.log('my-------------->', event);
    const data = {
      ...item,
      interview_status: event,
    };
    const alldata = {
      client: data.client,
      resource: data.resource,
      contact_person: data.contact_person,
      contact: data.contact,
      datetime: data.datetime,
      mode: data.mode,
      location: data.location,
      address: data.address,
      interview_type: data.interview_type,
      Schedule_id: data.Schedule_id,
      interview_status: event,
    };
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };

      const { data } = await axios.put(
        URL.BASE_URL + `/interview/${item.id}`,
        alldata,
        requestOptions,
      );
      // console.log('check-------------->', data);
      if (data.message) {
        // ToastAndroid.showWithGravity(
        //   'Interview Status Updated Successfully',
        //   ToastAndroid.LONG,
        //   ToastAndroid.TOP,
        // );\
        Toast.showWithGravity('Interview Status Updated Successfully', Toast.LONG, Toast.BOTTOM);

      }
    } catch (err) {
      console.log(err.response);
      Toast.showWithGravity('Interview Status Not Updated Successfully', Toast.LONG, Toast.BOTTOM);

    }
    // console.log("my interstatus------------>", data)
  };
  ///sec
  const handleReceive = async (event, item) => {
    // console.log('my-------------->', item)
    // console.log('my-------------->', event)
    const data = {
      ...item,
      receive_question: event,
    };
    const alldata = {
      client: data.client,
      resource: data.resource,
      contact_person: data.contact_person,
      contact: data.contact,
      datetime: data.datetime,
      mode: data.mode,
      location: data.location,
      address: data.address,
      interview_type: data.interview_type,
      Schedule_id: data.Schedule_id,
      interview_status: data.interview_status,
      receive_question: event,
    };
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: { Authorization: 'Bearer ' + token },
      };

      const { data } = await axios.put(
        URL.BASE_URL + `/interview/${item.id}`,
        alldata,
        requestOptions,
      );
      // console.log('check-------------->', data);
      if (data.message) {
        Toast.showWithGravity('Interview Status Updated Successfully', Toast.LONG, Toast.BOTTOM);

      }
    } catch (err) {
      console.log(err.response);
      Toast.showWithGravity('Interview Status Not Updated Successfully', Toast.LONG, Toast.BOTTOM);

    }
    // console.log("my interstatus------------>", data)
  };
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <SearchBox search={search} setSearchValue={setSearchValue} />
      {loding ? (
        <ActivityIndicator
          animating={true}
          size="large"
          style={{
            opacity: 1,
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        />
      ) : (
        filterData.length !==0? 

        <FlatList
          data={filterData}
          renderItem={({ item }) => (
            <View style={GLOBALSTYLES.appContainer}>
              <TouchableOpacity
                style={{ marginBottom: 30, flex: 1 }}
                onPress={() =>
                  navigation.navigate('Notes Screen', { newData: item })
                }>
                <MaterialIcons
                  style={{ position: 'absolute', right: 10, top: 0 }}
                  name={'clipboard-pencil'}
                  size={26}
                  color={COLORS.green}
                />
              </TouchableOpacity>
              <View style={{ flexDirection: 'row' }}>
                <View style={{ flexDirection: 'column', flex: 1 }}>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}> Resources</Text>
                    <Text style={{
                      fontSize:14,
                      color: 'black',
                      padding: 3, left: 4
                    }}>
                      {item.resources === null
                        ? '-'
                        : `${item.resources.fname} ${item.resources.lname}`}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Client</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.clients === null ? '-' : item?.clients.client_name}
                    </Text>
                  </View>

                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Date & Time</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.datetime === null ? '-' : item.datetime}
                      {/* {new Date(item.datetime).toLocaleDateString("en-US",{
                    

                  })} */}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Scheduled By</Text>
                    <View style={GLOBALSTYLES.contentView}>
                      <Text style={GLOBALSTYLES.content}>
                        {item.scheduled_by === null
                          ? '-'
                          : item?.scheduled_by?.name}
                      </Text>
                    </View>
                  </View>
                  <Text style={{ margin: 12 }}>Receive Que?</Text>

                  <View
                    style={{
                      width: '65%',
                      bottom: 10,
                    }}>
                    <Picker
                      selectedValue={
                        item.receive_question && item.receive_question == 0
                          ? 0
                          : item.receive_question && item.receive_question == 1
                            ? 1
                            : '-'
                      }
                      mode="dropdown"
                      onValueChange={e =>
                        handleReceive(e, item, item.receive_question)
                      }>
                      <Picker.Item label="No" value={0} />
                      <Picker.Item label="Yes" value={1} />
                    </Picker>
                  </View>
                </View>
                <View style={{ flexDirection: 'column', flex: 1 }}>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Mode</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.mode === null ? '-' : item.mode}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>isExternal</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.isExternal === null ? '-' : item?.isExternal=== true? "yes": item?.isExternal=== false? "no":"-"}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Nick Name</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.nick_name === null ? '-' : item.nick_name}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={{ top: 5 }}>Status</Text>

                    <View
                      style={{
                        top: 20,
                      }}>
                      <Picker
                        style={{
                          padding: -80,
                          color: 'white',
                          backgroundColor:
                            item.interview_status == 'cancel'
                              ? '#ff33cc'
                              : item.interview_status == 'select'
                                ? '#32cd32'
                                : item.interview_status == 'reject'
                                  ? '#ff0000'
                                  : item.interview_status == 'onhold'
                                    ? '#ffa500'
                                    : 'noData',

                        }}
                        selectedValue={
                          item.interview_status == 'cancel'
                            ? 'cancel'
                            : item.interview_status == 'select'
                              ? 'select'
                              : item.interview_status == 'reject'
                                ? 'reject'
                                : item.interview_status == 'onhold'
                                  ? 'onhold'
                                  : '-'
                        }
                        mode="dropdown"
                        onValueChange={e =>
                          handleChange(e, item, item.interview_status)
                        }>
                        <Picker.Item
                          label="Select"
                          value="select"
                          style={{ fontSize: 10, backgroundColor: 'black' }}
                        />
                        <Picker.Item
                          label="Reject"
                          value="reject"
                          style={{ fontSize: 10 }}
                        />
                        <Picker.Item
                          label="OnHold"
                          value="onhold"
                          style={{ fontSize: 10 }}
                        />
                        <Picker.Item
                          label="Cancel"
                          value="cancel"
                          style={{ fontSize: 10 }}
                        />
                      </Picker>
                    </View>
                  </View>
                </View>
              </View>
              <View style={{ flexDirection: 'row', margin: 10 }}>
                <TouchableOpacity
                  style={GLOBALSTYLES.editBtn}
                  onPress={() =>
                    navigation.navigate('Edit InterviewScreen', {
                      newData: item,
                    })
                  }>
                  <Text style={GLOBALSTYLES.editText}>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={GLOBALSTYLES.deleteBtn}
                  onPress={() => handleDelete(item)}>
                  <Text style={GLOBALSTYLES.deleteText}>Delete</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        /> :<View style={GLOBALSTYLES.mainContainer}><Text style={{alignSelf:'center', margin:'20%',color:'black'}}>No Data Found</Text></View>
      )}
    </SafeAreaView>
  );
};

export default Interview;