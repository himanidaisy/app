import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  Dimensions,
  ScrollView,
} from 'react-native';
import Toast from 'react-native-simple-toast';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';
import {Picker} from '@react-native-picker/picker';
import axios from 'axios';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import {URL} from '../../constants/configure';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DatePicker from 'react-native-datepicker';
import { Formik } from 'formik';
import * as yup from 'yup';
import { dpforHeight,dpforWidth } from '../../constants/SizeScreen';
const {height, width} = Dimensions.get('window');

const EditNonJoining = ({route,navigation}) => {
  const [newData, setNewData] = useState([]);
  const [resources, setResources] = useState('');
 
  const [clinets, setClients] = useState([]);
  const [res, setRes] = useState([]);
  const [data, setData] = useState({});

  useEffect(() => {
    getNonJoining();
    getResource();
    getClient();
    setData(route.params.newData);

  }, []);

  const getNonJoining = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/nonjoining',
        requestOptions,
      );

      // console.log(data.data.data.resources);

      setNewData(data.data.data.Nonjoining);
    } catch (error) {
      console.log(error);
    }
  };
  //get res
  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/resource', requestOptions);

      // console.log(data.data.data.resources);

      setRes(data.data.data.resources);
    } catch (error) {
      console.log(error);
    }
  };
  //get client
  const getClient = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/client', requestOptions);

      // console.log(data.data.data.externalResource);

      setClients(data.data.data.clients);
    } catch (error) {
      console.log(error);
    }
  };
  //
  //post
  const putUser = async values => {
    const id = route.params.newData.id;

    //console.log('checkv--------', store);
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      const {data} = await axios.put(
        URL.BASE_URL + `/nonjoining/${id}`,
        values,
        requestOptions,
      );

      //console.log('valuecheck------------->', data);
      if (data.message) {
       
        Toast.showWithGravity('NonJoining Data Updated Successfully', Toast.LONG, Toast.BOTTOM);

      }
      navigation.goBack();
    } catch (err) {
      Toast.showWithGravity('NonJoining Data Not Updated Successfully', Toast.LONG, Toast.BOTTOM);

    }
  };
  const handleSubmit = values => {
    putUser(values);
  };
  
  const loginValidationSchema = yup.object().shape({
    resource: yup.string().required('These field is Required'),
    clients: yup.string(),
    end_date: yup.date().required('These field is Required'),
    joining_date:yup.date(),

  });
  const resourceOptions = res.filter(t => t.resources !== null);
  const clientsOptions = clinets.filter(t => t.client_name !== null);

  console.log('resources', resources);
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Edit Non Joining" />
      <Formik
        validationSchema={loginValidationSchema}
        initialValues={{
          resource: data.resource,
          clients:data.clients,
          end_date:data.end_date,
          joining_date:data.joining_date,
          
        }}
        enableReinitialize={true}
        onSubmit={values => {
          handleSubmit(values);
        }}>
        {({
          handleChange,
          handleBlur,
          handleSubmit,
          setFieldValue,
          errors,
          touched,
          values,
        }) => (
          <>
      <View style={{height: height / 1.2}}>
        <ScrollView>
          <View style={{height: height / 1.0}}>
            <View
              style={{
                width: dpforWidth(90),
                  height: dpforHeight(7),
                margin: 5,
                marginStart: 20,
                backgroundColor: COLORS.pureWhite,
                borderRadius: 10,
                marginTop: 10,
              }}>
               <Picker
            selectedValue={values.resource}
            style={{margin: 4, bottom: 0}}
            mode="dropdown"
            onValueChange={(itemValue) => (
              setFieldValue('resource', itemValue)
            )}>
                <Picker.Item label="Select Resources*" value="" color="grey" />
                {resourceOptions.map((item, index) => (
                  <Picker.Item
                    key={item.id}
                    label={`${item.fname} ${item.lname}`}
                    value={item.id}
                  />
                ))}
              </Picker>
            </View>
            {errors.resource && touched.resource && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.resource}</Text>
                  )}
            <View
              style={{
                width: dpforWidth(90),
                  height: dpforHeight(7),
                margin: 5,
                marginStart: 20,
                backgroundColor: COLORS.pureWhite,
                borderRadius: 10,
                marginTop: 5,
              }}>
             <Picker
            selectedValue={values.clients}
            style={{margin: 4, bottom: 0}}
            mode="dropdown"
            onValueChange={(itemValue) => (
              setFieldValue('clients', itemValue)
            )}>
                <Picker.Item label="Select Client" value="" color="grey" />

                {clientsOptions.map(item => (
                  <Picker.Item
                    key={item.id}
                    label={item.client_name}
                    value={item.id}
                  />
                ))}
              </Picker>
            </View>
            {errors.clients && touched.clients && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.clients}</Text>
                  )}
            <TouchableOpacity
              style={{
                width: dpforWidth(90),
                  height: dpforHeight(7),
                margin: 5,
                flexDirection: 'row',
                justifyContent: 'space-between',
                backgroundColor: COLORS.pureWhite,
                marginStart: 20,
                borderRadius: 10,
              }}>
              <DatePicker
                style={{width: '100%', top: 7}}
                date={values.joining_date}
                mode="date"
                placeholder="Joining Date"
                format="DD MMMM YYYY"
                confirmBtnText="Confirm"
                cancelBtnText="Cancel"
                showIcon={false}
                customStyles={{
                  dateInput: {
                    borderWidth: 0,

                    position: 'absolute',
                    left: 20,
                    fontSize:14,
                  },
                }}
                onDateChange={(itemValue) => (
                  setFieldValue('joining_date', itemValue)
                )} 
              />
              <FontAwesome
                name="calendar-o"
                size={20}
                style={{alignSelf: 'center', right: 30}}
              />
            </TouchableOpacity>
            {errors.joining_date && touched.joining_date && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.joining_date}</Text>
                  )}

            <TouchableOpacity
              style={{
                width: dpforWidth(90),
                  height: dpforHeight(7),
                margin: 5,
                flexDirection: 'row',
                justifyContent: 'space-between',
                backgroundColor: COLORS.pureWhite,
                marginStart: 20,
                borderRadius: 10,
              }}>
              <DatePicker
                style={{width: '100%', top: 7}}
                date={values.end_date}
                mode="date"
                minDate={values.joining_date}
                placeholder="Tentative End Date*"
                format="DD MMMM YYYY"
                confirmBtnText="Confirm"
                cancelBtnText="Cancel"
                showIcon={false}
                customStyles={{
                  dateInput: {
                    borderWidth: 0,

                    position: 'absolute',
                    left: 20,
                    fontSize:14,
                  },
                }}
                onDateChange={(itemValue) => (
                  setFieldValue('end_date', itemValue)
                )} 
              />
              <FontAwesome
                name="calendar-o"
                size={20}
                style={{alignSelf: 'center', right: 30}}
              />
            </TouchableOpacity>
            {errors.end_date && touched.end_date && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.end_date}</Text>
                  )}
          </View>
        </ScrollView>
      </View>
      <TouchableOpacity
        style={GLOBALSTYLES.buttonStyle}
        onPress={() => handleSubmit()}>
        <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
      </TouchableOpacity>
      </>
        )}
      </Formik>
    </SafeAreaView>
  );
};
export default EditNonJoining;