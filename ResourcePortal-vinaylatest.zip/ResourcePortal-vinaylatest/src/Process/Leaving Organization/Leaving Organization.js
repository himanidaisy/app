import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  StyleSheet,
  Linking,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';
import SearchBox from '../../components/SearchBox';

import axios from 'axios';
import {URL} from '../../constants/configure';
import AsyncStorage from '@react-native-async-storage/async-storage';
const {height, width} = Dimensions.get('window');
const LeavingScreen = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [filterData, setFilterData] = useState([]);
  useEffect(() => {
    getResource();
    getAccountFilterData();
  }, [search, loding, newData]);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/leaving-organization',
        requestOptions,
      );
      // console.log(data.data.data.clientAgreements);
      setNewData(data.data.data.product);
      setLoding(false);
    } catch (error) {
      // console.log(error);
      setLoding(true);
    }
  };
  const setSearchValue = value => {
    setSearch(value);
  };
  const getAccountFilterData = () => {
    if (!loding) {
      const filterValue = newData?.filter(data => {
        if (search.length === 0) {
          return data;
        } else if (
          data.resource.fname
            .toLowerCase()
            .includes(!!search && search.toLowerCase()) ||
            data.resource.lname
            .toLowerCase()
            .includes(!!search && search.toLowerCase()) 
            // data.leaving_date.includes(search)
        
        ) {
          // console.log(data);
          return data;
        }
      });
      setFilterData(filterValue);
    }
  };
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <SearchBox search={search} setSearchValue={setSearchValue} />
      {loding ? (
        <ActivityIndicator
          animating={true}
          size="large"
          style={{
            opacity: 1,
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        />
      ) : (
        filterData.length !==0? 

        <FlatList
          data={filterData}
          renderItem={({item}) => (
            <View style={GLOBALSTYLES.appContainer}>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Resources</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                  {item.resource === null
                      ? '-'
                      : `${item.resource.fname} ${item.resource.lname}`}
                  </Text>
                </View>
              </View>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Leaving Date</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {new Date(item.leaving_date).toDateString('en-US', {})
                        .split(' ')
                        .slice(1)
                        .join(' ')}
                    
                  </Text>
                </View>
              </View>
              <TouchableOpacity
                style={{
                  backgroundColor: COLORS.skyBlue,
                  width: wp('80%'),
                  height: hp('7%'),
                  borderRadius: 10,
                  alignSelf: 'center',
                }}
                onPress={() =>
                  navigation.navigate('Edit Leaving', {newData: item})
                }>
                <Text style={GLOBALSTYLES.textStyle}>Edit</Text>
              </TouchableOpacity>
            </View>
          )}
        /> :<View style={GLOBALSTYLES.mainContainer}><Text style={{alignSelf:'center', margin:'20%',color:'black'}}>No Data Found</Text></View>

      )}
    </SafeAreaView>
  );
};

export default LeavingScreen;
