import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  Dimensions,
  StyleSheet,
} from 'react-native';
import DatePicker from 'react-native-datepicker/datepicker';
import { dpforHeight,dpforWidth } from '../../constants/SizeScreen';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';
import Toast from 'react-native-simple-toast';
import {Picker} from '@react-native-picker/picker';
import axios from 'axios';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {URL} from '../../constants/configure';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Formik } from 'formik';
import * as yup from 'yup';
const {height, width} = Dimensions.get('window');

const AddLeavingScreen = ({navigation}) => {
  const [newData, setNewData] = useState([]);

  useEffect(() => {
    getResource();
  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/resource', requestOptions);

      //  console.log(data.data.data.clientAgreements);

      setNewData(data.data.data.resources);
    } catch (error) {
      console.log(error);
    }
  };
  const postUser = async values => {
  
    console.log('checkv--------', values);
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
        URL.BASE_URL + '/leaving-organization',
        values,
        requestOptions,
      );

      // console.log('valuecheck------------->',data);
      if (data.message) {
      
        Toast.showWithGravity('Leavingorganizations Data Added Successfully', Toast.LONG, Toast.BOTTOM);

      }
      navigation.goBack();
    } catch (err) {
      // console.log(err.response)
      Toast.showWithGravity('Leavingorganizations Data Not Added Successfully', Toast.LONG, Toast.BOTTOM);

    }
  };
  const handleSubmit = values => {
    postUser(values);
  };

  const loginValidationSchema = yup.object().shape({
    resource_id: yup.string().required('These field is Required'),
    leaving_date: yup
      .string().required('These field is Required'),
  

  });
  const leavingOptions = newData.filter(t => t.resources !== null);
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Leaving Organization" />
      <Formik
        validationSchema={loginValidationSchema}
        initialValues={{
          resource_id: '',
          leaving_date: '',
          
        }}
        enableReinitialize={true}
        onSubmit={values => {
          handleSubmit(values);
        }}>
        {({
          handleChange,
          handleBlur,
          handleSubmit,
          setFieldValue,
          errors,
          touched,
          values,
        }) => (
          <>
      <View style={styles.container}>
        <View
          style={{
            width: dpforWidth(90),
                  height: dpforHeight(7),
            margin: 5,
            marginStart: 20,
            backgroundColor: COLORS.pureWhite,
            borderRadius: 10,
            marginTop: 10,
          }}>
          <Picker
            selectedValue={values.resource_id}
            style={{margin: 4, bottom: 0}}
            mode="dropdown"
            onValueChange={(itemValue) => (
              setFieldValue('resource_id', itemValue)
            )}>
            <Picker.Item label="Select Resources*" value="" color="grey" />
            {leavingOptions.map((item, index) => (
              <Picker.Item
                key={item.id}
                label={`${item.fname} ${item.lname}`}
                value={item.id}
              />
            ))}
          </Picker>
        </View>

        {errors.resource_id && touched.resource_id && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.resource_id}</Text>
                  )}

        <TouchableOpacity
          style={{
            width: dpforWidth(90),
            height: dpforHeight(7),
            margin: 5,
            flexDirection: 'row',
            justifyContent: 'space-between',
            backgroundColor: COLORS.pureWhite,
            marginStart: 20,
            borderRadius: 10,
          }}>
          <DatePicker
            style={{width: '100%', top: 7}}
            date={values.leaving_date}
            // value={leavingdate}
            mode="date"
            placeholder="Leaving date*"
            format="DD MMMM YYYY"
            confirmBtnText="Confirm"
            cancelBtnText="Cancel"
            showIcon={false}
            customStyles={{
              dateInput: {
                borderWidth: 0,

                position: 'absolute',
                left: 20,
                fontSize:14,
              },
            }}
            onDateChange={(itemValue) => (
              setFieldValue('leaving_date', itemValue)
            )} 
          />
          <FontAwesome
            name="calendar-o"
            size={20}
            style={{alignSelf: 'center', right: 30}}
          />
        </TouchableOpacity>
        {errors.leaving_date && touched.leaving_date && (
                    <Text style={GLOBALSTYLES.errorStyle}>{errors.leaving_date}</Text>
                  )}
        <TouchableOpacity
          style={GLOBALSTYLES.buttonStyle}
          onPress={() => handleSubmit()}>
          <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
        </TouchableOpacity>
      </View>
      </>
        )}
      </Formik>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
});
export default AddLeavingScreen;